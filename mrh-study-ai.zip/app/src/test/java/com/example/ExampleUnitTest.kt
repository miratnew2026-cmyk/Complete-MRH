package com.example

import com.example.ui.components.TextbookMathFormatter
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests verifying textbook mathematics formatting.
 */
class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testMathFormatting_UserScreenshotProblem() {
        val input = """যদি ${'$'}x = \sqrt{6} + \sqrt{5}${'$'} হয়, তবে ${'$'}\frac{x^6 - 1}{x^3}${'$'}-এর মান নির্ণয় করো।"""
        val result = TextbookMathFormatter.format(input)

        // Must not contain raw LaTeX code or dollar signs
        assertFalse("Should not contain \\sqrt", result.contains("\\sqrt"))
        assertFalse("Should not contain \\frac", result.contains("\\frac"))
        assertFalse("Should not contain $", result.contains("$"))

        // Must contain clean textbook math characters
        assertTrue("Should contain √6 + √5", result.contains("√6 + √5"))
        assertTrue("Should contain x⁶ - 1", result.contains("x⁶ - 1"))
        assertTrue("Should contain x³", result.contains("x³"))
        assertTrue("Should contain division /", result.contains("/"))
    }

    @Test
    fun testMathFormatting_FractionsAndRoots() {
        val input = """${'$'}\frac{1}{x} = \frac{1}{\sqrt{6} + \sqrt{5}}${'$'}"""
        val result = TextbookMathFormatter.format(input)

        assertEquals("1/x = 1 / (√6 + √5)", result.trim())
    }

    @Test
    fun testMathFormatting_DifferenceOfSquares() {
        val input = """${'$'}(\sqrt{6})^2 - (\sqrt{5})^2${'$'}"""
        val result = TextbookMathFormatter.format(input)

        assertEquals("(√6)² - (√5)²", result.trim())
    }

    @Test
    fun testMathFormatting_MathSymbols() {
        val input = """\pi r^2, 2 \times 3, 10 \div 2, \pm 5, \theta, \alpha, \le, \ge, \ne"""
        val result = TextbookMathFormatter.format(input)

        assertTrue(result.contains("π"))
        assertTrue(result.contains("r²"))
        assertTrue(result.contains("×"))
        assertTrue(result.contains("÷"))
        assertTrue(result.contains("±"))
        assertTrue(result.contains("θ"))
        assertTrue(result.contains("α"))
        assertTrue(result.contains("≤"))
        assertTrue(result.contains("≥"))
        assertTrue(result.contains("≠"))
    }

    @Test
    fun testMathFormatting_FullUserScreenshotConversation() {
        val lines = listOf(
            """যদি ${'$'}x = \sqrt{6} + \sqrt{5}${'$'} হয়, তবে ${'$'}\frac{x^6 - 1}{x^3}${'$'}-এর মান নির্ণয় করো।""",
            """ধাপ ১: দেওয়া আছে মান থেকে ${'$'}\frac{1}{x}${'$'}-এর মান নির্ণয়""",
            """${'$'}x = \sqrt{6} + \sqrt{5}${'$'}""",
            """${'$'}\frac{1}{x} = \frac{1}{\sqrt{6} + \sqrt{5}}${'$'}""",
            """${'$'}\frac{1}{x} = \frac{\sqrt{6} - \sqrt{5}}{(\sqrt{6} + \sqrt{5})(\sqrt{6} - \sqrt{5})}${'$'}""",
            """নিচের অংশটি ${'$'}(a+b)(a-b) = a^2 - b^2${'$'} সূত্রে পড়ে:""",
            """${'$'}\frac{1}{x} = \frac{\sqrt{6} - \sqrt{5}}{(\sqrt{6})^2 - (\sqrt{5})^2}${'$'}"""
        )

        for (line in lines) {
            val formatted = TextbookMathFormatter.format(line)
            assertFalse("Line must not contain raw \\sqrt: $formatted", formatted.contains("\\sqrt"))
            assertFalse("Line must not contain raw \\frac: $formatted", formatted.contains("\\frac"))
            assertFalse("Line must not contain dollar signs: $formatted", formatted.contains("$"))
            assertFalse("Line must not contain raw caret: $formatted", formatted.contains("^"))
        }
    }
}
