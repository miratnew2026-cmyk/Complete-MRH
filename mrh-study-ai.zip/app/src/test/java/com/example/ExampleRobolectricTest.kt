package com.example

import com.example.data.model.BoardQuestionsData
import com.example.data.model.GrammarLessonsData
import com.example.data.model.SscSyllabusData
import com.example.data.model.StudyPlanGenerator
import com.example.data.model.StudyPlansData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `verify all 12 SSC 2028 subjects are configured`() {
        val subjects = SscSyllabusData.subjects
        assertEquals("Should have exactly 12 required subjects", 12, subjects.size)

        val subjectIds = subjects.map { it.id }
        assertTrue("Contains Bangla 1st Paper", subjectIds.contains("bangla_1"))
        assertTrue("Contains General Math", subjectIds.contains("general_math"))
        assertTrue("Contains Higher Math", subjectIds.contains("higher_math"))
        assertTrue("Contains Physics", subjectIds.contains("physics"))
        assertTrue("Contains Chemistry", subjectIds.contains("chemistry"))
        assertTrue("Contains Biology", subjectIds.contains("biology"))
        assertTrue("Contains ICT", subjectIds.contains("ict"))
        assertTrue("Contains English 2nd", subjectIds.contains("english_2"))
    }

    @Test
    fun `verify study plans and grammar topics exist`() {
        assertNotNull(StudyPlansData.fourMonthPlan)
        assertNotNull(StudyPlansData.sixMonthPlan)
        assertEquals(4, StudyPlansData.fourMonthPlan.phases.size)
        assertEquals(4, StudyPlansData.sixMonthPlan.phases.size)

        assertTrue(GrammarLessonsData.topics.isNotEmpty())
        assertTrue(BoardQuestionsData.sampleMcqs.isNotEmpty())
    }

    @Test
    fun `verify future study plan generator creates complete 4-month and 6-month routines`() {
        // Test 4 Months (120 days)
        val (config4, tasks4) = StudyPlanGenerator.generateCompleteSchedule(
            durationMonths = 4,
            dailyHours = 4,
            startDateMillis = System.currentTimeMillis()
        )
        assertEquals(120, config4.totalPlanDays)
        assertTrue("Should generate daily tasks for 120 days", tasks4.size >= 120)

        // Verify task attributes
        val firstTask = tasks4.first()
        assertEquals(1, firstTask.dayNumber)
        assertNotNull(firstTask.subjectName)
        assertNotNull(firstTask.chapterTitle)

        // Test 6 Months (180 days)
        val (config6, tasks6) = StudyPlanGenerator.generateCompleteSchedule(
            durationMonths = 6,
            dailyHours = 6,
            startDateMillis = System.currentTimeMillis()
        )
        assertEquals(180, config6.totalPlanDays)
        assertTrue("Should generate daily tasks for 180 days", tasks6.size >= 180)
    }

    @Test
    fun `verify chapter time extension shifts subsequent dates`() {
        val (config, tasks) = StudyPlanGenerator.generateCompleteSchedule(
            durationMonths = 4,
            dailyHours = 4,
            startDateMillis = System.currentTimeMillis()
        )
        val targetChapter = tasks.first().chapterTitle
        val originalTargetMillis = config.targetCompletionDateMillis

        val (updatedConfig, updatedTasks) = StudyPlanGenerator.extendChapterTasks(
            targetChapterTitle = targetChapter,
            extraDays = 3,
            allTasks = tasks,
            currentConfig = config
        )

        assertEquals("Config should record +3 extended days", 3, updatedConfig.extendedDaysTotal)
        assertTrue(
            "Target completion date should shift by 3 days",
            updatedConfig.targetCompletionDateMillis > originalTargetMillis
        )
        assertEquals(tasks.size, updatedTasks.size)
    }

    @Test
    fun `verify Bangla 1st Paper has exactly 53 chapters with 25 prose and 28 poetry`() {
        val bangla1 = SscSyllabusData.getSubject("bangla_1")
        assertNotNull(bangla1)
        assertEquals("Bangla 1st Paper should have exactly 53 chapters", 53, bangla1!!.chapters.size)

        val prose = bangla1.chapters.filter { it.section == "গদ্য" }
        val poetry = bangla1.chapters.filter { it.section == "কবিতা" }

        assertEquals("Should have exactly 25 prose chapters", 25, prose.size)
        assertEquals("Should have exactly 28 poetry chapters", 28, poetry.size)

        assertEquals("First prose chapter should be প্রত্যুপকার", "প্রত্যুপকার", prose.first().title)
        assertEquals("25th prose chapter should be আমাদের নতুন গৌরবগাথা", "আমাদের নতুন গৌরবগাথা", prose.last().title)

        assertEquals("First poetry chapter should be বঙ্গবাণী", "বঙ্গবাণী", poetry.first().title)
        assertEquals("28th poetry chapter should be সময়ের গান", "সময়ের গান", poetry.last().title)

        // Verify Bangla 2nd Paper was not modified
        val bangla2 = SscSyllabusData.getSubject("bangla_2")
        assertNotNull(bangla2)
        assertEquals("Bangla 2nd Paper should remain unchanged with 9 chapters", 9, bangla2!!.chapters.size)
    }

    @Test
    fun `verify buildValidChatHistory creates valid alternating turns starting with user and ending with model`() {
        val repo = com.example.data.ai.AiRepository()
        val rawHistory = listOf(
            "ai" to "আসসালামু আলাইকুম! আমি তোমার SSC 2028 AI Study Coach...",
            "user" to "পদার্থবিজ্ঞান ৩য় অধ্যায় বল এর সূত্র কি?",
            "ai" to "নিউটনের গতির ২য় সূত্র: F = ma।",
            "ai" to "দুঃখিত, সংযোগে ত্রুটি হয়েছে: Timed out waiting for 60000 ms। পুনরায় চেষ্টা করুন।",
            "user" to "কাজ ক্ষমতা ও শক্তি বুঝিয়ে দাও"
        )
        val validHistory = repo.buildValidChatHistory(rawHistory, "কাজ ক্ষমতা ও শক্তি বুঝিয়ে দাও")

        // Should drop the leading AI greeting
        // Should drop the error message
        // Should drop the trailing duplicate user prompt
        // Result should only contain the valid (user, model) pair
        assertEquals("Should contain 1 pair (user -> model)", 2, validHistory.size)
        assertEquals("user", validHistory[0].role)
        assertEquals("model", validHistory[1].role)
    }

    @Test
    fun `verify General Mathematics has 17 chapters and Higher Mathematics has 14 chapters without duplication`() {
        val genMath = SscSyllabusData.getSubject("general_math")
        val highMath = SscSyllabusData.getSubject("higher_math")

        assertNotNull(genMath)
        assertNotNull(highMath)

        assertEquals("General Math should have 17 chapters", 17, genMath!!.chapters.size)
        assertEquals("Higher Math should have 14 chapters", 14, highMath!!.chapters.size)
        assertEquals(31, genMath.chapters.size + highMath.chapters.size)

        // Check no duplicate titles within each subject
        assertEquals(17, genMath.chapters.map { it.title }.distinct().size)
        assertEquals(14, highMath.chapters.map { it.title }.distinct().size)

        // Verify exact first and last titles
        assertEquals("বাস্তব সংখ্যা", genMath.chapters.first().title)
        assertEquals("পরিসংখ্যান", genMath.chapters.last().title)
        assertEquals("সেট ও ফাংশন", highMath.chapters.first().title)
        assertEquals("সম্ভাবনা", highMath.chapters.last().title)

        // Verify priority badges distribution (15 + 13 = 28 ⭐, 2 + 1 = 3 ☆)
        assertEquals(15, genMath.chapters.count { it.importanceTag == "⭐" })
        assertEquals(2, genMath.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(14, 15), genMath.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        assertEquals(13, highMath.chapters.count { it.importanceTag == "⭐" })
        assertEquals(1, highMath.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(4), highMath.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        // Verify updated Science chapter counts remain consistent with SSC 2028 Science Dashboard
        assertEquals(13, SscSyllabusData.getSubject("physics")?.chapters?.size)
        assertEquals(12, SscSyllabusData.getSubject("chemistry")?.chapters?.size)
        assertEquals(14, SscSyllabusData.getSubject("biology")?.chapters?.size)
    }

    @Test
    fun `verify Science subjects have exact 39 chapters with zero duplication and other subjects remain untouched`() {
        val physics = SscSyllabusData.getSubject("physics")!!
        val chemistry = SscSyllabusData.getSubject("chemistry")!!
        val biology = SscSyllabusData.getSubject("biology")!!

        // Counts: Physics 13, Chemistry 12, Biology 14 -> Combined 39
        assertEquals(13, physics.chapters.size)
        assertEquals(12, chemistry.chapters.size)
        assertEquals(14, biology.chapters.size)
        assertEquals(39, physics.chapters.size + chemistry.chapters.size + biology.chapters.size)

        // Zero duplicates within each subject
        assertEquals(13, physics.chapters.map { it.title }.distinct().size)
        assertEquals(12, chemistry.chapters.map { it.title }.distinct().size)
        assertEquals(14, biology.chapters.map { it.title }.distinct().size)

        // Exact ordered first and last titles
        assertEquals("ভৌত রাশি এবং তাদের পরিমাপ", physics.chapters.first().title)
        assertEquals("তেজস্ক্রিয়তা ও ইলেকট্রনিকস", physics.chapters.last().title)

        assertEquals("রসায়নের ধারণা", chemistry.chapters.first().title)
        assertEquals("আমাদের জীবনে রসায়ন", chemistry.chapters.last().title)

        assertEquals("জীবনপাঠ", biology.chapters.first().title)
        assertEquals("জীবপ্রযুক্তি", biology.chapters.last().title)

        // Priority distribution verification: 31 ⭐ Important, 8 ☆ Normal, 0 🟡 Low
        assertEquals(10, physics.chapters.count { it.importanceTag == "⭐" })
        assertEquals(3, physics.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(6, 10, 13), physics.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        assertEquals(10, chemistry.chapters.count { it.importanceTag == "⭐" })
        assertEquals(2, chemistry.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(11, 12), chemistry.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        assertEquals(11, biology.chapters.count { it.importanceTag == "⭐" })
        assertEquals(3, biology.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(1, 9, 14), biology.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        // Verify untouched non-science subjects (including updated BGS 14, Islam 5, ICT 7)
        assertEquals(17, SscSyllabusData.getSubject("general_math")?.chapters?.size)
        assertEquals(14, SscSyllabusData.getSubject("higher_math")?.chapters?.size)
        assertEquals(53, SscSyllabusData.getSubject("bangla_1")?.chapters?.size)
        assertEquals(9, SscSyllabusData.getSubject("bangla_2")?.chapters?.size)
        assertEquals(8, SscSyllabusData.getSubject("english_1")?.chapters?.size)
        assertEquals(7, SscSyllabusData.getSubject("english_2")?.chapters?.size)
        assertEquals(7, SscSyllabusData.getSubject("ict")?.chapters?.size)
        assertEquals(14, SscSyllabusData.getSubject("bgs")?.chapters?.size)
        assertEquals(5, SscSyllabusData.getSubject("islam_moral")?.chapters?.size)
    }

    @Test
    fun `verify BGS 14, Islam 5, and ICT 7 have exact 26 chapters with zero duplicates and all other 9 subjects unchanged`() {
        val bgs = SscSyllabusData.getSubject("bgs")!!
        val islam = SscSyllabusData.getSubject("islam_moral")!!
        val ict = SscSyllabusData.getSubject("ict")!!

        // Counts: BGS 14 + Islam 5 + ICT 7 = 26
        assertEquals(14, bgs.chapters.size)
        assertEquals(5, islam.chapters.size)
        assertEquals(7, ict.chapters.size)
        assertEquals(26, bgs.chapters.size + islam.chapters.size + ict.chapters.size)

        // Zero duplicates
        assertEquals(14, bgs.chapters.map { it.title }.distinct().size)
        assertEquals(5, islam.chapters.map { it.title }.distinct().size)
        assertEquals(7, ict.chapters.map { it.title }.distinct().size)

        // Exact ordered titles verification
        assertEquals("পূর্ব বাংলার আন্দোলন ও জাতীয়তাবাদের উত্থান", bgs.chapters.first().title)
        assertEquals("বাংলাদেশ ও আন্তর্জাতিক সহযোগিতা", bgs.chapters.last().title)

        assertEquals("আকাইদ ও নৈতিক জীবন", islam.chapters.first().title)
        assertEquals("আদর্শ জীবনচরিত", islam.chapters.last().title)

        assertEquals("তথ্য ও যোগাযোগ প্রযুক্তি এবং আমাদের বাংলাদেশ", ict.chapters.first().title)
        assertEquals("ইন্টারনেট ও ওয়েব পরিচিতি", ict.chapters.last().title)

        // Exact priority distribution: BGS (12 ⭐, 2 ☆ at #4 & #11), Islam (5 ⭐), ICT (7 ⭐)
        assertEquals(12, bgs.chapters.count { it.importanceTag == "⭐" })
        assertEquals(2, bgs.chapters.count { it.importanceTag == "☆" })
        assertEquals(listOf(4, 11), bgs.chapters.filter { it.importanceTag == "☆" }.map { it.number })

        assertEquals(5, islam.chapters.count { it.importanceTag == "⭐" })
        assertEquals(0, islam.chapters.count { it.importanceTag == "☆" })

        assertEquals(7, ict.chapters.count { it.importanceTag == "⭐" })
        assertEquals(0, ict.chapters.count { it.importanceTag == "☆" })

        // Verify Math, Higher Math, Science, Bangla, English remain untouched
        assertEquals(17, SscSyllabusData.getSubject("general_math")?.chapters?.size)
        assertEquals(14, SscSyllabusData.getSubject("higher_math")?.chapters?.size)
        assertEquals(13, SscSyllabusData.getSubject("physics")?.chapters?.size)
        assertEquals(12, SscSyllabusData.getSubject("chemistry")?.chapters?.size)
        assertEquals(14, SscSyllabusData.getSubject("biology")?.chapters?.size)
        assertEquals(53, SscSyllabusData.getSubject("bangla_1")?.chapters?.size)
        assertEquals(9, SscSyllabusData.getSubject("bangla_2")?.chapters?.size)
        assertEquals(8, SscSyllabusData.getSubject("english_1")?.chapters?.size)
        assertEquals(7, SscSyllabusData.getSubject("english_2")?.chapters?.size)
    }

    @Test
    fun `verify AiRepository filters colon error prefix in chat history`() {
        val repo = com.example.data.ai.AiRepository()
        val history = listOf(
            "user" to "সেট ও ফাংশন বুঝিয়ে দাও",
            "ai" to "দুঃখিত: নেটওয়ার্ক সমস্যা। পুনরায় চেষ্টা বাটনে ট্যাপ করুন।",
            "user" to "ত্রিকোণমিতি বুঝিয়ে দাও",
            "ai" to "ত্রিকোণমিতির মূল অনুপাতগুলো হলো sin, cos, tan।",
            "user" to "আবার প্রশ্ন"
        )
        val valid = repo.buildValidChatHistory(history, "আবার প্রশ্ন")
        assertEquals(2, valid.size)
        assertEquals("user", valid[0].role)
        assertEquals("model", valid[1].role)
    }
}
