package com.example.data.remote

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AttemptAnswerItem
import com.example.data.model.McqQuestionRecord
import com.example.data.model.McqUploadRecord
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class QuizAgentRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun unauthenticatedCaller_failsAllStreamsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = QuizAgentRepository(firestore)

        // 1. Published quizzes stream fails unauthenticated
        try {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observePublishedQuizzes().first() }
            fail("Expected PERMISSION_DENIED for unauthenticated observePublishedQuizzes")
        } catch (e: Exception) {
            val fs = checkNotNull(e.unwrapFirestoreError()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fs.code)
        }

        // 2. Published MCQs stream fails unauthenticated
        try {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observePublishedMcqs().first() }
            fail("Expected PERMISSION_DENIED for unauthenticated observePublishedMcqs")
        } catch (e: Exception) {
            val fs = checkNotNull(e.unwrapFirestoreError()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fs.code)
        }

        // 3. Quiz attempts stream fails unauthenticated
        try {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observeMyAttempts("any_user").first() }
            fail("Expected PERMISSION_DENIED for unauthenticated observeMyAttempts")
        } catch (e: Exception) {
            val fs = checkNotNull(e.unwrapFirestoreError()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fs.code)
        }
    }

    @Test
    fun studentCannotWriteMcqOrQuizOrSelfPromoteAgent() = runBlocking {
        val studentUid = signInTestUser("student_alice@test.com")
        val repo = QuizAgentRepository(firestore)

        val mcqResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createMcq(sampleMcq(status = "published", ocrReviewed = true))
        }
        assertTrue(mcqResult.isFailure)
        val mcqFs = mcqResult.exceptionOrNull()?.unwrapFirestoreError()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, mcqFs?.code)

        val quizResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createQuiz(sampleQuiz(mcqIds = listOf("mcq_1"), status = "published"))
        }
        assertTrue(quizResult.isFailure)
        val quizFs = quizResult.exceptionOrNull()?.unwrapFirestoreError()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, quizFs?.code)

        val roleResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.upsertAgentRole(
                targetUid = studentUid,
                username = "hacker",
                displayName = "Hacker",
                email = "student_alice@test.com"
            )
        }
        assertTrue(roleResult.isFailure)
        val roleFs = roleResult.exceptionOrNull()?.unwrapFirestoreError()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, roleFs?.code)
    }

    @Test
    fun bootstrappedAgent_cannotPublishUnreviewedOcrMcq_mustReviewFirst_thenCreateAndPublishQuiz() = runBlocking {
        val adminUid = signInTestUser(ADMIN_EMAIL, verifyEmailInEmulator = true)
        val repo = QuizAgentRepository(firestore)

        // Ensure bootstrapped agent doc succeeds
        val profileRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureBootstrappedAgentProfile(
                username = "Mr1122",
                displayName = "MRH Agent",
                email = ADMIN_EMAIL
            )
        }
        assertTrue("Expected profile creation success: ${profileRes.exceptionOrNull()}", profileRes.isSuccess)

        // Attempt bypassing OCR review gate by writing raw unreviewed published doc to Firestore
        val illegalDocId = "unreviewed_${UUID.randomUUID()}"
        val illegalDoc = sampleMcq(status = "published", ocrReviewed = false).copy(
            createdBy = adminUid
        )
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection(QuizAgentRepository.COLLECTION_MCQS)
                    .document(illegalDocId)
                    .set(illegalDoc)
                    .await()
            }
            fail("Security rules must block publishing MCQ when ocrReviewed=false")
        } catch (e: Exception) {
            val fs = e.unwrapFirestoreError()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fs?.code)
        }

        // Save OCR extracted MCQ to pending_review queue
        val uploadId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createUploadRecord(
                McqUploadRecord(
                    id = "upload_${UUID.randomUUID()}",
                    fileName = "algebra_ch3.pdf",
                    fileType = "pdf",
                    storagePath = "mcq_uploads/$adminUid/algebra_ch3.pdf",
                    downloadUrl = "",
                    subjectId = "general_math",
                    subjectName = "সাধারণ গণিত",
                    chapterNumber = 3L,
                    chapterTitle = "বীজগাণিতিক রাশি",
                    extractedCount = 1L,
                    reviewedCount = 0L,
                    ocrStatus = "pending_review",
                    storageSynced = false
                )
            ).getOrThrow()
        }

        val pendingMcqId = "mcq_${UUID.randomUUID()}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createMcq(
                sampleMcq(
                    id = pendingMcqId,
                    sourceType = "ocr_pdf",
                    ocrReviewed = false,
                    status = "pending_review"
                )
            ).getOrThrow()
        }

        // Review and publish MCQ
        val fetchedPending = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.getMcqById(pendingMcqId).getOrThrow()
        }
        assertNotNull(fetchedPending)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.updateMcq(
                fetchedPending!!.copy(
                    question = "x + 1/x = 3 হলে, x² + 1/x² = কত?",
                    ocrReviewed = true,
                    status = "published"
                )
            ).getOrThrow()
        }

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.updateUploadRecord(uploadId = uploadId, reviewedCount = 1L, ocrStatus = "reviewed").getOrThrow()
        }

        // Create and publish quiz using reviewed MCQ
        val quizId = "quiz_${UUID.randomUUID()}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createQuiz(
                sampleQuiz(
                    id = quizId,
                    mcqIds = listOf(pendingMcqId),
                    status = "published"
                )
            ).getOrThrow()
        }

        // Now student signs in and observes published quizzes & submits attempt
        val studentUid = signInTestUser("student_reader_${UUID.randomUUID()}@test.com")
        val studentRepo = QuizAgentRepository(firestore)

        val publishedQuizzes = withTimeout(FLOW_TIMEOUT_MS) {
            studentRepo.observePublishedQuizzes().first { list -> list.any { it.id == quizId } }
        }
        assertTrue(publishedQuizzes.any { it.id == quizId })

        val publishedMcqs = withTimeout(FLOW_TIMEOUT_MS) {
            studentRepo.observePublishedMcqs().first { list -> list.any { it.id == pendingMcqId } }
        }
        assertTrue(publishedMcqs.any { it.id == pendingMcqId })

        val attemptId = "attempt_${UUID.randomUUID()}"
        val submitRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentRepo.submitQuizAttempt(
                QuizAttemptRecord(
                    id = attemptId,
                    userId = studentUid,
                    quizId = quizId,
                    quizTitle = "বীজগণিত কুইজ",
                    quizType = "agent_uploaded",
                    subjectId = "general_math",
                    subjectName = "সাধারণ গণিত",
                    chapterTitle = "বীজগাণিতিক রাশি",
                    score = 1L,
                    totalQuestions = 1L,
                    accuracyPercent = 100.0,
                    timeTakenSeconds = 42L,
                    examMode = true,
                    answers = listOf(
                        AttemptAnswerItem(
                            mcqId = pendingMcqId,
                            question = "x + 1/x = 3 হলে, x² + 1/x² = কত?",
                            options = listOf("7", "9", "11", "5"),
                            selectedIndex = 0L,
                            correctIndex = 0L,
                            isCorrect = true,
                            explanation = "(x + 1/x)² - 2 = 9 - 2 = 7"
                        )
                    )
                )
            )
        }
        assertTrue("Attempt submission should succeed: ${submitRes.exceptionOrNull()}", submitRes.isSuccess)

        val myAttempts = withTimeout(FLOW_TIMEOUT_MS) {
            studentRepo.observeMyAttempts(studentUid).first { list -> list.any { it.id == attemptId } }
        }
        assertTrue(myAttempts.any { it.id == attemptId })

        // Cross-user attempt isolation check
        signInTestUser("student_other_${UUID.randomUUID()}@test.com")
        val otherGet = withTimeout(DEFAULT_TIMEOUT_MS) {
            QuizAgentRepository(firestore).getAttemptById(attemptId)
        }
        assertTrue(otherGet.isFailure)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, otherGet.exceptionOrNull()?.unwrapFirestoreError()?.code)

        // Promote a secondary registered agent & verify RBAC works for them
        signInTestUser(ADMIN_EMAIL, verifyEmailInEmulator = true)
        val delegatedUid = signInTestUser("delegated_agent_${UUID.randomUUID()}@test.com")
        signInTestUser(ADMIN_EMAIL, verifyEmailInEmulator = true)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            QuizAgentRepository(firestore).upsertAgentRole(
                targetUid = delegatedUid,
                username = "SubAgent01",
                displayName = "Sub Agent",
                email = "sub@test.com",
                active = true
            ).getOrThrow()
        }

        // Delegated agent reads agent profile & publishes an MCQ cleanly
        signInTestUser("delegated_relogin@test.com") // Note: we check with exact email of delegated user
        val secondAgentEmail = "agent2_${UUID.randomUUID()}@test.com"
        val secondAgentUid = signInTestUser(secondAgentEmail)
        signInTestUser(ADMIN_EMAIL, verifyEmailInEmulator = true)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            QuizAgentRepository(firestore).upsertAgentRole(
                targetUid = secondAgentUid,
                username = "AgentTwo",
                displayName = "Agent Two",
                email = secondAgentEmail,
                active = true
            ).getOrThrow()
        }
        signInTestUser(secondAgentEmail)
        val agent2Repo = QuizAgentRepository(firestore)
        val agent2McqRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            agent2Repo.createMcq(sampleMcq(id = "mcq_a2_${UUID.randomUUID()}", status = "published", ocrReviewed = true))
        }
        assertTrue("Registered agent should be able to publish reviewed MCQ: ${agent2McqRes.exceptionOrNull()}", agent2McqRes.isSuccess)

        val scopedAgentMcqs = withTimeout(FLOW_TIMEOUT_MS) {
            agent2Repo.observeAgentMcqs(secondAgentUid).first { list -> list.isNotEmpty() }
        }
        assertTrue("Delegated agent scoped MCQ stream should return created items", scopedAgentMcqs.isNotEmpty())
    }

    private fun sampleMcq(
        id: String = "",
        sourceType: String = "manual",
        ocrReviewed: Boolean = true,
        status: String = "draft"
    ) = McqQuestionRecord(
        id = id,
        subjectId = "general_math",
        subjectName = "সাধারণ গণিত",
        chapterNumber = 3L,
        chapterTitle = "বীজগাণিতিক রাশি",
        question = "a + b = 5 এবং ab = 6 হলে, a² + b² এর মান কত?",
        options = listOf("13", "19", "25", "12"),
        correctIndex = 0L,
        explanation = "a² + b² = (a + b)² - 2ab = 25 - 12 = 13",
        difficulty = "medium",
        sourceType = sourceType,
        sourceFileUrl = "",
        sourceStoragePath = "",
        ocrReviewed = ocrReviewed,
        status = status,
        quizId = ""
    )

    private fun sampleQuiz(
        id: String = "",
        mcqIds: List<String>,
        status: String = "draft"
    ) = QuizCollectionRecord(
        id = id,
        title = "এসএসসি গণিত অধ্যায় ৩ টেস্ট",
        description = "গুরুত্বপূর্ণ বীজগাণিতিক রাশির প্রশ্ন",
        subjectId = "general_math",
        subjectName = "সাধারণ গণিত",
        chapterNumber = 3L,
        chapterTitle = "বীজগাণিতিক রাশি",
        quizType = "agent_uploaded",
        difficulty = "medium",
        durationMinutes = 10L,
        mcqIds = mcqIds,
        questionCount = mcqIds.size.toLong(),
        status = status,
        createdByName = "Mr1122"
    )

    private companion object {
        const val ADMIN_EMAIL = "miratnew2026@gmail.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
