package com.example.viewmodel

import com.example.data.model.AttemptAnswerItem
import com.example.data.model.BookMcqSeedData
import com.example.data.model.McqQuestionRecord
import com.example.data.model.PlayableMcq
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.QuizModeType
import com.example.data.model.RemoteUiState
import com.example.data.model.SscSyllabusData
import com.example.data.model.toPlayableMcq
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QuizSelectionState(
    val selectedSubjectId: String = "general_math",
    val selectedChapterNumber: Int? = null,
    val selectedMode: QuizModeType = QuizModeType.PRACTICE,
    val questionLimit: Int = 10,
    val customDurationMinutes: Int = 10,
    val bannerMessage: String? = null
)

data class QuizSessionState(
    val isActive: Boolean = false,
    val quizId: String = "",
    val quizTitle: String = "",
    val mode: QuizModeType = QuizModeType.PRACTICE,
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterTitle: String = "",
    val questions: List<PlayableMcq> = emptyList(),
    val currentIndex: Int = 0,
    val selectedAnswers: Map<Int, Int> = emptyMap(),
    val revealedPracticeIndices: Set<Int> = emptySet(),
    val totalDurationSeconds: Int = 600,
    val remainingSeconds: Int = 600,
    val elapsedSeconds: Int = 0,
    val isSubmitted: Boolean = false,
    val isSavingAttempt: Boolean = false,
    val saveStatusMessage: String? = null,
    val score: Int = 0,
    val accuracyPercent: Double = 0.0
)

interface QuizController {
    val selectionState: StateFlow<QuizSelectionState>
    val sessionState: StateFlow<QuizSessionState>
    val publishedQuizzes: StateFlow<RemoteUiState<List<QuizCollectionRecord>>>
    val publishedMcqs: StateFlow<RemoteUiState<List<McqQuestionRecord>>>
    val myAttempts: StateFlow<RemoteUiState<List<QuizAttemptRecord>>>

    fun selectSubject(subjectId: String)
    fun selectChapter(chapterNumber: Int?)
    fun selectMode(mode: QuizModeType)
    fun setQuestionLimit(limit: Int)
    fun setDurationMinutes(minutes: Int)
    fun clearBannerMessage()
    fun availableBookCountForSubject(subjectId: String): Int
    fun availablePublishedAgentCountForSubject(subjectId: String): Int
    fun availableCountForChapter(subjectId: String, chapterNumber: Int): Int
    fun startConfiguredQuiz()
    fun startPublishedQuizCollection(quiz: QuizCollectionRecord)
    fun selectAnswer(questionIndex: Int, optionIndex: Int)
    fun goToQuestion(index: Int)
    fun nextQuestion()
    fun previousQuestion()
    fun submitActiveQuiz(
        onRecordMistake: ((
            subjectName: String,
            chapterTitle: String,
            question: String,
            studentAnswer: String,
            correctAnswer: String,
            explanation: String
        ) -> Unit)?
    )
    fun closeSession()
}

internal class QuizSessionEngine(
    private val scope: CoroutineScope
) {
    private val _selectionState = MutableStateFlow(QuizSelectionState())
    val selectionState: StateFlow<QuizSelectionState> = _selectionState.asStateFlow()

    private val _sessionState = MutableStateFlow(QuizSessionState())
    val sessionState: StateFlow<QuizSessionState> = _sessionState.asStateFlow()

    private var quizTimerJob: Job? = null

    fun selectSubject(subjectId: String) {
        _selectionState.value = _selectionState.value.copy(
            selectedSubjectId = subjectId,
            selectedChapterNumber = null,
            bannerMessage = null
        )
    }

    fun selectChapter(chapterNumber: Int?) {
        _selectionState.value = _selectionState.value.copy(
            selectedChapterNumber = chapterNumber,
            bannerMessage = null
        )
    }

    fun selectMode(mode: QuizModeType) {
        _selectionState.value = _selectionState.value.copy(
            selectedMode = mode,
            bannerMessage = null
        )
    }

    fun setQuestionLimit(limit: Int) {
        _selectionState.value = _selectionState.value.copy(
            questionLimit = limit.coerceIn(3, 50),
            bannerMessage = null
        )
    }

    fun setDurationMinutes(minutes: Int) {
        _selectionState.value = _selectionState.value.copy(
            customDurationMinutes = minutes.coerceIn(1, 90),
            bannerMessage = null
        )
    }

    fun clearBannerMessage() {
        _selectionState.value = _selectionState.value.copy(bannerMessage = null)
    }

    fun setBannerMessage(message: String) {
        _selectionState.value = _selectionState.value.copy(bannerMessage = message)
    }

    fun availableBookCountForSubject(subjectId: String): Int =
        BookMcqSeedData.allBookPlayableMcqs().count { it.subjectId == subjectId }

    fun availableCountForChapter(
        subjectId: String,
        chapterNumber: Int,
        agentRaw: List<McqQuestionRecord>
    ): Int {
        val bookCount = BookMcqSeedData.allBookPlayableMcqs().count {
            it.subjectId == subjectId && it.chapterNumber == chapterNumber
        }
        val agentCount = agentRaw.count {
            it.subjectId == subjectId && it.chapterNumber.toInt() == chapterNumber
        }
        return bookCount + agentCount
    }

    fun startConfiguredQuiz(
        agentRaw: List<McqQuestionRecord>,
        isAuthenticated: Boolean,
        onTimeoutSubmit: () -> Unit
    ) {
        val sel = _selectionState.value
        if (sel.selectedMode == QuizModeType.AGENT_UPLOADED && !isAuthenticated) {
            setBannerMessage(
                "এজেন্ট কর্তৃক প্রকাশিত কুইজ দেখতে Google দিয়ে সাইন-ইন করুন, অথবা এখনই 'বইয়ের MCQ' ও 'র‍্যান্ডম কুইজ' খেলুন।"
            )
            return
        }

        val subjectInfo = SscSyllabusData.getSubject(sel.selectedSubjectId)
        val subjectName = subjectInfo?.nameBn ?: "সকল বিষয়"
        val selectedChapterInfo = sel.selectedChapterNumber?.let { chNum ->
            SscSyllabusData.getChapter(sel.selectedSubjectId, chNum)
        }

        val bookPool = BookMcqSeedData.allBookPlayableMcqs()
        val agentPool = agentRaw.map { it.toPlayableMcq() }
        val combinedPool = (agentPool + bookPool).distinctBy { it.question.trim() }

        val candidateQuestions: List<PlayableMcq> = when (sel.selectedMode) {
            QuizModeType.BOOK_MCQ -> {
                val subFiltered = bookPool.filter { it.subjectId == sel.selectedSubjectId }
                val chFiltered = sel.selectedChapterNumber?.let { chNum ->
                    subFiltered.filter { it.chapterNumber == chNum }
                }.orEmpty()
                if (chFiltered.isNotEmpty()) chFiltered else subFiltered
            }

            QuizModeType.AGENT_UPLOADED -> {
                val subFiltered = agentPool.filter { it.subjectId == sel.selectedSubjectId }
                val chFiltered = sel.selectedChapterNumber?.let { chNum ->
                    subFiltered.filter { it.chapterNumber == chNum }
                }.orEmpty()
                when {
                    chFiltered.isNotEmpty() -> chFiltered
                    subFiltered.isNotEmpty() -> subFiltered
                    else -> agentPool
                }
            }

            QuizModeType.RANDOM -> {
                combinedPool.shuffled()
            }

            QuizModeType.CHAPTER_WISE -> {
                val targetCh = sel.selectedChapterNumber ?: subjectInfo?.chapters?.firstOrNull()?.number
                if (targetCh != null) {
                    combinedPool.filter {
                        it.subjectId == sel.selectedSubjectId && it.chapterNumber == targetCh
                    }
                } else {
                    combinedPool.filter { it.subjectId == sel.selectedSubjectId }
                }
            }

            QuizModeType.FULL_SUBJECT -> {
                combinedPool.filter { it.subjectId == sel.selectedSubjectId }.shuffled()
            }

            QuizModeType.PRACTICE, QuizModeType.TIMED, QuizModeType.EXAM_MODE -> {
                val subFiltered = combinedPool.filter { it.subjectId == sel.selectedSubjectId }
                val chFiltered = sel.selectedChapterNumber?.let { chNum ->
                    subFiltered.filter { it.chapterNumber == chNum }
                }.orEmpty()
                when {
                    chFiltered.isNotEmpty() -> chFiltered
                    subFiltered.isNotEmpty() -> subFiltered
                    else -> combinedPool.shuffled()
                }
            }
        }

        if (candidateQuestions.isEmpty()) {
            val notice = when (sel.selectedMode) {
                QuizModeType.AGENT_UPLOADED ->
                    "এই মুহূর্তে কোনো প্রকাশিত এজেন্ট MCQ পাওয়া যায়নি। এজেন্ট প্যানেল থেকে প্রশ্ন প্রকাশ করুন অথবা 'বইয়ের MCQ' ব্যবহার করুন।"
                QuizModeType.CHAPTER_WISE ->
                    "নির্বাচিত অধ্যায়ে এখনো কোনো MCQ যোগ করা হয়নি। সংখ্যা-চিহ্নিত অধ্যায় বেছে নিন অথবা 'পূর্ণ বিষয়' মোডে কুইজ দিন।"
                else ->
                    "নির্বাচিত বিষয়ের জন্য কোনো MCQ পাওয়া যায়নি। অনুগ্রহ করে অন্য বিষয় বা মোড নির্বাচন করুন।"
            }
            setBannerMessage(notice)
            return
        }

        val effectiveLimit = if (sel.selectedMode == QuizModeType.FULL_SUBJECT) {
            maxOf(sel.questionLimit, 25)
        } else {
            sel.questionLimit
        }
        val selectedList = candidateQuestions.take(effectiveLimit)
        val chapterLabel = selectedChapterInfo?.title ?: "সকল অধ্যায়"
        val modeTitle = "${sel.selectedMode.labelBn} • $subjectName"

        launchSession(
            quizId = "mode_${sel.selectedMode.wireKey}_${sel.selectedSubjectId}",
            quizTitle = modeTitle,
            mode = sel.selectedMode,
            subjectId = if (sel.selectedMode == QuizModeType.RANDOM) "all" else sel.selectedSubjectId,
            subjectName = if (sel.selectedMode == QuizModeType.RANDOM) "সকল বিষয় (মিশ্র)" else subjectName,
            chapterTitle = chapterLabel,
            questions = selectedList,
            durationMinutes = sel.customDurationMinutes,
            onTimeoutSubmit = onTimeoutSubmit
        )
    }

    fun launchSession(
        quizId: String,
        quizTitle: String,
        mode: QuizModeType,
        subjectId: String,
        subjectName: String,
        chapterTitle: String,
        questions: List<PlayableMcq>,
        durationMinutes: Int,
        onTimeoutSubmit: () -> Unit
    ) {
        quizTimerJob?.cancel()
        val totalSec = durationMinutes * 60
        val isCountdownMode = mode == QuizModeType.TIMED || mode == QuizModeType.EXAM_MODE

        _sessionState.value = QuizSessionState(
            isActive = true,
            quizId = quizId,
            quizTitle = quizTitle,
            mode = mode,
            subjectId = subjectId,
            subjectName = subjectName,
            chapterTitle = chapterTitle,
            questions = questions,
            currentIndex = 0,
            selectedAnswers = emptyMap(),
            revealedPracticeIndices = emptySet(),
            totalDurationSeconds = totalSec,
            remainingSeconds = totalSec,
            elapsedSeconds = 0,
            isSubmitted = false,
            isSavingAttempt = false,
            saveStatusMessage = null
        )

        quizTimerJob = scope.launch {
            while (_sessionState.value.isActive && !_sessionState.value.isSubmitted) {
                delay(1000L)
                val curr = _sessionState.value
                if (!curr.isActive || curr.isSubmitted) break
                val nextElapsed = curr.elapsedSeconds + 1
                if (isCountdownMode) {
                    val nextRem = (curr.remainingSeconds - 1).coerceAtLeast(0)
                    _sessionState.value = curr.copy(
                        elapsedSeconds = nextElapsed,
                        remainingSeconds = nextRem
                    )
                    if (nextRem == 0) {
                        onTimeoutSubmit()
                        break
                    }
                } else {
                    _sessionState.value = curr.copy(elapsedSeconds = nextElapsed)
                }
            }
        }
    }

    fun selectAnswer(questionIndex: Int, optionIndex: Int) {
        val curr = _sessionState.value
        if (!curr.isActive || curr.isSubmitted) return
        if (questionIndex !in curr.questions.indices) return
        if (curr.mode == QuizModeType.PRACTICE && questionIndex in curr.revealedPracticeIndices) return

        val nextAnswers = curr.selectedAnswers.toMutableMap().apply {
            this[questionIndex] = optionIndex
        }
        val nextRevealed = if (curr.mode == QuizModeType.PRACTICE) {
            curr.revealedPracticeIndices + questionIndex
        } else {
            curr.revealedPracticeIndices
        }
        _sessionState.value = curr.copy(
            selectedAnswers = nextAnswers,
            revealedPracticeIndices = nextRevealed
        )
    }

    fun goToQuestion(index: Int) {
        val curr = _sessionState.value
        if (index in curr.questions.indices) {
            _sessionState.value = curr.copy(currentIndex = index)
        }
    }

    fun nextQuestion() {
        val curr = _sessionState.value
        if (curr.currentIndex + 1 < curr.questions.size) {
            _sessionState.value = curr.copy(currentIndex = curr.currentIndex + 1)
        }
    }

    fun previousQuestion() {
        val curr = _sessionState.value
        if (curr.currentIndex > 0) {
            _sessionState.value = curr.copy(currentIndex = curr.currentIndex - 1)
        }
    }

    fun evaluateAndMarkSubmitted(
        userId: String,
        isSavingToCloud: Boolean,
        initialStatusMessage: String?,
        onRecordMistake: ((
            subjectName: String,
            chapterTitle: String,
            question: String,
            studentAnswer: String,
            correctAnswer: String,
            explanation: String
        ) -> Unit)?
    ): QuizAttemptRecord? {
        val curr = _sessionState.value
        if (!curr.isActive || curr.isSubmitted || curr.questions.isEmpty()) return null

        quizTimerJob?.cancel()

        var correctCount = 0
        val answerItems = curr.questions.mapIndexed { idx, mcq ->
            val selected = curr.selectedAnswers[idx] ?: -1
            val isCorrect = selected == mcq.correctIndex
            if (isCorrect) {
                correctCount++
            } else {
                val studentAnsText = if (selected in mcq.options.indices) {
                    mcq.options[selected]
                } else {
                    "উত্তর দেওয়া হয়নি"
                }
                val correctAnsText = mcq.options.getOrElse(mcq.correctIndex) { "" }
                onRecordMistake?.invoke(
                    mcq.subjectName,
                    mcq.chapterTitle,
                    mcq.question,
                    studentAnsText,
                    correctAnsText,
                    mcq.explanation
                )
            }
            AttemptAnswerItem(
                mcqId = mcq.id,
                question = mcq.question,
                options = mcq.options,
                selectedIndex = selected.toLong(),
                correctIndex = mcq.correctIndex.toLong(),
                isCorrect = isCorrect,
                explanation = mcq.explanation
            )
        }

        val total = curr.questions.size
        val accuracy = (correctCount.toDouble() / total.toDouble()) * 100.0

        _sessionState.value = curr.copy(
            isSubmitted = true,
            isSavingAttempt = isSavingToCloud,
            score = correctCount,
            accuracyPercent = accuracy,
            saveStatusMessage = initialStatusMessage
        )

        return QuizAttemptRecord(
            userId = userId,
            quizId = curr.quizId,
            quizTitle = curr.quizTitle,
            quizType = curr.mode.wireKey,
            subjectId = curr.subjectId,
            subjectName = curr.subjectName,
            chapterTitle = curr.chapterTitle,
            score = correctCount.toLong(),
            totalQuestions = total.toLong(),
            accuracyPercent = accuracy,
            timeTakenSeconds = curr.elapsedSeconds.toLong().coerceAtLeast(1L),
            examMode = curr.mode == QuizModeType.EXAM_MODE,
            answers = answerItems
        )
    }

    fun updateSaveStatus(isSaving: Boolean, message: String?) {
        _sessionState.value = _sessionState.value.copy(
            isSavingAttempt = isSaving,
            saveStatusMessage = message
        )
    }

    fun closeSession() {
        quizTimerJob?.cancel()
        _sessionState.value = QuizSessionState()
    }

    fun cancelTimers() {
        quizTimerJob?.cancel()
    }
}
