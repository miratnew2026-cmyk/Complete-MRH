package com.example.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.OcrQuestionExtractor
import com.example.data.model.AgentAccount
import com.example.data.model.McqQuestionRecord
import com.example.data.model.McqUploadRecord
import com.example.data.model.QuizCollectionRecord
import com.example.data.model.RemoteUiState
import com.example.data.model.SscSyllabusData
import com.example.data.remote.QuizAgentRepository
import com.example.data.remote.unwrapFirestoreException
import com.example.data.remote.userFriendlyFirestoreMessage
import com.example.ui.components.TextbookMathFormatter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AgentActionStatus(
    val isBusy: Boolean = false,
    val busyLabel: String = "",
    val message: String? = null,
    val isError: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class AgentViewModel(
    private val repository: QuizAgentRepository,
    private val ocrExtractor: OcrQuestionExtractor,
    val currentUserId: String,
    val currentUserEmail: String,
    val currentDisplayName: String,
    val isBootstrappedAdmin: Boolean
) : ViewModel() {

    val myAgentAccount: StateFlow<RemoteUiState<AgentAccount?>> =
        repository.observeAgentAccount(currentUserId)
            .map<AgentAccount?, RemoteUiState<AgentAccount?>> { account ->
                RemoteUiState.Success(account)
            }
            .catch { error ->
                val fsEx = error.unwrapFirestoreException()
                if (fsEx == null && error is CancellationException) throw error
                emit(
                    RemoteUiState.Error(
                        error.userFriendlyFirestoreMessage("এজেন্ট প্রোফাইল যাচাই করা যায়নি।")
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    val isAuthorizedAgent: StateFlow<Boolean> =
        myAgentAccount
            .map { state ->
                if (isBootstrappedAdmin) {
                    true
                } else {
                    val account = (state as? RemoteUiState.Success)?.data
                    account != null && account.active && account.role == "agent"
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = isBootstrappedAdmin
            )

    val agentMcqs: StateFlow<RemoteUiState<List<McqQuestionRecord>>> =
        isAuthorizedAgent
            .flatMapLatest { authorized ->
                if (!authorized) {
                    flowOf<RemoteUiState<List<McqQuestionRecord>>>(RemoteUiState.Success(emptyList()))
                } else {
                    val sourceFlow = if (isBootstrappedAdmin) {
                        repository.observeAllMcqsAdmin()
                    } else {
                        repository.observeAgentMcqs(currentUserId)
                    }
                    sourceFlow
                        .map<List<McqQuestionRecord>, RemoteUiState<List<McqQuestionRecord>>> { RemoteUiState.Success(it) }
                        .catch { error ->
                            val fsEx = error.unwrapFirestoreException()
                            if (fsEx == null && error is CancellationException) throw error
                            emit(RemoteUiState.Error(error.userFriendlyFirestoreMessage("MCQ তালিকা লোড করা যায়নি।")))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    val pendingReviewMcqs: StateFlow<List<McqQuestionRecord>> =
        agentMcqs
            .map { state ->
                val list = (state as? RemoteUiState.Success)?.data.orEmpty()
                list.filter { !it.ocrReviewed || it.status == "pending_review" }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    val agentQuizzes: StateFlow<RemoteUiState<List<QuizCollectionRecord>>> =
        isAuthorizedAgent
            .flatMapLatest { authorized ->
                if (!authorized) {
                    flowOf<RemoteUiState<List<QuizCollectionRecord>>>(RemoteUiState.Success(emptyList()))
                } else {
                    val sourceFlow = if (isBootstrappedAdmin) {
                        repository.observeAllQuizzesAdmin()
                    } else {
                        repository.observeAgentQuizzes(currentUserId)
                    }
                    sourceFlow
                        .map<List<QuizCollectionRecord>, RemoteUiState<List<QuizCollectionRecord>>> { RemoteUiState.Success(it) }
                        .catch { error ->
                            val fsEx = error.unwrapFirestoreException()
                            if (fsEx == null && error is CancellationException) throw error
                            emit(RemoteUiState.Error(error.userFriendlyFirestoreMessage("কুইজ তালিকা লোড করা যায়নি।")))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    val agentUploads: StateFlow<RemoteUiState<List<McqUploadRecord>>> =
        isAuthorizedAgent
            .flatMapLatest { authorized ->
                if (!authorized) {
                    flowOf<RemoteUiState<List<McqUploadRecord>>>(RemoteUiState.Success(emptyList()))
                } else {
                    val sourceFlow = if (isBootstrappedAdmin) {
                        repository.observeAllUploadsAdmin()
                    } else {
                        repository.observeAgentUploads(currentUserId)
                    }
                    sourceFlow
                        .map<List<McqUploadRecord>, RemoteUiState<List<McqUploadRecord>>> { RemoteUiState.Success(it) }
                        .catch { error ->
                            val fsEx = error.unwrapFirestoreException()
                            if (fsEx == null && error is CancellationException) throw error
                            emit(RemoteUiState.Error(error.userFriendlyFirestoreMessage("আপলোড তালিকা লোড করা যায়নি।")))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = RemoteUiState.Loading
            )

    val allAgents: StateFlow<RemoteUiState<List<AgentAccount>>> =
        if (!isBootstrappedAdmin) {
            MutableStateFlow(RemoteUiState.Success(emptyList()))
        } else {
            repository.observeAllAgents()
                .map<List<AgentAccount>, RemoteUiState<List<AgentAccount>>> { RemoteUiState.Success(it) }
                .catch { error ->
                    val fsEx = error.unwrapFirestoreException()
                    if (fsEx == null && error is CancellationException) throw error
                    emit(RemoteUiState.Error(error.userFriendlyFirestoreMessage("এজেন্ট তালিকা লোড করা যায়নি।")))
                }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000L),
                    initialValue = RemoteUiState.Loading
                )
        }

    private val _actionStatus = MutableStateFlow(AgentActionStatus())
    val actionStatus: StateFlow<AgentActionStatus> = _actionStatus.asStateFlow()

    init {
        if (isBootstrappedAdmin) {
            viewModelScope.launch {
                repository.ensureBootstrappedAgentProfile(
                    username = "Mr1122",
                    displayName = currentDisplayName.ifBlank { "MRH Primary Agent" },
                    email = currentUserEmail
                )
            }
        }
    }

    fun clearStatusMessage() {
        _actionStatus.value = _actionStatus.value.copy(message = null, isError = false)
    }

    private fun setBusy(label: String) {
        _actionStatus.value = AgentActionStatus(isBusy = true, busyLabel = label)
    }

    private fun setSuccess(message: String) {
        _actionStatus.value = AgentActionStatus(isBusy = false, message = message, isError = false)
    }

    private fun setFailure(message: String) {
        _actionStatus.value = AgentActionStatus(isBusy = false, message = message, isError = true)
    }

    // --- 1. Manual & Book MCQ CRUD ---

    fun saveManualOrBookMcq(
        editingMcqId: String? = null,
        subjectId: String,
        chapterNumber: Int,
        question: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctIndex: Int,
        explanation: String,
        difficulty: String,
        sourceType: String,
        publishNow: Boolean,
        onComplete: () -> Unit = {}
    ) {
        val cleanQuestion = TextbookMathFormatter.format(question.trim())
        val cleanOptions = listOf(optionA, optionB, optionC, optionD).map {
            TextbookMathFormatter.format(it.trim())
        }
        val cleanExplanation = TextbookMathFormatter.format(explanation.trim())

        if (cleanQuestion.isBlank() || cleanOptions.any { it.isBlank() }) {
            setFailure("প্রশ্ন এবং ৪টি অপশন অবশ্যই পূরণ করতে হবে।")
            return
        }

        val subject = SscSyllabusData.getSubject(subjectId)
        val chapter = SscSyllabusData.getChapter(subjectId, chapterNumber)
        val cleanSubjectName = subject?.nameBn ?: "সাধারণ গণিত"
        val cleanChapterTitle = chapter?.title ?: "অধ্যায় $chapterNumber"
        val finalSourceType = if (sourceType == "book") "book" else "manual"
        val targetStatus = if (publishNow) "published" else "draft"

        viewModelScope.launch {
            setBusy("MCQ সংরক্ষণ করা হচ্ছে...")
            if (editingMcqId.isNullOrBlank()) {
                val record = McqQuestionRecord(
                    subjectId = subjectId,
                    subjectName = cleanSubjectName,
                    chapterNumber = chapterNumber.toLong(),
                    chapterTitle = cleanChapterTitle,
                    question = cleanQuestion,
                    options = cleanOptions,
                    correctIndex = correctIndex.coerceIn(0, 3).toLong(),
                    explanation = cleanExplanation,
                    difficulty = difficulty,
                    sourceType = finalSourceType,
                    ocrReviewed = true,
                    status = targetStatus,
                    createdBy = currentUserId
                )
                repository.createMcq(record).fold(
                    onSuccess = {
                        setSuccess(
                            if (publishNow) "MCQ সফলভাবে প্রকাশিত হয়েছে।" else "MCQ ড্রাফট হিসেবে সেভ হয়েছে।"
                        )
                        onComplete()
                    },
                    onFailure = { err ->
                        setFailure(err.userFriendlyFirestoreMessage("MCQ সংরক্ষণ করা যায়নি।"))
                    }
                )
            } else {
                val existing = (agentMcqs.value as? RemoteUiState.Success)?.data?.find { it.id == editingMcqId }
                val updated = McqQuestionRecord(
                    id = editingMcqId,
                    subjectId = subjectId,
                    subjectName = cleanSubjectName,
                    chapterNumber = chapterNumber.toLong(),
                    chapterTitle = cleanChapterTitle,
                    question = cleanQuestion,
                    options = cleanOptions,
                    correctIndex = correctIndex.coerceIn(0, 3).toLong(),
                    explanation = cleanExplanation,
                    difficulty = difficulty,
                    sourceType = existing?.sourceType ?: finalSourceType,
                    sourceFileUrl = existing?.sourceFileUrl ?: "",
                    sourceStoragePath = existing?.sourceStoragePath ?: "",
                    ocrReviewed = true,
                    status = targetStatus,
                    quizId = existing?.quizId ?: "",
                    createdBy = existing?.createdBy ?: currentUserId
                )
                repository.updateMcq(updated).fold(
                    onSuccess = {
                        setSuccess("MCQ সফলভাবে আপডেট হয়েছে।")
                        onComplete()
                    },
                    onFailure = { err ->
                        setFailure(err.userFriendlyFirestoreMessage("MCQ আপডেট করা যায়নি।"))
                    }
                )
            }
        }
    }

    fun deleteMcq(mcqId: String) {
        viewModelScope.launch {
            setBusy("MCQ মুছে ফেলা হচ্ছে...")
            repository.deleteMcq(mcqId).fold(
                onSuccess = { setSuccess("MCQ সফলভাবে ডিলিট হয়েছে।") },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("MCQ ডিলিট করা যায়নি।"))
                }
            )
        }
    }

    // --- 2. OCR Upload Pipeline (Image & PDF) — Strictly unreviewed until agent confirms ---

    fun processImageUpload(uri: Uri, subjectId: String, chapterNumber: Int) {
        val subjectName = SscSyllabusData.getSubject(subjectId)?.nameBn ?: "সাধারণ গণিত"
        val chapterTitle = SscSyllabusData.getChapter(subjectId, chapterNumber)?.title ?: "অধ্যায় $chapterNumber"

        viewModelScope.launch {
            setBusy("ছবি থেকে OCR-এর মাধ্যমে প্রশ্ন বের করা হচ্ছে...")
            val extractResult = ocrExtractor.extractFromImageUri(uri, subjectName, chapterTitle)
            extractResult.fold(
                onSuccess = { outcome ->
                    saveOcrOutcome(outcome, subjectId, subjectName, chapterNumber, chapterTitle, "ocr_image")
                },
                onFailure = { err ->
                    setFailure(err.localizedMessage ?: "ছবি OCR ব্যর্থ হয়েছে।")
                }
            )
        }
    }

    fun processPdfUpload(uri: Uri, subjectId: String, chapterNumber: Int) {
        val subjectName = SscSyllabusData.getSubject(subjectId)?.nameBn ?: "সাধারণ গণিত"
        val chapterTitle = SscSyllabusData.getChapter(subjectId, chapterNumber)?.title ?: "অধ্যায় $chapterNumber"

        viewModelScope.launch {
            setBusy("PDF প্রশ্নপত্র থেকে OCR বিশ্লেষণ চলছে (সর্বোচ্চ ৬ পৃষ্ঠা)...")
            val extractResult = ocrExtractor.extractFromPdfUri(uri, subjectName, chapterTitle)
            extractResult.fold(
                onSuccess = { outcome ->
                    saveOcrOutcome(outcome, subjectId, subjectName, chapterNumber, chapterTitle, "ocr_pdf")
                },
                onFailure = { err ->
                    setFailure(err.localizedMessage ?: "PDF OCR ব্যর্থ হয়েছে।")
                }
            )
        }
    }

    private suspend fun saveOcrOutcome(
        outcome: com.example.data.ai.OcrExtractionOutcome,
        subjectId: String,
        subjectName: String,
        chapterNumber: Int,
        chapterTitle: String,
        sourceType: String
    ) {
        setBusy("ফাইল আর্কাইভ ও পেন্ডিং রিভিউ কিউতে সংরক্ষণ করা হচ্ছে...")
        val storageResult = repository.uploadMediaBytesToStorage(
            fileName = outcome.fileName,
            bytes = outcome.fileBytes,
            mimeType = outcome.mimeType
        )
        val (storagePath, downloadUrl, storageSynced) = storageResult.fold(
            onSuccess = { (path, url) -> Triple(path, url, true) },
            onFailure = { Triple("", "", false) }
        )

        val uploadRecord = McqUploadRecord(
            createdBy = currentUserId,
            fileName = outcome.fileName,
            fileType = outcome.fileType,
            storagePath = storagePath,
            downloadUrl = downloadUrl,
            subjectId = subjectId,
            subjectName = subjectName,
            chapterNumber = chapterNumber.toLong(),
            chapterTitle = chapterTitle,
            extractedCount = outcome.draftQuestions.size.toLong(),
            reviewedCount = 0L,
            ocrStatus = "pending_review",
            storageSynced = storageSynced
        )
        repository.createUploadRecord(uploadRecord)

        var savedCount = 0
        outcome.draftQuestions.forEach { draft ->
            val pendingMcq = McqQuestionRecord(
                subjectId = subjectId,
                subjectName = subjectName,
                chapterNumber = chapterNumber.toLong(),
                chapterTitle = chapterTitle,
                question = draft.question,
                options = draft.options,
                correctIndex = draft.correctIndex.coerceIn(0, 3).toLong(),
                explanation = draft.explanation,
                difficulty = draft.difficulty,
                sourceType = sourceType,
                sourceFileUrl = downloadUrl,
                sourceStoragePath = storagePath,
                ocrReviewed = false,
                status = "pending_review",
                createdBy = currentUserId
            )
            if (repository.createMcq(pendingMcq).isSuccess) {
                savedCount++
            }
        }

        val storageHint = if (!storageSynced) {
            " (নোট: Firebase Storage বাকেট সক্রিয় না থাকায় মূল ফাইল ব্যাকআপ বাদ দেওয়া হয়েছে, তবে প্রশ্নগুলো নিরাপদ রয়েছে)"
        } else {
            ""
        }
        setSuccess(
            "${outcome.pageCountProcessed}টি পৃষ্ঠা থেকে $savedCount টি OCR প্রশ্ন 'রিভিউ কিউ'-তে যুক্ত হয়েছে। যাচাই ও অনুমোদন না করা পর্যন্ত এগুলো পাবলিশ হবে না।$storageHint"
        )
    }

    // --- 3. Mandatory OCR Review Queue ---

    fun approveOcrMcq(
        originalMcq: McqQuestionRecord,
        subjectId: String,
        chapterNumber: Int,
        question: String,
        options: List<String>,
        correctIndex: Int,
        explanation: String,
        difficulty: String,
        publishNow: Boolean
    ) {
        val cleanQuestion = TextbookMathFormatter.format(question.trim())
        val cleanOptions = options.take(4).map { TextbookMathFormatter.format(it.trim()) }
        val cleanExplanation = TextbookMathFormatter.format(explanation.trim())

        if (cleanQuestion.isBlank() || cleanOptions.size != 4 || cleanOptions.any { it.isBlank() }) {
            setFailure("সংশোধিত প্রশ্ন ও ৪টি অপশন খালি রাখা যাবে না।")
            return
        }

        val subjectName = SscSyllabusData.getSubject(subjectId)?.nameBn ?: originalMcq.subjectName
        val chapterTitle = SscSyllabusData.getChapter(subjectId, chapterNumber)?.title ?: originalMcq.chapterTitle

        viewModelScope.launch {
            setBusy("OCR প্রশ্ন অনুমোদন করা হচ্ছে...")
            val updated = originalMcq.copy(
                subjectId = subjectId,
                subjectName = subjectName,
                chapterNumber = chapterNumber.toLong(),
                chapterTitle = chapterTitle,
                question = cleanQuestion,
                options = cleanOptions,
                correctIndex = correctIndex.coerceIn(0, 3).toLong(),
                explanation = cleanExplanation,
                difficulty = difficulty,
                ocrReviewed = true,
                status = if (publishNow) "published" else "draft"
            )
            repository.updateMcq(updated).fold(
                onSuccess = {
                    setSuccess(
                        if (publishNow) "OCR প্রশ্ন যাচাই ও পাবলিশ সম্পন্ন হয়েছে!" else "OCR প্রশ্ন যাচাই করে ড্রাফটে রাখা হয়েছে।"
                    )
                },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("প্রশ্নটি অনুমোদন করা যায়নি।"))
                }
            )
        }
    }

    // --- 4. Quiz Collection Builder (Create / Edit / Publish / Draft / Delete) ---

    fun saveQuizCollection(
        editingQuizId: String? = null,
        title: String,
        description: String,
        subjectId: String,
        chapterNumber: Int,
        quizType: String,
        difficulty: String,
        durationMinutes: Long,
        selectedMcqIds: List<String>,
        publishNow: Boolean,
        onComplete: () -> Unit = {}
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) {
            setFailure("কুইজের শিরোনাম লিখুন।")
            return
        }

        val reviewedPoolIds = (agentMcqs.value as? RemoteUiState.Success)?.data
            ?.filter { it.ocrReviewed && it.status != "pending_review" }
            ?.map { it.id }
            ?.toSet()
            ?: emptySet()

        val validIds = selectedMcqIds.distinct().filter { it in reviewedPoolIds }
        if (validIds.isEmpty()) {
            setFailure("কুইজ তৈরি করতে অন্তত ১টি যাচাইকৃত (Reviewed) MCQ নির্বাচন করুন।")
            return
        }

        val subjectName = SscSyllabusData.getSubject(subjectId)?.nameBn ?: "সকল বিষয়"
        val chapterTitle = if (chapterNumber > 0) {
            SscSyllabusData.getChapter(subjectId, chapterNumber)?.title ?: "অধ্যায় $chapterNumber"
        } else {
            "সমন্বিত অধ্যায়"
        }

        val targetStatus = if (publishNow) "published" else "draft"
        val cleanDuration = durationMinutes.coerceIn(1L, 180L)

        viewModelScope.launch {
            setBusy("কুইজ সংরক্ষণ করা হচ্ছে...")
            if (editingQuizId.isNullOrBlank()) {
                val record = QuizCollectionRecord(
                    title = cleanTitle,
                    description = description.trim(),
                    subjectId = subjectId,
                    subjectName = subjectName,
                    chapterNumber = chapterNumber.toLong(),
                    chapterTitle = chapterTitle,
                    quizType = quizType,
                    difficulty = difficulty,
                    durationMinutes = cleanDuration,
                    mcqIds = validIds,
                    questionCount = validIds.size.toLong(),
                    status = targetStatus,
                    createdBy = currentUserId,
                    createdByName = currentDisplayName.ifBlank { "Mr1122 Agent" }
                )
                repository.createQuiz(record).fold(
                    onSuccess = {
                        setSuccess(
                            if (publishNow) "কুইজটি শিক্ষার্থীদের জন্য প্রকাশিত হয়েছে।" else "কুইজ ড্রাফট হিসেবে সংরক্ষিত হয়েছে।"
                        )
                        onComplete()
                    },
                    onFailure = { err ->
                        setFailure(err.userFriendlyFirestoreMessage("কুইজ তৈরি করা যায়নি।"))
                    }
                )
            } else {
                val existing = (agentQuizzes.value as? RemoteUiState.Success)?.data?.find { it.id == editingQuizId }
                val updated = QuizCollectionRecord(
                    id = editingQuizId,
                    title = cleanTitle,
                    description = description.trim(),
                    subjectId = subjectId,
                    subjectName = subjectName,
                    chapterNumber = chapterNumber.toLong(),
                    chapterTitle = chapterTitle,
                    quizType = quizType,
                    difficulty = difficulty,
                    durationMinutes = cleanDuration,
                    mcqIds = validIds,
                    questionCount = validIds.size.toLong(),
                    status = targetStatus,
                    createdBy = existing?.createdBy ?: currentUserId,
                    createdByName = existing?.createdByName ?: currentDisplayName.ifBlank { "Mr1122 Agent" }
                )
                repository.updateQuiz(updated).fold(
                    onSuccess = {
                        setSuccess("কুইজ সফলভাবে আপডেট করা হয়েছে।")
                        onComplete()
                    },
                    onFailure = { err ->
                        setFailure(err.userFriendlyFirestoreMessage("কুইজ আপডেট করা যায়নি।"))
                    }
                )
            }
        }
    }

    fun toggleQuizPublishStatus(quiz: QuizCollectionRecord) {
        val nextStatus = if (quiz.status == "published") "draft" else "published"
        viewModelScope.launch {
            setBusy("স্ট্যাটাস পরিবর্তন করা হচ্ছে...")
            repository.updateQuiz(quiz.copy(status = nextStatus)).fold(
                onSuccess = {
                    setSuccess(
                        if (nextStatus == "published") "কুইজ পাবলিশ করা হয়েছে।" else "কুইজ ড্রাফটে ফিরিয়ে নেওয়া হয়েছে।"
                    )
                },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("কুইজের স্ট্যাটাস বদলানো যায়নি।"))
                }
            )
        }
    }

    fun deleteQuiz(quizId: String) {
        viewModelScope.launch {
            setBusy("কুইজ মুছে ফেলা হচ্ছে...")
            repository.deleteQuiz(quizId).fold(
                onSuccess = { setSuccess("কুইজটি ডিলিট করা হয়েছে।") },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("কুইজ ডিলিট করা যায়নি।"))
                }
            )
        }
    }

    // --- 5. Role-Based Agent Delegation (Bootstrapped Admin Only) ---

    fun upsertAgentRole(
        targetUid: String,
        username: String,
        displayName: String,
        email: String,
        active: Boolean
    ) {
        if (!isBootstrappedAdmin) {
            setFailure("শুধুমাত্র প্রাইমারি অ্যাডমিন এজেন্ট অ্যাক্সেস পরিচালনা করতে পারেন।")
            return
        }
        val cleanUid = targetUid.trim()
        val cleanUsername = username.trim()
        if (cleanUid.isBlank() || cleanUsername.isBlank()) {
            setFailure("Agent UID এবং Username অবশ্যই পূরণ করতে হবে।")
            return
        }
        viewModelScope.launch {
            setBusy("এজেন্ট অনুমতি আপডেট হচ্ছে...")
            repository.upsertAgentRole(
                targetUid = cleanUid,
                username = cleanUsername,
                displayName = displayName.trim().ifBlank { cleanUsername },
                email = email.trim(),
                active = active
            ).fold(
                onSuccess = { setSuccess("এজেন্ট অনুমতি সফলভাবে সংরক্ষিত হয়েছে।") },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("এজেন্ট অনুমতি সেভ করা যায়নি।"))
                }
            )
        }
    }

    fun deleteAgentRole(targetUid: String) {
        if (!isBootstrappedAdmin) return
        if (targetUid == currentUserId) {
            setFailure("নিজের প্রাইমারি অ্যাডমিন প্রোফাইল ডিলিট করা যাবে না।")
            return
        }
        viewModelScope.launch {
            setBusy("এজেন্ট অ্যাক্সেস বাতিল করা হচ্ছে...")
            repository.deleteAgentRole(targetUid).fold(
                onSuccess = { setSuccess("এজেন্ট অ্যাক্সেস বাতিল করা হয়েছে।") },
                onFailure = { err ->
                    setFailure(err.userFriendlyFirestoreMessage("এজেন্ট ডিলিট করা যায়নি।"))
                }
            )
        }
    }
}
