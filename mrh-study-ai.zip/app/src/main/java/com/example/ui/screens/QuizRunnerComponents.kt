package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizModeType
import com.example.ui.components.CyberCard
import com.example.ui.components.TextbookMathFormatter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.AppFontFamily
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.QuizSessionState
import java.util.Locale

private val optionLabelsBn = listOf("ক", "খ", "গ", "ঘ")

@Composable
fun QuizActiveRunnerScreen(
    session: QuizSessionState,
    onSelectAnswer: (questionIndex: Int, optionIndex: Int) -> Unit,
    onGoToQuestion: (index: Int) -> Unit,
    onPreviousQuestion: () -> Unit,
    onNextQuestion: () -> Unit,
    onSubmitQuiz: () -> Unit,
    onCloseSession: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }

    BackHandler {
        if (session.isSubmitted) {
            onCloseSession()
        } else {
            showExitConfirm = true
        }
    }

    if (session.isSubmitted) {
        QuizResultsReviewScreen(
            session = session,
            onDone = onCloseSession
        )
        return
    }

    val isCountdown = session.mode == QuizModeType.TIMED || session.mode == QuizModeType.EXAM_MODE
    val displaySec = if (isCountdown) session.remainingSeconds else session.elapsedSeconds
    val minutes = displaySec / 60
    val seconds = displaySec % 60
    val timerText = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    val timerColor = when {
        isCountdown && session.remainingSeconds <= 60 -> NeonPink
        isCountdown -> AmberGold
        else -> NeonCyan
    }

    val currentMcq = session.questions.getOrNull(session.currentIndex)
    val selectedForCurrent = session.selectedAnswers[session.currentIndex]
    val isRevealedPractice = session.mode == QuizModeType.PRACTICE &&
        session.currentIndex in session.revealedPracticeIndices
    val answeredCount = session.selectedAnswers.size
    val totalCount = session.questions.size

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Top Runner Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = { showExitConfirm = true },
                        modifier = Modifier.testTag("close_active_quiz_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "কুইজ বন্ধ করুন",
                            tint = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = session.quizTitle,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1
                        )
                        Text(
                            text = "প্রশ্ন ${session.currentIndex + 1}/$totalCount • উত্তর দেওয়া: $answeredCount/$totalCount",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceVariant)
                        .border(1.dp, timerColor.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = "Timer",
                            tint = timerColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = timerText,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = timerColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { if (totalCount > 0) (session.currentIndex + 1f) / totalCount.toFloat() else 0f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = NeonCyan,
                trackColor = DarkSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Question Jump Palette
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                session.questions.indices.forEach { idx ->
                    val isCurrent = idx == session.currentIndex
                    val hasAns = session.selectedAnswers.containsKey(idx)
                    val bgColor = when {
                        isCurrent -> NeonCyan
                        hasAns -> Color(0xFF0E3A47)
                        else -> DarkSurfaceVariant
                    }
                    val txtColor = when {
                        isCurrent -> Color(0xFF031A24)
                        hasAns -> NeonCyan
                        else -> TextSecondary
                    }
                    Box(
                        modifier = Modifier
                            .size(width = 40.dp, height = 36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(bgColor)
                            .border(
                                1.dp,
                                if (isCurrent) NeonCyan else BorderGlow,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onGoToQuestion(idx) }
                            .testTag("quiz_nav_dot_$idx"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${idx + 1}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = txtColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Question Scroll Content
            if (currentMcq != null) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CyberCard(
                        borderBrush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.7f), NeonPurple.copy(alpha = 0.6f))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF0F2636))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${currentMcq.sourceBadge} • ${currentMcq.subjectName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NeonCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = currentMcq.difficulty.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = currentMcq.chapterTitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = TextbookMathFormatter.format(currentMcq.question),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                lineHeight = 25.sp,
                                fontFamily = AppFontFamily,
                                modifier = Modifier.testTag("quiz_question_text")
                            )
                        }
                    }

                    // Option Buttons
                    currentMcq.options.take(4).forEachIndexed { optIdx, optionText ->
                        val isSelected = selectedForCurrent == optIdx
                        val isCorrectOpt = optIdx == currentMcq.correctIndex

                        val containerBg = when {
                            isRevealedPractice && isCorrectOpt -> Color(0xFF093124)
                            isRevealedPractice && isSelected && !isCorrectOpt -> Color(0xFF33111E)
                            isSelected -> Color(0xFF0B2B3C)
                            else -> DarkSurface
                        }
                        val borderColor = when {
                            isRevealedPractice && isCorrectOpt -> EmeraldSuccess
                            isRevealedPractice && isSelected && !isCorrectOpt -> NeonPink
                            isSelected -> NeonCyan
                            else -> BorderGlow
                        }
                        val badgeColor = when {
                            isRevealedPractice && isCorrectOpt -> EmeraldSuccess
                            isRevealedPractice && isSelected && !isCorrectOpt -> NeonPink
                            isSelected -> NeonCyan
                            else -> TextSecondary
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSelectAnswer(session.currentIndex, optIdx) }
                                .testTag("quiz_option_$optIdx"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = containerBg),
                            border = BorderStroke(1.2.dp, borderColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(DarkSurfaceVariant)
                                        .border(1.dp, badgeColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = optionLabelsBn.getOrElse(optIdx) { "${optIdx + 1}" },
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeColor
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = TextbookMathFormatter.format(optionText),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = TextPrimary,
                                    fontFamily = AppFontFamily,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Practice Mode Instant Explanation Box
                    if (isRevealedPractice) {
                        val wasRight = selectedForCurrent == currentMcq.correctIndex
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("practice_explanation_box"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (wasRight) Color(0xFF07251B) else Color(0xFF1E1B30)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (wasRight) EmeraldSuccess else AmberGold
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = "Explanation",
                                        tint = if (wasRight) EmeraldSuccess else AmberGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (wasRight) "সঠিক উত্তর!" else "সঠিক উত্তর: (${optionLabelsBn.getOrElse(currentMcq.correctIndex) { "" }}) ${TextbookMathFormatter.format(currentMcq.options.getOrElse(currentMcq.correctIndex) { "" })}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (wasRight) EmeraldSuccess else AmberGold
                                    )
                                }
                                if (currentMcq.explanation.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = TextbookMathFormatter.format(currentMcq.explanation),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        fontFamily = AppFontFamily,
                                        lineHeight = 21.sp
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Navigation & Submit Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onPreviousQuestion,
                    enabled = session.currentIndex > 0,
                    border = BorderStroke(1.dp, BorderGlow),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("prev_question_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "পূর্ববর্তী",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("পূর্ববর্তী", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }

                if (session.currentIndex + 1 < totalCount) {
                    Button(
                        onClick = onNextQuestion,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("next_question_button")
                    ) {
                        Text("পরবর্তী", color = Color(0xFF031A24), fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "পরবর্তী",
                            tint = Color(0xFF031A24),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Button(
                        onClick = onSubmitQuiz,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .heightIn(min = 48.dp)
                            .testTag("submit_quiz_button")
                    ) {
                        Text(
                            text = "কুইজ জমা দিন ($answeredCount/$totalCount)",
                            color = Color(0xFF031A24),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (session.currentIndex + 1 < totalCount) {
                Spacer(modifier = Modifier.height(6.dp))
                TextButton(
                    onClick = onSubmitQuiz,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .testTag("early_submit_quiz_button")
                ) {
                    Text(
                        text = "সবশেষে না গিয়ে এখনই ফলাফল সাবমিট করুন",
                        color = NeonPurple,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = { showExitConfirm = false },
            containerColor = DarkSurface,
            title = {
                Text("কুইজ থেকে বের হতে চান?", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "এখন বের হলে বর্তমান কুইজের উত্তরগুলো সংরক্ষিত হবে না। আপনি চাইলে সাবমিট করে বের হতে পারেন।",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirm = false
                        onCloseSession()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                ) {
                    Text("বের হোন", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirm = false }) {
                    Text("থাকুন", color = NeonCyan)
                }
            }
        )
    }
}

@Composable
private fun QuizResultsReviewScreen(
    session: QuizSessionState,
    onDone: () -> Unit
) {
    val total = session.questions.size
    val accInt = session.accuracyPercent.toInt()
    val timeM = session.elapsedSeconds / 60
    val timeS = session.elapsedSeconds % 60
    val timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", timeM, timeS)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                CyberCard(
                    borderBrush = Brush.horizontalGradient(listOf(EmeraldSuccess, NeonCyan)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Score",
                            tint = AmberGold,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = session.quizTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${session.score} / $total",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan,
                            modifier = Modifier.testTag("quiz_result_score_text")
                        )
                        Text(
                            text = "নির্ভুলতা: $accInt% • সময় লেগেছে: $timeFormatted",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (session.isSavingAttempt) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ফলাফল ক্লাউডে সংরক্ষণ হচ্ছে...",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        } else if (!session.saveStatusMessage.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = session.saveStatusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onDone,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("finish_quiz_review_button")
                        ) {
                            Text(
                                text = "কুইজ হাবে ফিরে যান",
                                color = Color(0xFF031A24),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "প্রশ্নভিত্তিক ফলাফল ও ব্যাখ্যা",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            itemsIndexed(session.questions) { idx, mcq ->
                val userSel = session.selectedAnswers[idx] ?: -1
                val isCorrect = userSel == mcq.correctIndex
                val borderCol = if (isCorrect) EmeraldSuccess else NeonPink

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, borderCol.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "প্রশ্ন ${idx + 1} • ${mcq.chapterTitle}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = if (isCorrect) "✓ সঠিক" else "✗ ভুল",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = borderCol
                            )
                        }

                        Text(
                            text = TextbookMathFormatter.format(mcq.question),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            fontFamily = AppFontFamily
                        )

                        val userOptText = if (userSel in mcq.options.indices) {
                            "(${optionLabelsBn.getOrElse(userSel) { "" }}) ${TextbookMathFormatter.format(mcq.options[userSel])}"
                        } else {
                            "উত্তর দেওয়া হয়নি"
                        }
                        val correctOptText =
                            "(${optionLabelsBn.getOrElse(mcq.correctIndex) { "" }}) ${TextbookMathFormatter.format(mcq.options.getOrElse(mcq.correctIndex) { "" })}"

                        Text(
                            text = "আপনার উত্তর: $userOptText",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isCorrect) EmeraldSuccess else NeonPink
                        )
                        if (!isCorrect) {
                            Text(
                                text = "সঠিক উত্তর: $correctOptText",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                        }
                        if (mcq.explanation.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceVariant)
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "ব্যাখ্যা: ${TextbookMathFormatter.format(mcq.explanation)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontFamily = AppFontFamily,
                                    lineHeight = 19.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuizAttemptDetailDialog(
    attempt: QuizAttemptRecord,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Column {
                Text(
                    text = attempt.quizTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "স্কোর: ${attempt.score}/${attempt.totalQuestions} (${attempt.accuracyPercent.toInt()}%) • সময়: ${attempt.timeTakenSeconds} সে.",
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonCyan
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                attempt.answers.forEachIndexed { idx, item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                        border = BorderStroke(
                            1.dp,
                            if (item.isCorrect) EmeraldSuccess.copy(alpha = 0.6f) else NeonPink.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "প্রশ্ন ${idx + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                Icon(
                                    imageVector = if (item.isCorrect) Icons.Default.CheckCircle else Icons.Default.Close,
                                    contentDescription = if (item.isCorrect) "সঠিক" else "ভুল",
                                    tint = if (item.isCorrect) EmeraldSuccess else NeonPink,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = TextbookMathFormatter.format(item.question),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                fontFamily = AppFontFamily
                            )
                            val selIdx = item.selectedIndex.toInt()
                            val corrIdx = item.correctIndex.toInt()
                            val ansStr = if (selIdx in item.options.indices) {
                                TextbookMathFormatter.format(item.options[selIdx])
                            } else {
                                "উত্তর দেওয়া হয়নি"
                            }
                            Text(
                                text = "আপনার উত্তর: $ansStr",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (item.isCorrect) EmeraldSuccess else NeonPink
                            )
                            if (!item.isCorrect && corrIdx in item.options.indices) {
                                Text(
                                    text = "সঠিক: ${TextbookMathFormatter.format(item.options[corrIdx])}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (item.explanation.isNotBlank()) {
                                Text(
                                    text = "ব্যাখ্যা: ${TextbookMathFormatter.format(item.explanation)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontFamily = AppFontFamily
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
        }
    )
}
