package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Science
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChapterProgressEntity
import com.example.data.model.ChapterInfo
import com.example.data.model.SscSyllabusData
import com.example.data.model.SubjectInfo
import com.example.ui.components.ChapterNoteDialog
import com.example.ui.components.ChapterProgressBar
import com.example.ui.components.CyberCard
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

@Composable
fun SyllabusScreen(
    viewModel: MainViewModel,
    onAskAiAboutChapter: (String) -> Unit,
    onNavigateToMathPriority: () -> Unit = {},
    onNavigateToSciencePriority: () -> Unit = {},
    onNavigateToSocialIctPriority: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val chaptersProgress by viewModel.allChapters.collectAsState()
    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    var selectedCategory by remember { mutableStateOf("All") }
    val expandedSubjects = remember { mutableStateMapOf<String, Boolean>() }

    var editingChapter by remember { mutableStateOf<Pair<String, String>?>(null) } // id to current note
    var editingChapterTitle by remember { mutableStateOf("") }

    val filteredSubjects = when (selectedCategory) {
        "Science" -> SscSyllabusData.subjects.filter { it.category == "Science" }
        "Language" -> SscSyllabusData.subjects.filter { it.category == "Language" }
        "Compulsory" -> SscSyllabusData.subjects.filter { it.category == "Compulsory" }
        else -> SscSyllabusData.subjects
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.MenuBook,
                contentDescription = "Syllabus",
                tint = NeonCyan,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "এসএসসি ২০২৮ সিলেবাস",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "১২টি সম্পূর্ণ বিষয়ের অধ্যায়ভিত্তিক অগ্রগতি ও ব্যক্তিগত নোট",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Dedicated COMPLETE MRH Mathematics Priority Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("syllabus_math_priority_banner")
                .clip(RoundedCornerShape(14.dp))
                .clickable { onNavigateToMathPriority() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E33)),
            border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0284C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Math",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "COMPLETE MRH",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "⭐ গুরুত্বপূর্ণ",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "গণিত চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড (৩১টি অধ্যায়)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open",
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dedicated COMPLETE MRH Science Priority Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("syllabus_science_priority_banner")
                .clip(RoundedCornerShape(14.dp))
                .clickable { onNavigateToSciencePriority() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1931)),
            border = BorderStroke(
                1.dp,
                Brush.horizontalGradient(listOf(Color(0xFF38BDF8), Color(0xFFA855F7), Color(0xFF10B981)))
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF7C3AED)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = "Science",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "COMPLETE MRH",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "⭐ ৩১ গুরুত্বপূর্ণ",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "বিজ্ঞান চ্যাপ্টার প্রায়োরিটি ড্যাশবোর্ড (৩৯টি অধ্যায়)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open Science Priority",
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dedicated COMPLETE MRH Social Studies (BGS), Islam & ICT Priority Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("syllabus_social_ict_priority_banner")
                .clip(RoundedCornerShape(14.dp))
                .clickable { onNavigateToSocialIctPriority() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF091B30)),
            border = BorderStroke(
                1.dp,
                Brush.horizontalGradient(listOf(Color(0xFF38BDF8), Color(0xFF10B981), Color(0xFFA855F7)))
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF10B981)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "BGS Islam ICT",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "COMPLETE MRH",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "⭐ ২৪ গুরুত্বপূর্ণ",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "BGS, ইসলাম ও ICT ড্যাশবোর্ড (২৬টি অধ্যায়)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open BGS Islam ICT Priority",
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val categories = listOf(
                "All" to "সকল বিষয় (১২)",
                "Science" to "বিজ্ঞান বিভাগ (৫)",
                "Language" to "ভাষা ও সাহিত্য (৪)",
                "Compulsory" to "সাধারণ ও আবশ্যিক (৩)"
            )
            items(categories) { (key, label) ->
                FilterChip(
                    selected = selectedCategory == key,
                    onClick = { selectedCategory = key },
                    label = { Text(label, fontSize = 13.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonCyan,
                        selectedLabelColor = Color(0xFF031A24),
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = BorderGlow,
                        selectedBorderColor = NeonCyan,
                        enabled = true,
                        selected = selectedCategory == key
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Subjects List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredSubjects) { subject ->
                val subjectProgressEntities = chaptersProgress.filter { it.subjectId == subject.id }
                val completedCount = subjectProgressEntities.count { it.isCompleted }
                val totalCount = subject.chapters.size
                val isExpanded = expandedSubjects[subject.id] ?: false

                SubjectCard(
                    subject = subject,
                    completedCount = completedCount,
                    totalCount = totalCount,
                    isExpanded = isExpanded,
                    onToggleExpand = {
                        expandedSubjects[subject.id] = !isExpanded
                    },
                    chapters = subject.chapters,
                    progressEntities = subjectProgressEntities,
                    onToggleChapter = { chapterId, currentStatus ->
                        viewModel.toggleChapterCompletion(chapterId, currentStatus)
                    },
                    onEditNote = { id, title, note ->
                        editingChapter = id to note
                        editingChapterTitle = title
                    },
                    onAskAi = { chapterTitle, subjectName ->
                        viewModel.requestQuickExplanation(
                            title = "$subjectName: $chapterTitle",
                            prompt = "$subjectName এর '$chapterTitle' অধ্যায়টির সারসংক্ষেপ, সবচেয়ে গুরুত্বপূর্ণ ৩টি সূত্র/তত্ত্ব, এবং এসএসসি ২০২৮ পরীক্ষার জন্য সৃজনশীল প্রশ্ন (CQ) ও MCQ-এর বিশেষ টিপস সহজ বাংলায় বিস্তারিত বুঝিয়ে দিন।"
                        )
                    }
                )
            }
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Chapter Note Editor Modal
    if (editingChapter != null) {
        val (id, note) = editingChapter!!
        ChapterNoteDialog(
            chapterTitle = editingChapterTitle,
            initialNote = note,
            onDismiss = { editingChapter = null },
            onSaveNote = { newNote ->
                viewModel.saveChapterNote(id, newNote)
                editingChapter = null
            }
        )
    }

    // Quick AI Explanation Dialog
    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

@Composable
fun SubjectCard(
    subject: SubjectInfo,
    completedCount: Int,
    totalCount: Int,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    chapters: List<ChapterInfo>,
    progressEntities: List<ChapterProgressEntity>,
    onToggleChapter: (String, Boolean) -> Unit,
    onEditNote: (String, String, String) -> Unit,
    onAskAi: (String, String) -> Unit
) {
    CyberCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onToggleExpand
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subject.nameBn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = subject.nameEn,
                        style = MaterialTheme.typography.bodySmall,
                        color = subject.accentColor
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            ChapterProgressBar(
                completed = completedCount,
                total = totalCount,
                color = subject.accentColor
            )

            // Expanded Chapters List
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    var banglaSectionFilter by remember { mutableStateOf("All") }

                    if (subject.id == "bangla_1") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "All" to "সকল অধ্যায় (৫৩)",
                                "গদ্য" to "গদ্য অংশ (২৫)",
                                "কবিতা" to "কবিতা অংশ (২৮)"
                            ).forEach { (filterKey, label) ->
                                val isSelected = banglaSectionFilter == filterKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) NeonCyan else DarkSurfaceVariant)
                                        .clickable { banglaSectionFilter = filterKey }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF031A24) else TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    val displayChapters = if (subject.id == "bangla_1" && banglaSectionFilter != "All") {
                        chapters.filter { it.section == banglaSectionFilter }
                    } else {
                        chapters
                    }

                    displayChapters.forEach { chapter ->
                        val chapterId = "${subject.id}_ch_${chapter.number}"
                        val entity = progressEntities.find { it.chapterNumber == chapter.number }
                        val isCompleted = entity?.isCompleted ?: false
                        val note = entity?.notes.orEmpty()

                        ChapterItemRow(
                            chapter = chapter,
                            chapterId = chapterId,
                            isCompleted = isCompleted,
                            note = note,
                            subjectName = subject.nameBn,
                            onToggle = { onToggleChapter(chapterId, isCompleted) },
                            onEditNote = { onEditNote(chapterId, chapter.title, note) },
                            onAskAi = { 
                                val prompt = "${subject.nameBn} এর '${chapter.title}' (${chapter.section}) অধ্যায়ের লেখক/কবি পরিচিতি, মূল বক্তব্য, গুরুত্বপূর্ণ অনুধাবনমূলক প্রশ্ন ও বিগত বছরের শীর্ষ বোর্ডের সৃজনশীল সমাধান বাংলায় বিস্তারিত বুঝিয়ে দাও।"
                                onAskAi(chapter.title, prompt)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterItemRow(
    chapter: ChapterInfo,
    chapterId: String,
    isCompleted: Boolean,
    note: String,
    subjectName: String,
    onToggle: () -> Unit,
    onEditNote: () -> Unit,
    onAskAi: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        border = BorderStroke(1.dp, if (isCompleted) EmeraldSuccess.copy(alpha = 0.5f) else Color(0xFF283548))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Complete Chapter",
                        tint = if (isCompleted) EmeraldSuccess else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${chapter.sectionIndex}. ${chapter.title}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) TextTertiary else TextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val (pBg, pTextColor, pLabel) = when (chapter.importanceTag) {
                            "⭐" -> Triple(Color(0xFF064E3B), Color(0xFF34D399), "⭐ গুরুত্বপূর্ণ")
                            "☆" -> Triple(Color(0xFF3B0764), Color(0xFFE9D5FF), "☆ সাধারণ")
                            else -> Triple(Color(0xFF451A03), Color(0xFFFDE68A), "🟡 স্বল্প অগ্রাধিকার")
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(pBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = pLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = pTextColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Duration Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (chapter.importanceTag == "⭐") Color(0xFF38230B) else Color(0xFF0F2636))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${chapter.defaultDays} দিন",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (chapter.importanceTag == "⭐") AmberGold else NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (chapter.section.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1E1E2E))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = chapter.section,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonPurple,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = chapter.keyTopics,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        color = TextSecondary
                    )
                }
            }

            // Note preview if present
            if (note.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0C1322))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "📝 নোট: $note",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onEditNote) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit note",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (note.isBlank()) "নোট যোগ করো" else "নোট সম্পাদনা",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                TextButton(onClick = onAskAi) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Ask AI",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "MRH AI ব্যাখ্যা",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
