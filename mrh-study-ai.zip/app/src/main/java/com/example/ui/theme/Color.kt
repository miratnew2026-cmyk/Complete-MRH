package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// MRH STUDY AI - Cyber Obsidian Palette
val DarkBg = Color(0xFF070A13)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF162032)

// Neon Accents
val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF38BDF8)
val NeonPurple = Color(0xFFA855F7)
val DeepViolet = Color(0xFF7C3AED)
val NeonPink = Color(0xFFF43F5E)
val EmeraldSuccess = Color(0xFF10B981)
val AmberGold = Color(0xFFF59E0B)

// Text and Base
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val BorderGlow = Color(0xFF334155)

// Gradients
val CyberGradient = Brush.horizontalGradient(
    colors = listOf(NeonCyan, NeonPurple)
)

val CardGlowGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
)

val HeroBannerGradient = Brush.verticalGradient(
    colors = listOf(Color(0x3300E5FF), Color(0x33A855F7), Color(0xFF070A13))
)
