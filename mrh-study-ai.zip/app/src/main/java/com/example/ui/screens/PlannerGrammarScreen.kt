package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ScheduledTaskEntity
import com.example.data.model.GrammarLessonsData
import com.example.data.model.PlanProgressMetrics
import com.example.ui.components.ChapterProgressBar
import com.example.ui.components.ChapterStudySystemDialog
import com.example.ui.components.CyberCard
import com.example.ui.components.ExtendChapterDialog
import com.example.ui.components.MissedRecoveryDialog
import com.example.ui.components.QuickExplanationDialog
import com.example.ui.components.StudyPlanSetupDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGradient
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MainViewModel

@Composable
fun PlannerGrammarScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("ভবিষ্যৎ স্টাডি প্ল্যান", "English Grammar A-Z", "অগ্রগতি অ্যানালিটিক্স")

    val quickExplainTitle by viewModel.quickExplainTitle.collectAsState()
    val quickExplainContent by viewModel.quickExplainContent.collectAsState()
    val isQuickExplainLoading by viewModel.isQuickExplainLoading.collectAsState()

    val activePlanConfig by viewModel.activePlanConfig.collectAsState()
    val allScheduledTasks by viewModel.allScheduledTasks.collectAsState()
    val planMetrics by viewModel.planMetrics.collectAsState()

    var showSetupDialog by remember { mutableStateOf(false) }
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var selectedTaskForSystem by remember { mutableStateOf<ScheduledTaskEntity?>(null) }
    var selectedChapterForExtend by remember { mutableStateOf<String?>(null) }

    val missedTasks = allScheduledTasks.filter { it.dateString < viewModel.todayString && !it.isCompleted && !it.isRecovered }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = NeonCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = NeonCyan
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) NeonCyan else TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> FutureStudyPlannerTab(
                    planMetrics = planMetrics,
                    allTasks = allScheduledTasks,
                    todayString = viewModel.todayString,
                    tomorrowString = viewModel.tomorrowString,
                    missedTasks = missedTasks,
                    onOpenSetup = { showSetupDialog = true },
                    onOpenRecovery = { showRecoveryDialog = true },
                    onOpenChapterSystem = { task -> selectedTaskForSystem = task },
                    onOpenExtendDialog = { chapterTitle -> selectedChapterForExtend = chapterTitle },
                    onToggleComplete = { taskId, current -> viewModel.toggleTaskCompleteDirectly(taskId, current) },
                    onAskAi = { title, prompt -> viewModel.requestQuickExplanation(title, prompt) }
                )
                1 -> EnglishGrammarTab(
                    onAskAi = { title, prompt -> viewModel.requestQuickExplanation(title, prompt) }
                )
                2 -> ComprehensiveAnalyticsTab(
                    metrics = planMetrics,
                    onOpenSetup = { showSetupDialog = true }
                )
            }
        }
    }

    // Feature 1: Setup Dialog
    if (showSetupDialog) {
        StudyPlanSetupDialog(
            currentConfig = activePlanConfig,
            onDismiss = { showSetupDialog = false },
            onGeneratePlan = { durationMonths, dailyHours, startDateMillis, easyDays, normalDays, difficultDays, veryDifficultDays ->
                viewModel.generateNewStudyPlan(
                    durationMonths = durationMonths,
                    dailyHours = dailyHours,
                    startDateMillis = startDateMillis,
                    easyDays = easyDays,
                    normalDays = normalDays,
                    difficultDays = difficultDays,
                    veryDifficultDays = veryDifficultDays
                )
            }
        )
    }

    // Feature 3: Chapter Study System Dialog (8 Phases & Time allocation)
    if (selectedTaskForSystem != null) {
        val currentTask = allScheduledTasks.find { it.id == selectedTaskForSystem!!.id } ?: selectedTaskForSystem!!
        ChapterStudySystemDialog(
            task = currentTask,
            onDismiss = { selectedTaskForSystem = null },
            onToggleStep = { stepIndex -> viewModel.toggleTaskStep(currentTask, stepIndex) },
            onUpdateTimeAllocations = { textbook, mcq, cq, board, revision ->
                viewModel.updateTaskTimeAllocations(currentTask.id, textbook, mcq, cq, board, revision)
            },
            onOpenExtendDialog = {
                selectedChapterForExtend = currentTask.chapterTitle
            },
            onAskAi = { title, prompt ->
                viewModel.requestQuickExplanation(title, prompt)
            }
        )
    }

    // Feature 4: Custom Time Extension Dialog
    if (selectedChapterForExtend != null) {
        ExtendChapterDialog(
            chapterTitle = selectedChapterForExtend!!,
            onDismiss = { selectedChapterForExtend = null },
            onConfirmExtension = { extraDays ->
                viewModel.extendChapterTime(selectedChapterForExtend!!, extraDays)
                selectedChapterForExtend = null
            }
        )
    }

    // Feature 5: Missed Study Recovery Dialog
    if (showRecoveryDialog) {
        MissedRecoveryDialog(
            missedTasks = missedTasks,
            onDismiss = { showRecoveryDialog = false },
            onRecoverAll = { viewModel.recoverAllMissedTasks() },
            onMarkTaskRecovered = { taskId -> viewModel.markTaskRecovered(taskId) }
        )
    }

    // Quick AI Explanation Dialog
    QuickExplanationDialog(
        title = quickExplainTitle,
        content = quickExplainContent,
        isLoading = isQuickExplainLoading,
        onDismiss = { viewModel.closeQuickExplanation() }
    )
}

/**
 * Feature 2 & 6: Complete Daily Schedule & Calendar View
 */
@Composable
fun FutureStudyPlannerTab(
    planMetrics: PlanProgressMetrics,
    allTasks: List<ScheduledTaskEntity>,
    todayString: String,
    tomorrowString: String,
    missedTasks: List<ScheduledTaskEntity>,
    onOpenSetup: () -> Unit,
    onOpenRecovery: () -> Unit,
    onOpenChapterSystem: (ScheduledTaskEntity) -> Unit,
    onOpenExtendDialog: (String) -> Unit,
    onToggleComplete: (String, Boolean) -> Unit,
    onAskAi: (String, String) -> Unit
) {
    var calendarFilter by remember { mutableStateOf("TODAY") } // TODAY, TOMORROW, WEEK, ALL

    val filteredTasks = when (calendarFilter) {
        "TODAY" -> allTasks.filter { it.dateString == todayString }
        "TOMORROW" -> allTasks.filter { it.dateString == tomorrowString }
        "WEEK" -> {
            // Next 7 days
            val cal = java.util.Calendar.getInstance()
            val next7Days = (0..6).map {
                val str = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(cal.time)
                cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                str
            }
            allTasks.filter { it.dateString in next7Days }
        }
        else -> allTasks
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))

            // Plan Header Card
            CyberCard(
                borderBrush = CyberGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "এসএসসি ২০২৮ ভবিষ্যৎ স্টাডি প্ল্যান",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${planMetrics.totalPlanDays} দিন • দৈনিক ${planMetrics.dailyHours} ঘণ্টা • লক্ষ্য সমাপ্তি: ${planMetrics.targetCompletionDate}",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonCyan
                            )
                        }

                        IconButton(
                            onClick = onOpenSetup,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceVariant)
                                .testTag("open_plan_setup_button")
                        ) {
                            Icon(imageVector = Icons.Default.EditCalendar, contentDescription = "Config", tint = NeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    ChapterProgressBar(
                        completed = planMetrics.completedChapters,
                        total = planMetrics.totalChapters,
                        color = NeonCyan
                    )
                }
            }
        }

        // Feature 5 Alert: Missed Tasks Recovery Alert
        if (missedTasks.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenRecovery() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B1219)),
                    border = BorderStroke(1.dp, AmberGold),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = "Alert", tint = AmberGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "মিসড পড়া চিহ্নিত হয়েছে (${missedTasks.size}টি বকেয়া টাস্ক)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberGold
                                )
                                Text(
                                    text = "অটোমেটিক রিকভারি প্ল্যান তৈরি করতে এখানে ট্যাপ করুন",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Button(
                            onClick = onOpenRecovery,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("রিকভার", color = Color(0xFF031A24), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Calendar Filters Row
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val filters = listOf(
                    "TODAY" to "আজকের পড়া (${allTasks.count { it.dateString == todayString }})",
                    "TOMORROW" to "আগামীকাল (${allTasks.count { it.dateString == tomorrowString }})",
                    "WEEK" to "সাপ্তাহিক শিডিউল",
                    "ALL" to "সম্পূর্ণ শিডিউল (${allTasks.size}টি সেশন)"
                )
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = calendarFilter == key,
                        onClick = { calendarFilter = key },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan,
                            selectedLabelColor = Color(0xFF031A24),
                            containerColor = DarkSurface,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = BorderGlow,
                            selectedBorderColor = NeonCyan,
                            enabled = true,
                            selected = calendarFilter == key
                        )
                    )
                }
            }
        }

        // Tasks List
        if (filteredTasks.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "None", tint = EmeraldSuccess, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (calendarFilter == "TODAY") "আজকের সব পড়া সম্পন্ন হয়েছে! ওয়েল ডান!" else "কোনো টাস্ক নেই।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(filteredTasks) { task ->
                ScheduledTaskCard(
                    task = task,
                    onOpenChapterSystem = { onOpenChapterSystem(task) },
                    onOpenExtendDialog = { onOpenExtendDialog(task.chapterTitle) },
                    onToggleComplete = { onToggleComplete(task.id, task.isCompleted) },
                    onAskAi = {
                        onAskAi(
                            "অধ্যায় আলোচনা: ${task.chapterTitle}",
                            "আমি ${task.subjectName} এর '${task.chapterTitle}' পড়ছি। এসএসসি ২০২৮-এর জন্য এই অধ্যায়ের সবচেয়ে গুরুত্বপূর্ণ বোর্ড টিপস ও ফর্মুলা সংক্ষেপে বাংলায় বুঝিয়ে দিন।"
                        )
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ScheduledTaskCard(
    task: ScheduledTaskEntity,
    onOpenChapterSystem: () -> Unit,
    onOpenExtendDialog: () -> Unit,
    onToggleComplete: () -> Unit,
    onAskAi: () -> Unit
) {
    val phaseDoneCount = listOf(
        task.textbookRead, task.conceptUnderstood, task.notesCreated,
        task.mcqPracticeCompleted, task.cqPracticeCompleted, task.boardQuestionsSolved,
        task.chapterTestCompleted, task.mistakesReviewed
    ).count { it }

    CyberCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onOpenChapterSystem
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Day & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                when (task.taskType) {
                                    "REVISION" -> Color(0xFF2E1065)
                                    "MODEL_TEST" -> Color(0xFF4C0519)
                                    "RECOVERY" -> Color(0xFF451A03)
                                    else -> Color(0xFF0C2A4D)
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "দিন ${task.dayNumber} • ${task.subjectName}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (task.taskType) {
                                "REVISION" -> NeonPurple
                                "MODEL_TEST" -> NeonPink
                                "RECOVERY" -> AmberGold
                                else -> NeonCyan
                            }
                        )
                    }
                    if (task.extendedDays > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF3B1219))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(text = "+${task.extendedDays} দিন বর্ধিত", style = MaterialTheme.typography.labelSmall, color = NeonPink, fontSize = 10.sp)
                        }
                    }
                }

                Text(
                    text = task.dateString,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Middle: Title and Checkbox
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleComplete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Status",
                        tint = if (task.isCompleted) EmeraldSuccess else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.chapterTitle,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = if (task.isCompleted) TextTertiary else TextPrimary
                    )
                    Text(
                        text = "সময় বরাদ্দ: ${task.allocatedHours} ঘণ্টা • ৮-ধাপ প্রস্তুতি: $phaseDoneCount/৮ সম্পন্ন",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (phaseDoneCount == 8) EmeraldSuccess else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpenChapterSystem,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    border = BorderStroke(1.dp, Color(0xFF283850)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("৮-ধাপ চেকলিস্ট", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onOpenExtendDialog) {
                        Icon(imageVector = Icons.Default.MoreTime, contentDescription = "Extend", tint = NeonPurple, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Extend Time", style = MaterialTheme.typography.labelSmall, color = NeonPurple)
                    }

                    TextButton(onClick = onAskAi) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = NeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AI গাইড", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                    }
                }
            }
        }
    }
}

/**
 * Feature 7: Comprehensive Analytics Tab
 */
@Composable
fun ComprehensiveAnalyticsTab(
    metrics: PlanProgressMetrics,
    onOpenSetup: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "এসএসসি ২০২৮ সামগ্রিক অগ্রগতি ড্যাশবোর্ড",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "পরিকল্পনা অনুযায়ী নিখুঁত প্রস্তুতি নিশ্চিতকরণ",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Button(
                    onClick = onOpenSetup,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    border = BorderStroke(1.dp, NeonCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("প্ল্যান পরিবর্তন", color = NeonCyan, fontSize = 12.sp)
                }
            }
        }

        // Main Progress Bar Card
        item {
            CyberCard(
                borderBrush = CyberGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "সিলেবাস সম্পন্নতা", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${metrics.completedChapters} / ${metrics.totalChapters} অধ্যায় (${metrics.syllabusPercent}%)",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    ChapterProgressBar(
                        completed = metrics.completedChapters,
                        total = metrics.totalChapters,
                        color = NeonCyan
                    )
                }
            }
        }

        // Metrics Grid (2 columns)
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CyberCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "অবশিষ্ট অধ্যায়", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${metrics.remainingChapters}টি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = NeonPink)
                        Text(text = "১২টি বিষয়", style = MaterialTheme.typography.bodySmall, color = TextTertiary)
                    }
                }
                CyberCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "অবশিষ্ট দিন", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${metrics.remainingDays} দিন", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = AmberGold)
                        Text(text = "সমাপ্তি: ${metrics.targetCompletionDate}", style = MaterialTheme.typography.bodySmall, color = TextTertiary, maxLines = 1)
                    }
                }
            }
        }

        // Quantitative Question Pending Metrics (Pending MCQ, CQ, Board Questions)
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CyberCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "বকেয়া MCQ", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${metrics.pendingMcqCount}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NeonCyan)
                    }
                }
                CyberCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "বকেয়া CQ", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${metrics.pendingCqCount}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NeonPurple)
                    }
                }
                CyberCard(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "বোর্ড প্রশ্ন", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${metrics.pendingBoardQuestionCount}টি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                    }
                }
            }
        }

        // Missed Tasks & Recovery Status
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "মিসড পড়া রিকভারি স্ট্যাটাস", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            text = if (metrics.missedTasksCount == 0) "সব আপ-টু-ডেট" else "${metrics.missedTasksCount}টি পেন্ডিং",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (metrics.missedTasksCount == 0) EmeraldSuccess else AmberGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (metrics.missedTasksCount == 0)
                            "তুমি একদম সঠিক ট্র্যাকে আছো! কোনো বকেয়া পড়া নেই।"
                        else
                            "কিছু পড়া মিস হয়েছে। স্টাডি প্ল্যানার ট্যাব থেকে 'রিকভার' অপশন ব্যবহার করে ব্যালান্সড রুটিনে যোগ করো।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun EnglishGrammarTab(
    onAskAi: (String, String) -> Unit
) {
    val expandedTopics = remember { mutableStateMapOf<String, Boolean>() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "English Grammar A to Z",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "এসএসসি ২য় পত্রের প্রতিটি ব্যাকরণ টপিকের নিয়ম, উদাহরণ ও বোর্ড ট্র্যাপস",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        items(GrammarLessonsData.topics) { topic ->
            val isExpanded = expandedTopics[topic.id] ?: false

            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = { expandedTopics[topic.id] = !isExpanded }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = topic.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                            Text(text = topic.subtitleBn, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand",
                            tint = TextSecondary
                        )
                    }

                    AnimatedVisibility(visible = isExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            topic.rules.forEach { rule ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DarkSurfaceVariant)
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = rule.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = rule.explanationBn,
                                            style = MaterialTheme.typography.bodySmall,
                                            lineHeight = 20.sp,
                                            color = TextPrimary
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF0F172A))
                                                .padding(8.dp)
                                        ) {
                                            Text(
                                                text = "সূত্র / স্ট্রাকচার: ${rule.formulaOrStructure}",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = NeonPurple
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        rule.examples.forEach { example ->
                                            Text(
                                                text = "✓ $example",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = EmeraldSuccess
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Lightbulb,
                                                contentDescription = "Tip",
                                                tint = AmberGold,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "বোর্ড টিপ: ${rule.boardTip}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = AmberGold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            TextButton(
                                                onClick = {
                                                    onAskAi(
                                                        "ইংরেজি গ্রামার: ${rule.title}",
                                                        "নিয়ম: ${rule.title}\nব্যাখ্যা: ${rule.explanationBn}\nসূত্র: ${rule.formulaOrStructure}\n\nএই নিয়মটির উপর ভিত্তি করে এসএসসি ২০২৮ বোর্ড পরীক্ষার উপযোগী আরো ৩টি প্র্যাকটিস বাক্য তৈরি করুন এবং বিস্তারিত ব্যাখ্যা দিন।"
                                                    )
                                                }
                                            ) {
                                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = NeonCyan, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("AI প্র্যাকটিস করো", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
