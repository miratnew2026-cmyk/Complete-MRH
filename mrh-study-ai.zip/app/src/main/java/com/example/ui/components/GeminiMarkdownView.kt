package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.AppFontFamily
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.regex.Pattern

/**
 * Renders Gemini AI responses with official Google Gemini-style visual structure:
 * - Automatic conversion of raw LaTeX/code into clean NCTB textbook mathematics (√, π, ×, ÷, ±, x², x³, 1/x)
 * - Beautiful MCQ options with stylized badges: (ক), (খ), (গ), (ঘ)
 * - Distinct highlighted cards for Correct Answers & Explanations
 * - Dedicated formula cards for math equations and calculation steps
 * - Native Markdown headers, inline bold (**text**), dividers (---), and bullets
 */
@Composable
fun GeminiMarkdownView(
    content: String,
    modifier: Modifier = Modifier
) {
    val lines = content.split("\n")

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        var i = 0
        while (i < lines.size) {
            val rawLine = lines[i]
            val line = rawLine.trim()

            if (line.isBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                i++
                continue
            }

            // Divider line (e.g. --- or ***)
            if (line == "---" || line == "***" || line == "___") {
                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider(
                    color = Color(0xFF1E2D42),
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                i++
                continue
            }

            val formattedLine = TextbookMathFormatter.format(line)

            when {
                // Header 1 or 2
                line.startsWith("# ") || line.startsWith("## ") -> {
                    val cleanHeader = formattedLine.removePrefix("## ").removePrefix("# ").replace("**", "").trim()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = cleanHeader,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        fontSize = 17.sp,
                        fontFamily = AppFontFamily
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Header 3 or Section title
                line.startsWith("### ") -> {
                    val cleanHeader = formattedLine.removePrefix("### ").replace("**", "").trim()
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = cleanHeader,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF93C5FD),
                        fontSize = 15.sp,
                        fontFamily = AppFontFamily
                    )
                }

                // Math Step Header: e.g. ধাপ ১:, Step 1:, ধাপ ২: দেওয়া আছে...
                isMathStepHeader(formattedLine) -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F2636))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Step",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineMarkdown(formattedLine),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE0F2FE),
                            fontFamily = AppFontFamily
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Standalone Math Equation Line: e.g. 1/x = ..., = (√6 - √5) / ..., x = √6 + √5
                isStandaloneMathEquation(formattedLine) -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0C1726))
                            .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Functions,
                                contentDescription = "Formula",
                                tint = NeonCyan.copy(alpha = 0.8f),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = parseInlineMarkdown(formattedLine),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE2E8F0),
                                fontSize = 15.sp,
                                lineHeight = 22.sp,
                                fontFamily = AppFontFamily
                            )
                        }
                    }
                }

                // MCQ Question Header: e.g. **প্রশ্ন ১:** or প্রশ্ন ১:
                isMcqQuestionHeader(line) -> {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0C1929))
                            .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = parseInlineMarkdown(formattedLine),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            lineHeight = 22.sp,
                            fontFamily = AppFontFamily
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // MCQ Option: e.g. (ক) ..., ক) ..., (A) ..., A) ...
                isMcqOption(line) -> {
                    val (badge, optionText) = extractOptionBadgeAndText(formattedLine)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F2636))
                                .border(1.dp, NeonCyan.copy(alpha = 0.6f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = badge,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontFamily = AppFontFamily
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = parseInlineMarkdown(optionText),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontFamily = AppFontFamily,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Correct Answer Box: e.g. **সঠিক উত্তর:** বা **✓ সঠিক উত্তর:**
                isCorrectAnswerLine(line) -> {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF092920))
                            .border(1.dp, EmeraldSuccess.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Correct Answer",
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = parseInlineMarkdown(formattedLine),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess,
                                fontFamily = AppFontFamily,
                                lineHeight = 20.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Explanation Box: e.g. **ব্যাখ্যা:** বা **💡 ব্যাখ্যা:**
                isExplanationLine(line) -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0A1E2D))
                            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "Explanation",
                                tint = AmberGold,
                                modifier = Modifier.size(18.dp).padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = parseInlineMarkdown(formattedLine),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFE0F2FE),
                                fontFamily = AppFontFamily,
                                lineHeight = 19.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Bullet point item: starts with •, -, *
                line.startsWith("• ") || line.startsWith("- ") || line.startsWith("* ") -> {
                    val bulletText = formattedLine.substring(2).trim()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 4.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(NeonCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineMarkdown(bulletText),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 22.sp,
                            fontFamily = AppFontFamily
                        )
                    }
                }

                // Standard paragraph / line
                else -> {
                    Text(
                        text = parseInlineMarkdown(formattedLine),
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp,
                        color = TextPrimary,
                        fontFamily = AppFontFamily
                    )
                }
            }
            i++
        }
    }
}

/**
 * Detects if a line is a mathematical step header like "ধাপ ১:", "Step 1:", "১ম ধাপ:"
 */
private fun isMathStepHeader(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    return clean.matches(Regex("^(ধাপ|Step|পদক্ষেপ|১ম\\s*ধাপ|২য়\\s*ধাপ|৩য়\\s*ধাপ|৪র্থ\\s*ধাপ)\\s*[০-৯0-9]*[:\\-].*", RegexOption.IGNORE_CASE))
}

/**
 * Detects standalone math equations (e.g. "= (√6 - √5) / (6 - 5)", "1/x = 1 / (√6 + √5)", "x² - 5x + 6 = 0")
 */
private fun isStandaloneMathEquation(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    // Does not qualify if it's an MCQ option or explanation or question header
    if (isMcqOption(clean) || isMcqQuestionHeader(clean) || isExplanationLine(clean) || isCorrectAnswerLine(clean)) {
        return false
    }

    // Starts with = (continuation step like "= (√6 - √5) / 1")
    if (clean.startsWith("=") || clean.startsWith("=>") || clean.startsWith("⇒") || clean.startsWith("∴") || clean.startsWith("অতএব,") && clean.contains("=")) {
        return true
    }

    // Form of "variable = expression" or "expression = expression" with math symbols
    val hasMathSymbols = clean.contains("√") || clean.contains("²") || clean.contains("³") ||
            clean.contains("⁶") || clean.contains("×") || clean.contains("÷") ||
            clean.contains("±") || clean.contains("π") || clean.contains("θ") ||
            clean.contains("/") && clean.contains("=")

    val isEquation = clean.contains("=") && hasMathSymbols
    val hasLongWords = clean.split(" ").any { it.length > 12 && !it.contains("√") && !it.contains("/") }

    return isEquation && !hasLongWords && clean.length < 90
}

/**
 * Checks if line is an MCQ Question header like **প্রশ্ন ১:**, **Q1:**, etc.
 */
private fun isMcqQuestionHeader(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    return clean.startsWith("প্রশ্ন") ||
            clean.startsWith("Question") ||
            clean.startsWith("Q.") ||
            clean.matches(Regex("^(প্রশ্ন|Q|নং)\\s*[০-৯0-9]+.*", RegexOption.IGNORE_CASE))
}

/**
 * Checks if line is an MCQ option like (ক), (খ), (গ), (ঘ) or (A), (B), (C), (D) or ক), খ)
 */
private fun isMcqOption(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    val pattern = Pattern.compile("^(\\(?[ক-ঘa-dA-D][\\)\\.]\\s*|\\([ক-ঘa-dA-D]\\)\\s*).*")
    return pattern.matcher(clean).matches()
}

/**
 * Extracts the option indicator (e.g. ক, খ, গ, ঘ) and the option text
 */
private fun extractOptionBadgeAndText(line: String): Pair<String, String> {
    val clean = line.replace("*", "").trim()
    val match = Regex("^(\\(?)([ক-ঘa-dA-D])([\\)\\.]?)(.*)").find(clean)
    if (match != null) {
        val letter = match.groupValues[2]
        val text = match.groupValues[4].trim()
        return Pair(letter, text)
    }
    return Pair("•", clean)
}

/**
 * Checks if line is correct answer indicator
 */
private fun isCorrectAnswerLine(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    return clean.contains("সঠিক উত্তর") ||
            clean.contains("Correct Answer") ||
            clean.contains("উত্তর:")
}

/**
 * Checks if line is explanation indicator
 */
private fun isExplanationLine(line: String): Boolean {
    val clean = line.replace("*", "").trim()
    return clean.startsWith("ব্যাখ্যা") ||
            clean.startsWith("💡 ব্যাখ্যা") ||
            clean.startsWith("Explanation")
}

/**
 * Converts raw LaTeX, math code, and expressions into clean NCTB textbook mathematics:
 * √, π, ×, ÷, ±, ⁰¹²³⁴⁵⁶⁷⁸⁹ⁿ, fractions (A / B)
 */
object TextbookMathFormatter {

    fun format(input: String): String {
        if (input.isBlank()) return input

        var text = input

        // 1. Remove LaTeX dollar delimiters $$...$$ and $...$
        text = text.replace("$$", "")
        text = text.replace("$", "")

        // 2. Convert \sqrt[n]{A} and \sqrt{A} first so inner roots in fractions are clean
        val nthRootRegex = Regex("""\\sqrt\s*\[(.*?)\]\s*\{([^{}]+)\}""")
        text = nthRootRegex.replace(text) { matchResult ->
            val n = toSuperscript(matchResult.groupValues[1].trim())
            val inner = matchResult.groupValues[2].trim()
            "${n}√($inner)"
        }
        val sqrtRegex = Regex("""\\sqrt\s*\{([^{}]+)\}""")
        text = sqrtRegex.replace(text) { matchResult ->
            val inner = matchResult.groupValues[1].trim()
            if (inner.length == 1 || inner.matches(Regex("^[০-৯0-9a-zA-Z]+$"))) {
                "√$inner"
            } else {
                "√($inner)"
            }
        }
        // Handle bare \sqrt without braces like \sqrt 6
        text = text.replace(Regex("""\\sqrt\s+([০-৯0-9a-zA-Z])"""), "√$1")

        // 3. Superscripts with braces ^{...}
        val supBraceRegex = Regex("""\^\{([^{}]+)\}""")
        text = supBraceRegex.replace(text) { matchResult ->
            toSuperscript(matchResult.groupValues[1].trim())
        }

        // 4. Superscripts without braces: ^2, ^3, ^6, ^n, ^x, etc.
        val supSingleRegex = Regex("""\^([0-9a-zA-Z\+\-])""")
        text = supSingleRegex.replace(text) { matchResult ->
            toSuperscript(matchResult.groupValues[1])
        }

        // 5. Subscripts with braces _{...}
        val subBraceRegex = Regex("""_\{([^{}]+)\}""")
        text = subBraceRegex.replace(text) { matchResult ->
            toSubscript(matchResult.groupValues[1].trim())
        }

        // 6. Subscripts without braces _0, _1, _n
        val subSingleRegex = Regex("""_([0-9a-zA-Z])""")
        text = subSingleRegex.replace(text) { matchResult ->
            toSubscript(matchResult.groupValues[1])
        }

        // 7. Convert \frac{A}{B} using robust curly brace matching
        text = convertFractions(text)

        // 8. Replace LaTeX symbols with Unicode math symbols
        val symbolReplacements = listOf(
            "\\times" to " × ",
            "\\div" to " ÷ ",
            "\\pm" to " ± ",
            "\\mp" to " ∓ ",
            "\\cdot" to " · ",
            "\\pi" to "π",
            "\\theta" to "θ",
            "\\alpha" to "α",
            "\\beta" to "β",
            "\\gamma" to "γ",
            "\\delta" to "δ",
            "\\Delta" to "Δ",
            "\\lambda" to "λ",
            "\\mu" to "μ",
            "\\sigma" to "σ",
            "\\Sigma" to "∑",
            "\\sum" to "∑",
            "\\int" to "∫",
            "\\infty" to "∞",
            "\\approx" to " ≈ ",
            "\\neq" to " ≠ ",
            "\\ne" to " ≠ ",
            "\\leq" to " ≤ ",
            "\\le" to " ≤ ",
            "\\geq" to " ≥ ",
            "\\ge" to " ≥ ",
            "\\circ" to "°",
            "\\degree" to "°",
            "\\to" to " → ",
            "\\rightarrow" to " → ",
            "\\Rightarrow" to " ⇒ ",
            "\\Leftrightarrow" to " ⇔ ",
            "\\therefore" to "∴",
            "\\because" to "∵",
            "\\angle" to "∠",
            "\\triangle" to "△",
            "\\perp" to "⊥",
            "\\parallel" to "∥",
            "\\left(" to "(",
            "\\right)" to ")",
            "\\left\\{" to "{",
            "\\right\\}" to "}",
            "\\left[" to "[",
            "\\right]" to "]",
            "\\{" to "{",
            "\\}" to "}",
            "\\quad" to "  ",
            "\\qquad" to "   ",
            "\\," to " ",
            "\\;" to " ",
            "\\:" to " "
        )

        for ((target, replacement) in symbolReplacements) {
            text = text.replace(target, replacement)
        }

        // 9. Remove \text{...}, \mathrm{...}, \mathbf{...}
        val textCommandRegex = Regex("""\\(text|mathrm|mathbf)\s*\{([^{}]+)\}""")
        text = textCommandRegex.replace(text) { it.groupValues[2] }

        // 10. Clean common functions \sin, \cos, \tan, \log
        val funcRegex = Regex("""\\(sin|cos|tan|cot|sec|cosec|log|ln)""")
        text = funcRegex.replace(text) { it.groupValues[1] }

        // 11. Normalize "+-" to "±" in math contexts
        text = text.replace("+ -", "±")
        text = text.replace("+-", "±")

        // Clean up double spaces within text
        text = text.replace(Regex("""[ \t]{2,}"""), " ")

        return text
    }

    private fun convertFractions(input: String): String {
        var text = input
        val fracMarker = "\\frac"
        var idx = text.indexOf(fracMarker)
        var safety = 0
        while (idx != -1 && safety < 50) {
            safety++
            val numStart = idx + fracMarker.length
            val numContent = extractBracedContent(text, numStart)
            if (numContent == null) {
                idx = text.indexOf(fracMarker, idx + 1)
                continue
            }
            val denContent = extractBracedContent(text, numContent.second)
            if (denContent == null) {
                idx = text.indexOf(fracMarker, idx + 1)
                continue
            }

            val rawNum = numContent.first.trim()
            val rawDen = denContent.first.trim()

            // Recursively convert inner fractions if any
            val formattedNum = convertFractions(rawNum)
            val formattedDen = convertFractions(rawDen)

            val finalNum = if (needsParentheses(formattedNum)) "($formattedNum)" else formattedNum
            val finalDen = if (needsParentheses(formattedDen)) "($formattedDen)" else formattedDen

            val replacement = if (finalNum.length == 1 && finalDen.length == 1) {
                "$finalNum/$finalDen"
            } else {
                "$finalNum / $finalDen"
            }

            text = text.substring(0, idx) + replacement + text.substring(denContent.second)
            idx = text.indexOf(fracMarker)
        }
        return text
    }

    private fun extractBracedContent(text: String, startIndex: Int): Pair<String, Int>? {
        var i = startIndex
        while (i < text.length && text[i].isWhitespace()) i++
        if (i >= text.length || text[i] != '{') return null
        var depth = 0
        val contentStart = i + 1
        for (j in i until text.length) {
            if (text[j] == '{') depth++
            else if (text[j] == '}') {
                depth--
                if (depth == 0) {
                    return Pair(text.substring(contentStart, j), j + 1)
                }
            }
        }
        return null
    }

    private fun needsParentheses(expr: String): Boolean {
        val trimmed = expr.trim()
        if (trimmed.startsWith("(") && trimmed.endsWith(")")) return false
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) return false
        // Single identifier or pure number or single square root (e.g., 1, x, √6)
        if (trimmed.matches(Regex("^[০-৯0-9a-zA-Z√]+$"))) return false
        // Contains binary operators
        return trimmed.contains("+") || trimmed.contains("-") ||
                trimmed.contains("×") || trimmed.contains("÷") ||
                trimmed.contains("/") || trimmed.contains(" ")
    }

    fun toSuperscript(str: String): String {
        return str.map { ch ->
            when (ch) {
                '0' -> '⁰'
                '1' -> '¹'
                '2' -> '²'
                '3' -> '³'
                '4' -> '⁴'
                '5' -> '⁵'
                '6' -> '⁶'
                '7' -> '⁷'
                '8' -> '⁸'
                '9' -> '⁹'
                '+' -> '⁺'
                '-' -> '⁻'
                '=' -> '⁼'
                '(' -> '⁽'
                ')' -> '⁾'
                'n' -> 'ⁿ'
                'i' -> 'ⁱ'
                'x' -> 'ˣ'
                'y' -> 'ʸ'
                'a' -> 'ᵃ'
                'b' -> 'ᵇ'
                'c' -> 'ᶜ'
                else -> ch
            }
        }.joinToString("")
    }

    fun toSubscript(str: String): String {
        return str.map { ch ->
            when (ch) {
                '0' -> '₀'
                '1' -> '₁'
                '2' -> '₂'
                '3' -> '₃'
                '4' -> '₄'
                '5' -> '₅'
                '6' -> '₆'
                '7' -> '₇'
                '8' -> '₈'
                '9' -> '₉'
                '+' -> '₊'
                '-' -> '₋'
                '=' -> '₌'
                '(' -> '₍'
                ')' -> '₎'
                'a' -> 'ₐ'
                'e' -> 'ₑ'
                'o' -> 'ₒ'
                'x' -> 'ₓ'
                'h' -> 'ₕ'
                'k' -> 'ₖ'
                'l' -> 'ₗ'
                'm' -> 'ₘ'
                'n' -> 'ₙ'
                'p' -> 'ₚ'
                's' -> 'ₛ'
                't' -> 'ₜ'
                else -> ch
            }
        }.joinToString("")
    }
}

/**
 * Parses bold (**bold**), italic (*italic*), and inline code (`code`) into an AnnotatedString.
 * Automatically runs TextbookMathFormatter to ensure all math symbols and powers are textbook-ready.
 */
fun parseInlineMarkdown(text: String): AnnotatedString {
    val mathFormatted = TextbookMathFormatter.format(text)

    return buildAnnotatedString {
        var currentIndex = 0
        // Match **bold**
        val boldPattern = Pattern.compile("\\*\\*(.*?)\\*\\*")
        val matcher = boldPattern.matcher(mathFormatted)

        while (matcher.find()) {
            val start = matcher.start()
            val end = matcher.end()
            val content = matcher.group(1) ?: ""

            if (start > currentIndex) {
                append(mathFormatted.substring(currentIndex, start))
            }

            val boldStart = length
            append(content)
            addStyle(
                SpanStyle(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                ),
                boldStart,
                length
            )

            currentIndex = end
        }

        if (currentIndex < mathFormatted.length) {
            append(mathFormatted.substring(currentIndex))
        }
    }
}
