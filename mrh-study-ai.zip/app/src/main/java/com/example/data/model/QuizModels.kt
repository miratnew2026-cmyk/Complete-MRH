package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class AgentAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val username: String = "",
    val displayName: String = "",
    val email: String = "",
    val role: String = "agent",
    val active: Boolean = true,
    val assignedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class McqQuestionRecord(
    @DocumentId val id: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterNumber: Long = 1L,
    val chapterTitle: String = "",
    val question: String = "",
    val options: List<String> = emptyList(),
    val correctIndex: Long = 0L,
    val explanation: String = "",
    val difficulty: String = "medium",
    val sourceType: String = "manual", // manual | book | ocr_image | ocr_pdf
    val sourceFileUrl: String = "",
    val sourceStoragePath: String = "",
    val ocrReviewed: Boolean = false,
    val status: String = "pending_review", // pending_review | draft | published
    val quizId: String = "",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class QuizCollectionRecord(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterNumber: Long = 0L,
    val chapterTitle: String = "",
    val quizType: String = "agent_uploaded", // chapter | full_subject | random | timed | exam_mode | book | agent_uploaded
    val difficulty: String = "mixed", // easy | medium | hard | mixed
    val durationMinutes: Long = 10L,
    val mcqIds: List<String> = emptyList(),
    val questionCount: Long = 0L,
    val status: String = "draft", // draft | published | archived
    val createdBy: String = "",
    val createdByName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AttemptAnswerItem(
    val mcqId: String = "",
    val question: String = "",
    val options: List<String> = emptyList(),
    val selectedIndex: Long = -1L,
    val correctIndex: Long = 0L,
    val isCorrect: Boolean = false,
    val explanation: String = ""
)

@IgnoreExtraProperties
data class QuizAttemptRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val quizId: String = "",
    val quizTitle: String = "",
    val quizType: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterTitle: String = "",
    val score: Long = 0L,
    val totalQuestions: Long = 0L,
    val accuracyPercent: Double = 0.0,
    val timeTakenSeconds: Long = 0L,
    val examMode: Boolean = false,
    val answers: List<AttemptAnswerItem> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class McqUploadRecord(
    @DocumentId val id: String = "",
    val createdBy: String = "",
    val fileName: String = "",
    val fileType: String = "image", // image | pdf
    val storagePath: String = "",
    val downloadUrl: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterNumber: Long = 1L,
    val chapterTitle: String = "",
    val extractedCount: Long = 0L,
    val reviewedCount: Long = 0L,
    val ocrStatus: String = "pending_review", // pending_review | reviewed | failed
    val storageSynced: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class QuizModeType(
    val wireKey: String,
    val labelBn: String,
    val subtitleBn: String
) {
    PRACTICE("practice", "MCQ প্র্যাকটিস", "সাথে সাথে ব্যাখ্যা ও উত্তর দেখুন"),
    BOOK_MCQ("book", "বইয়ের MCQ", "পাঠ্যবই ও বোর্ড মানের নির্বাচিত প্রশ্ন"),
    AGENT_UPLOADED("agent_uploaded", "এজেন্ট কুইজ", "এজেন্ট কর্তৃক যাচাইকৃত ও প্রকাশিত কুইজ"),
    RANDOM("random", "র‍্যান্ডম কুইজ", "সকল অধ্যায় থেকে মিশ্র দ্রুত কুইজ"),
    CHAPTER_WISE("chapter", "অধ্যায়ভিত্তিক", "নির্দিষ্ট অধ্যায়ের গভীর অনুশীলন"),
    FULL_SUBJECT("full_subject", "পূর্ণ বিষয়", "একটি বিষয়ের সব অধ্যায়ের সমন্বিত টেস্ট"),
    TIMED("timed", "টাইমড কুইজ", "সময়সীমা অনুযায়ী দ্রুত উত্তর দেওয়ার চ্যালেঞ্জ"),
    EXAM_MODE("exam_mode", "এক্সাম মোড", "সাবমিটের পর চূড়ান্ত ফলাফল ও বিশ্লেষণ")
}

data class PlayableMcq(
    val id: String,
    val subjectId: String,
    val subjectName: String,
    val chapterNumber: Int,
    val chapterTitle: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val difficulty: String = "medium",
    val sourceBadge: String = "বই"
)

data class DraftExtractedMcq(
    val tempId: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val difficulty: String = "medium"
)

sealed interface RemoteUiState<out T> {
    data object Loading : RemoteUiState<Nothing>
    data class Success<T>(val data: T) : RemoteUiState<T>
    data class Error(val message: String) : RemoteUiState<Nothing>
}
