package com.example.data.model

import com.example.data.local.ScheduledTaskEntity
import com.example.data.local.StudyPlanConfigEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class PlanDuration(val months: Int, val days: Int, val labelBn: String, val tag: String) {
    FOUR_MONTHS(4, 120, "৪ মাস (১৬ সপ্তাহ)", "FAST TRACK"),
    FIVE_MONTHS(5, 150, "৫ মাস (২০ সপ্তাহ)", "BALANCED PRO"),
    SIX_MONTHS(6, 180, "৬ মাস (২৪ সপ্তাহ)", "COMPLETE MASTERY")
}

enum class DailyStudyHours(val hours: Int, val labelBn: String, val descriptionBn: String) {
    FOUR_HOURS(4, "দৈনিক ৪ ঘণ্টা", "নিয়মিত স্কুল ডেস রুটিন (২ ঘণ্টা + ২ ঘণ্টা)"),
    FIVE_HOURS(5, "দৈনিক ৫ ঘণ্টা", "ব্যালান্সড ফোকাস প্রিপারেশন (২.৫ ঘণ্টা + ২.৫ ঘণ্টা)"),
    SIX_HOURS(6, "দৈনিক ৬ ঘণ্টা", "ইনটেন্সিভ কামব্যাক মোড (৩ ঘণ্টা + ৩ ঘণ্টা)")
}

enum class ChapterDifficulty(val labelBn: String, val defaultDays: Int) {
    EASY("সহজ অধ্যায় (Easy)", 1),
    NORMAL("সাধারণ অধ্যায় (Normal)", 2),
    DIFFICULT("কঠিন অধ্যায় (Difficult)", 3),
    VERY_DIFFICULT("খুব কঠিন অধ্যায় (Very Difficult)", 5)
}

/**
 * Metadata for tracking schedule metrics across the plan
 */
data class PlanProgressMetrics(
    val totalChapters: Int = 105,
    val completedChapters: Int = 0,
    val remainingChapters: Int = 105,
    val syllabusPercent: Int = 0,
    val totalPlanDays: Int = 120,
    val elapsedDays: Int = 0,
    val remainingDays: Int = 120,
    val dailyHours: Int = 4,
    val pendingMcqCount: Int = 0,
    val pendingCqCount: Int = 0,
    val pendingBoardQuestionCount: Int = 0,
    val missedTasksCount: Int = 0,
    val targetCompletionDate: String = ""
)

/**
 * Detailed progress metrics for SSC 2028 Bangla 1st Paper (Prose + Poetry)
 */
data class Bangla1ProgressSummary(
    val proseTotal: Int = 25,
    val proseCompleted: Int = 0,
    val poetryTotal: Int = 28,
    val poetryCompleted: Int = 0,
    val totalChapters: Int = 53,
    val completedChapters: Int = 0,
    val remainingChapters: Int = 53,
    val percentage: Int = 0,
    val plannedDays: Int = 81,
    val mcqCompleted: Int = 0,
    val mcqTotal: Int = 1060,
    val cqCompleted: Int = 0,
    val cqTotal: Int = 106,
    val boardCompleted: Int = 0,
    val boardTotal: Int = 265
)

/**
 * Detailed progress metrics for SSC 2028 Mathematics Priority Interface (General Math + Higher Math = 31 chapters)
 */
data class MathPriorityMetrics(
    val generalMathTotal: Int = 17,
    val generalMathCompleted: Int = 0,
    val generalMathPercent: Int = 0,
    val higherMathTotal: Int = 14,
    val higherMathCompleted: Int = 0,
    val higherMathPercent: Int = 0,
    val totalChapters: Int = 31,
    val totalCompleted: Int = 0,
    val totalPercent: Int = 0,
    val importantCount: Int = 28,
    val normalCount: Int = 3,
    val lowCount: Int = 0
)

/**
 * Detailed progress metrics for SSC 2028 Science Priority Dashboard (Physics 13 + Chemistry 12 + Biology 14 = 39 chapters)
 */
data class SciencePriorityMetrics(
    val physicsTotal: Int = 13,
    val physicsCompleted: Int = 0,
    val physicsRemaining: Int = 13,
    val physicsPercent: Int = 0,
    val chemistryTotal: Int = 12,
    val chemistryCompleted: Int = 0,
    val chemistryRemaining: Int = 12,
    val chemistryPercent: Int = 0,
    val biologyTotal: Int = 14,
    val biologyCompleted: Int = 0,
    val biologyRemaining: Int = 14,
    val biologyPercent: Int = 0,
    val totalChapters: Int = 39,
    val totalCompleted: Int = 0,
    val totalRemaining: Int = 39,
    val totalPercent: Int = 0,
    val importantCount: Int = 31,
    val normalCount: Int = 8,
    val lowCount: Int = 0
)

/**
 * Detailed progress metrics for SSC 2028 Social Studies & ICT Priority Dashboard (BGS 14 + Islam 5 + ICT 7 = 26 chapters)
 */
data class SocialIctPriorityMetrics(
    val bgsTotal: Int = 14,
    val bgsCompleted: Int = 0,
    val bgsRemaining: Int = 14,
    val bgsPercent: Int = 0,
    val islamTotal: Int = 5,
    val islamCompleted: Int = 0,
    val islamRemaining: Int = 5,
    val islamPercent: Int = 0,
    val ictTotal: Int = 7,
    val ictCompleted: Int = 0,
    val ictRemaining: Int = 7,
    val ictPercent: Int = 0,
    val totalChapters: Int = 26,
    val totalCompleted: Int = 0,
    val totalRemaining: Int = 26,
    val totalPercent: Int = 0,
    val importantCount: Int = 24,
    val normalCount: Int = 2,
    val lowCount: Int = 0
)

object StudyPlanGenerator {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("dd MMM, yyyy", Locale.getDefault())

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
    fun formatDisplayDate(millis: Long): String = displayDateFormat.format(Date(millis))

    fun getDifficultyForChapter(subjectId: String, chapterNumber: Int): ChapterDifficulty {
        return when (subjectId) {
            "bangla_1" -> {
                val chapter = SscSyllabusData.getChapter("bangla_1", chapterNumber)
                if (chapter?.importanceTag == "⭐") ChapterDifficulty.NORMAL else ChapterDifficulty.EASY
            }
            "general_math" -> when (chapterNumber) {
                3, 8, 9, 10, 16 -> ChapterDifficulty.DIFFICULT // Algebra, Circle, Trig, Mensuration
                else -> ChapterDifficulty.NORMAL
            }
            "higher_math" -> when (chapterNumber) {
                3, 8, 10, 11 -> ChapterDifficulty.VERY_DIFFICULT // Geometry, Trig, Coordinate, Binomial
                1, 2, 7 -> ChapterDifficulty.DIFFICULT
                else -> ChapterDifficulty.NORMAL
            }
            "physics" -> when (chapterNumber) {
                2, 3, 4, 8, 9, 11 -> ChapterDifficulty.DIFFICULT // Motion, Force, Energy, Optics, Current Electricity
                6, 10, 13 -> ChapterDifficulty.EASY // Thermal effect, Static Electricity, Radioactivity (☆)
                else -> ChapterDifficulty.NORMAL
            }
            "chemistry" -> when (chapterNumber) {
                6, 7 -> ChapterDifficulty.VERY_DIFFICULT // Mole concept, Chemical Reactions
                4, 5, 8 -> ChapterDifficulty.DIFFICULT
                11, 12 -> ChapterDifficulty.EASY // Fossil resources, Everyday chemistry (☆)
                else -> ChapterDifficulty.NORMAL
            }
            "biology" -> when (chapterNumber) {
                4, 6, 11, 12 -> ChapterDifficulty.DIFFICULT // Bioenergetics, Transport, Reproduction, Genetics
                1, 9, 14 -> ChapterDifficulty.EASY // Introduction, Locomotion, Biotechnology (☆)
                else -> ChapterDifficulty.NORMAL
            }
            "english_2" -> when (chapterNumber) {
                2, 3 -> ChapterDifficulty.DIFFICULT // Right form of verbs, Changing sentences
                else -> ChapterDifficulty.NORMAL
            }
            "bangla_2" -> when (chapterNumber) {
                4, 5, 7 -> ChapterDifficulty.DIFFICULT // ণ-ত্ব/ষ-ত্ব, সমাস, কারক
                else -> ChapterDifficulty.NORMAL
            }
            "bgs" -> when (chapterNumber) {
                1, 2, 3, 6, 8 -> ChapterDifficulty.DIFFICULT
                4, 11 -> ChapterDifficulty.EASY
                else -> ChapterDifficulty.NORMAL
            }
            "islam_moral" -> ChapterDifficulty.NORMAL
            "ict" -> when (chapterNumber) {
                4, 6, 7 -> ChapterDifficulty.DIFFICULT
                else -> ChapterDifficulty.NORMAL
            }
            else -> ChapterDifficulty.NORMAL
        }
    }

    /**
     * Generates a complete day-by-day study routine for all 12 SSC subjects
     * matching the student's selected duration (120, 150, or 180 days).
     */
    fun generateCompleteSchedule(
        durationMonths: Int,
        dailyHours: Int,
        startDateMillis: Long = System.currentTimeMillis(),
        easyDays: Int = 1,
        normalDays: Int = 2,
        difficultDays: Int = 3,
        veryDifficultDays: Int = 5
    ): Pair<StudyPlanConfigEntity, List<ScheduledTaskEntity>> {
        val totalDays = when (durationMonths) {
            4 -> 120
            5 -> 150
            else -> 180
        }

        val calendar = Calendar.getInstance().apply {
            timeInMillis = startDateMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // We organize subjects into 2 parallel daily tracks:
        // Track A (STEM & High Cognitive Load): General Math, Higher Math, Physics, Chemistry, Biology
        // Track B (Languages, Social, ICT, Islam): Bangla 1, Bangla 2, English 1, English 2, ICT, BGS, Islam
        val stemSubjects = SscSyllabusData.subjects.filter { it.category == "Science" }
        val humanitiesAndLanguages = SscSyllabusData.subjects.filter { it.category != "Science" }

        data class ChapterQueueItem(
            val subjectId: String,
            val subjectName: String,
            val chapterNumber: Int,
            val chapterTitle: String,
            val difficulty: ChapterDifficulty
        )

        val stemQueue = mutableListOf<ChapterQueueItem>()
        stemSubjects.forEach { sub ->
            sub.chapters.forEach { ch ->
                stemQueue.add(
                    ChapterQueueItem(
                        subjectId = sub.id,
                        subjectName = sub.nameBn,
                        chapterNumber = ch.number,
                        chapterTitle = ch.title,
                        difficulty = getDifficultyForChapter(sub.id, ch.number)
                    )
                )
            }
        }

        val trackBQueue = mutableListOf<ChapterQueueItem>()
        humanitiesAndLanguages.forEach { sub ->
            sub.chapters.forEach { ch ->
                trackBQueue.add(
                    ChapterQueueItem(
                        subjectId = sub.id,
                        subjectName = sub.nameBn,
                        chapterNumber = ch.number,
                        chapterTitle = ch.title,
                        difficulty = getDifficultyForChapter(sub.id, ch.number)
                    )
                )
            }
        }

        val generatedTasks = mutableListOf<ScheduledTaskEntity>()
        val hoursPerSlot = dailyHours.toFloat() / 2.0f

        var currentStemIndex = 0
        var currentTrackBIndex = 0
        var stemDayCounter = 0
        var trackBDayCounter = 0

        // Reserve the last 15-20 days for Full Syllabus Model Tests & Test Paper Solving
        val modelTestReserveDays = if (totalDays >= 180) 24 else if (totalDays >= 150) 18 else 14
        val coreLearningDays = totalDays - modelTestReserveDays

        for (day in 1..coreLearningDays) {
            val dateMillis = calendar.timeInMillis
            val dateStr = dateFormat.format(Date(dateMillis))

            // Every 7th day is a dedicated Weekly Milestone Revision & Board CQ Solving day
            if (day % 7 == 0) {
                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = "stem_weekly_revision",
                        subjectName = "বিজ্ঞান ও গণিত সাপ্তাহিক রিভিশন",
                        chapterNumber = day / 7,
                        chapterTitle = "সপ্তাহ ${(day / 7)}: বিগত সপ্তাহের গণিত ও বিজ্ঞানের কঠিন সৃজনশীল সমাধান",
                        taskType = "REVISION",
                        allocatedHours = hoursPerSlot,
                        mcqCount = 30,
                        cqCount = 4,
                        boardQuestionCount = 12
                    )
                )
                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = "lang_weekly_revision",
                        subjectName = "ভাষা ও সাধারণ বিষয় রিভিশন",
                        chapterNumber = day / 7,
                        chapterTitle = "সপ্তাহ ${(day / 7)}: ইংরেজি ২য় গ্রামার ও বাংলা ২য় ব্যাকরণ বোর্ড টেস্ট",
                        taskType = "BOARD_PRACTICE",
                        allocatedHours = hoursPerSlot,
                        mcqCount = 25,
                        cqCount = 3,
                        boardQuestionCount = 10
                    )
                )
                calendar.add(Calendar.DAY_OF_YEAR, 1)
                continue
            }

            // Slot 1: Track A (STEM)
            if (currentStemIndex < stemQueue.size) {
                val stemItem = stemQueue[currentStemIndex]
                val requiredDays = when (stemItem.difficulty) {
                    ChapterDifficulty.EASY -> easyDays
                    ChapterDifficulty.NORMAL -> normalDays
                    ChapterDifficulty.DIFFICULT -> difficultDays
                    ChapterDifficulty.VERY_DIFFICULT -> veryDifficultDays
                }

                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = stemItem.subjectId,
                        subjectName = stemItem.subjectName,
                        chapterNumber = stemItem.chapterNumber,
                        chapterTitle = stemItem.chapterTitle,
                        taskType = "CHAPTER_STUDY",
                        allocatedHours = hoursPerSlot,
                        mcqCount = if (stemItem.difficulty == ChapterDifficulty.VERY_DIFFICULT) 35 else 25,
                        cqCount = if (stemItem.difficulty == ChapterDifficulty.VERY_DIFFICULT) 5 else 3,
                        boardQuestionCount = 10
                    )
                )

                stemDayCounter++
                if (stemDayCounter >= requiredDays) {
                    stemDayCounter = 0
                    currentStemIndex++
                }
            } else {
                // If all STEM chapters completed, schedule Board Question Drill
                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = "general_math",
                        subjectName = "সাধারণ গণিত ও বিজ্ঞান",
                        chapterNumber = (day % 10) + 1,
                        chapterTitle = "বোর্ড টেস্ট পেপার সমাধান ও সময় ধরে অঙ্ক প্র্যাকটিস",
                        taskType = "BOARD_PRACTICE",
                        allocatedHours = hoursPerSlot,
                        mcqCount = 30,
                        cqCount = 4,
                        boardQuestionCount = 15
                    )
                )
            }

            // Slot 2: Track B (Humanities & Languages)
            if (currentTrackBIndex < trackBQueue.size) {
                val trackBItem = trackBQueue[currentTrackBIndex]
                val requiredDays = when (trackBItem.difficulty) {
                    ChapterDifficulty.EASY -> easyDays
                    ChapterDifficulty.NORMAL -> normalDays
                    ChapterDifficulty.DIFFICULT -> difficultDays
                    ChapterDifficulty.VERY_DIFFICULT -> veryDifficultDays
                }

                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = trackBItem.subjectId,
                        subjectName = trackBItem.subjectName,
                        chapterNumber = trackBItem.chapterNumber,
                        chapterTitle = trackBItem.chapterTitle,
                        taskType = "CHAPTER_STUDY",
                        allocatedHours = hoursPerSlot,
                        mcqCount = 20,
                        cqCount = 3,
                        boardQuestionCount = 8
                    )
                )

                trackBDayCounter++
                if (trackBDayCounter >= requiredDays) {
                    trackBDayCounter = 0
                    currentTrackBIndex++
                }
            } else {
                // If all Track B chapters completed, schedule English/Bangla Model Drills
                generatedTasks.add(
                    ScheduledTaskEntity(
                        id = UUID.randomUUID().toString(),
                        dayNumber = day,
                        dateString = dateStr,
                        dateMillis = dateMillis,
                        subjectId = "english_2",
                        subjectName = "ইংরেজি ২য় ও বাংলা ২য় পত্র",
                        chapterNumber = (day % 7) + 1,
                        chapterTitle = "বোর্ড গ্রামার রুলস ও প্যাসেজ ন্যারেশন স্পিড টেস্ট",
                        taskType = "BOARD_PRACTICE",
                        allocatedHours = hoursPerSlot,
                        mcqCount = 25,
                        cqCount = 3,
                        boardQuestionCount = 10
                    )
                )
            }

            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Final Model Test & Board Paper Solving Phase (Last 14-24 days)
        for (day in (coreLearningDays + 1)..totalDays) {
            val dateMillis = calendar.timeInMillis
            val dateStr = dateFormat.format(Date(dateMillis))

            generatedTasks.add(
                ScheduledTaskEntity(
                    id = UUID.randomUUID().toString(),
                    dayNumber = day,
                    dateString = dateStr,
                    dateMillis = dateMillis,
                    subjectId = "full_model_test",
                    subjectName = "এসএসসি ২০২৮ ফুল মডেল টেস্ট",
                    chapterNumber = day - coreLearningDays,
                    chapterTitle = "মডেল টেস্ট #${day - coreLearningDays}: ১০০ নম্বরের পূর্ণাঙ্গ বোর্ড সিমুলেশন এক্সাম",
                    taskType = "MODEL_TEST",
                    allocatedHours = hoursPerSlot,
                    mcqCount = 30,
                    cqCount = 7,
                    boardQuestionCount = 15
                )
            )

            generatedTasks.add(
                ScheduledTaskEntity(
                    id = UUID.randomUUID().toString(),
                    dayNumber = day,
                    dateString = dateStr,
                    dateMillis = dateMillis,
                    subjectId = "mistakes_revision",
                    subjectName = "ভুল সংশোধন ও দুর্বল টপিক রিভিশন",
                    chapterNumber = day - coreLearningDays,
                    chapterTitle = "মডেল টেস্টের ভুল উত্তর রিভিউ এবং MRH AI বিশ্লেষণ",
                    taskType = "REVISION",
                    allocatedHours = hoursPerSlot,
                    mcqCount = 20,
                    cqCount = 2,
                    boardQuestionCount = 10
                )
            )

            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        val targetCompletionMillis = calendar.timeInMillis - 24 * 60 * 60 * 1000

        val config = StudyPlanConfigEntity(
            id = "active_plan",
            durationMonths = durationMonths,
            dailyStudyHours = dailyHours,
            startDateMillis = startDateMillis,
            targetCompletionDateMillis = targetCompletionMillis,
            extendedDaysTotal = 0,
            easyChapterDays = easyDays,
            normalChapterDays = normalDays,
            difficultChapterDays = difficultDays,
            veryDifficultChapterDays = veryDifficultDays,
            totalPlanDays = totalDays,
            createdAt = System.currentTimeMillis()
        )

        return Pair(config, generatedTasks)
    }

    /**
     * Feature 4: Extends a chapter by extraDays.
     * Shifts subsequent uncompleted tasks forward by extraDays,
     * preserves already completed tasks, and updates the final target completion date.
     */
    fun extendChapterTasks(
        targetChapterTitle: String,
        extraDays: Int,
        allTasks: List<ScheduledTaskEntity>,
        currentConfig: StudyPlanConfigEntity
    ): Pair<StudyPlanConfigEntity, List<ScheduledTaskEntity>> {
        val updatedTasks = mutableListOf<ScheduledTaskEntity>()
        var foundChapter = false
        val millisToAdd = extraDays.toLong() * 24 * 60 * 60 * 1000

        allTasks.forEach { task ->
            if (task.chapterTitle == targetChapterTitle && !task.isCompleted) {
                foundChapter = true
                updatedTasks.add(
                    task.copy(
                        extendedDays = task.extendedDays + extraDays,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } else if (foundChapter && !task.isCompleted) {
                // Shift subsequent uncompleted tasks forward
                val newDateMillis = task.dateMillis + millisToAdd
                val newDateStr = dateFormat.format(Date(newDateMillis))
                updatedTasks.add(
                    task.copy(
                        dayNumber = task.dayNumber + extraDays,
                        dateMillis = newDateMillis,
                        dateString = newDateStr,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } else {
                // Keep completed or earlier tasks as they are
                updatedTasks.add(task)
            }
        }

        val updatedConfig = currentConfig.copy(
            extendedDaysTotal = currentConfig.extendedDaysTotal + extraDays,
            targetCompletionDateMillis = currentConfig.targetCompletionDateMillis + millisToAdd
        )

        return Pair(updatedConfig, updatedTasks)
    }

    /**
     * Feature 5: Generates a Recovery Plan for missed tasks
     * by moving missed tasks into upcoming dates without exceeding daily study hours.
     */
    fun recoverMissedTasks(
        allTasks: List<ScheduledTaskEntity>,
        todayMillis: Long = System.currentTimeMillis()
    ): List<ScheduledTaskEntity> {
        val todayStr = dateFormat.format(Date(todayMillis))
        val updatedTasks = allTasks.toMutableList()

        val missedTasks = updatedTasks.filter { task ->
            task.dateString < todayStr && !task.isCompleted && !task.isRecovered
        }

        if (missedTasks.isEmpty()) return allTasks

        // Shift each missed task's target date to today onwards
        val cal = Calendar.getInstance().apply { timeInMillis = todayMillis }
        missedTasks.forEachIndexed { index, missedTask ->
            val targetCal = Calendar.getInstance().apply {
                timeInMillis = todayMillis
                add(Calendar.DAY_OF_YEAR, index)
            }
            val newMillis = targetCal.timeInMillis
            val newStr = dateFormat.format(Date(newMillis))

            val taskIndex = updatedTasks.indexOfFirst { it.id == missedTask.id }
            if (taskIndex != -1) {
                updatedTasks[taskIndex] = missedTask.copy(
                    dateMillis = newMillis,
                    dateString = newStr,
                    taskType = "RECOVERY",
                    notes = "সংগৃহীত রিকভারি টাস্ক (আগে মিস হয়েছিল)",
                    updatedAt = System.currentTimeMillis()
                )
            }
        }

        return updatedTasks
    }
}
