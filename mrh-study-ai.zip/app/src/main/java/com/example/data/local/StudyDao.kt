package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {

    // --- Chapters Progress ---
    @Query("SELECT * FROM chapter_progress WHERE subjectId = :subjectId ORDER BY chapterNumber ASC")
    fun getChaptersForSubject(subjectId: String): Flow<List<ChapterProgressEntity>>

    @Query("SELECT * FROM chapter_progress")
    fun getAllChapters(): Flow<List<ChapterProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateChapter(chapter: ChapterProgressEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertInitialChapters(chapters: List<ChapterProgressEntity>)

    @Query("DELETE FROM chapter_progress WHERE subjectId = :subjectId")
    suspend fun deleteChaptersForSubject(subjectId: String)

    @Query("UPDATE chapter_progress SET isCompleted = :isCompleted, updatedAt = :updatedAt, isSynced = 0 WHERE id = :id")
    suspend fun updateChapterCompletion(id: String, isCompleted: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE chapter_progress SET isCompleted = 0, updatedAt = :updatedAt, isSynced = 0 WHERE subjectId = :subjectId")
    suspend fun resetSubjectCompletion(subjectId: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE chapter_progress SET notes = :notes, updatedAt = :updatedAt, isSynced = 0 WHERE id = :id")
    suspend fun updateChapterNotes(id: String, notes: String, updatedAt: Long = System.currentTimeMillis())

    // --- Study Sessions ---
    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllStudySessions(): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySessionEntity)

    @Query("SELECT SUM(durationMinutes) FROM study_sessions")
    fun getTotalStudyMinutes(): Flow<Int?>

    // --- Daily Goals ---
    @Query("SELECT * FROM daily_goals WHERE dateString = :dateString ORDER BY updatedAt ASC")
    fun getGoalsForDate(dateString: String): Flow<List<DailyGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: DailyGoalEntity)

    @Update
    suspend fun updateGoal(goal: DailyGoalEntity)

    @Query("UPDATE daily_goals SET isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun toggleGoalCompletion(id: String, isCompleted: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM daily_goals WHERE id = :id")
    suspend fun deleteGoal(id: String)

    // --- Exam Results ---
    @Query("SELECT * FROM exam_results ORDER BY timestamp DESC")
    fun getAllExamResults(): Flow<List<ExamResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamResult(result: ExamResultEntity)

    // --- Mistakes Notebook ---
    @Query("SELECT * FROM mistakes_notebook ORDER BY timestamp DESC")
    fun getAllMistakes(): Flow<List<MistakeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMistake(mistake: MistakeEntity)

    @Query("UPDATE mistakes_notebook SET isResolved = :isResolved WHERE id = :id")
    suspend fun updateMistakeStatus(id: String, isResolved: Boolean)

    @Query("DELETE FROM mistakes_notebook WHERE id = :id")
    suspend fun deleteMistake(id: String)

    // --- Chat History ---
    @Query("SELECT * FROM chat_history ORDER BY timestamp ASC")
    fun getChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_history")
    suspend fun clearChatHistory()

    // --- Future Study Plan: Config ---
    @Query("SELECT * FROM study_plan_config WHERE id = 'active_plan' LIMIT 1")
    fun getActivePlanConfig(): Flow<StudyPlanConfigEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlanConfig(config: StudyPlanConfigEntity)

    @Update
    suspend fun updatePlanConfig(config: StudyPlanConfigEntity)

    // --- Future Study Plan: Scheduled Tasks ---
    @Query("SELECT * FROM scheduled_study_tasks ORDER BY dayNumber ASC, dateMillis ASC")
    fun getAllScheduledTasks(): Flow<List<ScheduledTaskEntity>>

    @Query("SELECT * FROM scheduled_study_tasks WHERE dateString = :dateString ORDER BY dayNumber ASC")
    fun getTasksForDate(dateString: String): Flow<List<ScheduledTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduledTasks(tasks: List<ScheduledTaskEntity>)

    @Update
    suspend fun updateScheduledTask(task: ScheduledTaskEntity)

    @Query("DELETE FROM scheduled_study_tasks")
    suspend fun clearAllScheduledTasks()

    @Query("UPDATE scheduled_study_tasks SET isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTaskCompletion(id: String, isCompleted: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE scheduled_study_tasks SET textbookRead = :textbookRead, conceptUnderstood = :conceptUnderstood, notesCreated = :notesCreated, mcqPracticeCompleted = :mcqCompleted, cqPracticeCompleted = :cqCompleted, boardQuestionsSolved = :boardSolved, chapterTestCompleted = :testCompleted, mistakesReviewed = :mistakesReviewed, isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTaskPhases(
        id: String,
        textbookRead: Boolean,
        conceptUnderstood: Boolean,
        notesCreated: Boolean,
        mcqCompleted: Boolean,
        cqCompleted: Boolean,
        boardSolved: Boolean,
        testCompleted: Boolean,
        mistakesReviewed: Boolean,
        isCompleted: Boolean,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("UPDATE scheduled_study_tasks SET textbookMinutes = :textbook, mcqMinutes = :mcq, cqMinutes = :cq, boardSolveMinutes = :board, revisionMinutes = :revision WHERE id = :id")
    suspend fun updateTaskPhaseTimes(
        id: String,
        textbook: Int,
        mcq: Int,
        cq: Int,
        board: Int,
        revision: Int
    )

    @Query("UPDATE scheduled_study_tasks SET isRecovered = 1, isCompleted = 1, updatedAt = :updatedAt WHERE id = :id")
    suspend fun markTaskRecovered(id: String, updatedAt: Long = System.currentTimeMillis())
}
