package com.example.data.remote

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.R
import com.example.data.model.AgentAccount
import com.example.data.model.McqQuestionRecord
import com.example.data.model.McqUploadRecord
import com.example.data.model.QuizAttemptRecord
import com.example.data.model.QuizCollectionRecord
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.storage
import com.google.firebase.storage.storageMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

private const val TAG = "QuizAgentRepository"

class QuizAgentRepository(
    private val db: FirebaseFirestore,
    private val storage: FirebaseStorage? = null
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        storage = defaultStorageOrNull()
    )

    private fun requireUserId(): String =
        Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    // --- Agent Roles & Access ---

    fun observeAgentAccount(uid: String): Flow<AgentAccount?> {
        val docRef = db.collection(COLLECTION_AGENTS).document(uid)
        return docRef.snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(AgentAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.GET, docRef.path)
                }
                throw error
            }
    }

    fun observeAllAgents(): Flow<List<AgentAccount>> {
        val colRef = db.collection(COLLECTION_AGENTS)
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(AgentAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, colRef.path)
                }
                throw error
            }
    }

    suspend fun ensureBootstrappedAgentProfile(
        username: String = "Mr1122",
        displayName: String = "MRH Primary Agent",
        email: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_AGENTS).document(uid)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val account = AgentAccount(
                    uid = uid,
                    username = username.trim().take(40).ifBlank { "Mr1122" },
                    displayName = displayName.trim().take(80).ifBlank { "MRH Primary Agent" },
                    email = email.trim().take(120),
                    role = "agent",
                    active = true,
                    assignedBy = uid,
                    createdAt = null,
                    updatedAt = null
                )
                docRef.set(account).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun upsertAgentRole(
        targetUid: String,
        username: String,
        displayName: String,
        email: String,
        active: Boolean = true
    ): Result<Unit> {
        val callerUid = requireUserId()
        val cleanUid = targetUid.trim()
        require(cleanUid.isNotBlank()) { "Agent UID must not be blank" }
        val docRef = db.collection(COLLECTION_AGENTS).document(cleanUid)
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                val updates = mapOf(
                    "username" to username.trim().take(40),
                    "displayName" to displayName.trim().take(80),
                    "email" to email.trim().take(120),
                    "role" to "agent",
                    "active" to active,
                    "assignedBy" to callerUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val account = AgentAccount(
                    uid = cleanUid,
                    username = username.trim().take(40),
                    displayName = displayName.trim().take(80),
                    email = email.trim().take(120),
                    role = "agent",
                    active = active,
                    assignedBy = callerUid,
                    createdAt = null,
                    updatedAt = null
                )
                docRef.set(account).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteAgentRole(targetUid: String): Result<Unit> {
        requireUserId()
        val docRef = db.collection(COLLECTION_AGENTS).document(targetUid.trim())
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- MCQs ---

    fun observePublishedMcqs(): Flow<List<McqQuestionRecord>> {
        val query = db.collection(COLLECTION_MCQS)
            .whereEqualTo("status", "published")
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(McqQuestionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_MCQS)
                }
                throw error
            }
    }

    fun observeAgentMcqs(agentUid: String): Flow<List<McqQuestionRecord>> {
        val query = db.collection(COLLECTION_MCQS)
            .whereEqualTo("createdBy", agentUid)
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(McqQuestionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_MCQS)
                }
                throw error
            }
    }

    fun observeAllMcqsAdmin(): Flow<List<McqQuestionRecord>> {
        val colRef = db.collection(COLLECTION_MCQS)
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(McqQuestionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, colRef.path)
                }
                throw error
            }
    }

    suspend fun createMcq(mcq: McqQuestionRecord): Result<String> {
        val uid = requireUserId()
        require(mcq.options.size == 4) { "Exactly 4 MCQ options are required." }
        require(mcq.correctIndex in 0L..3L) { "correctIndex must be in 0..3." }
        require(mcq.status != "published" || mcq.ocrReviewed) {
            "OCR/unreviewed MCQs cannot be published before agent review."
        }
        val docRef = if (mcq.id.isNotBlank()) {
            db.collection(COLLECTION_MCQS).document(mcq.id)
        } else {
            db.collection(COLLECTION_MCQS).document()
        }
        val record = mcq.copy(
            id = "",
            question = mcq.question.trim(),
            options = mcq.options.map { it.trim() },
            explanation = mcq.explanation.trim(),
            createdBy = uid,
            createdAt = null,
            updatedAt = null
        )
        return try {
            docRef.set(record).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateMcq(mcq: McqQuestionRecord): Result<Unit> {
        requireUserId()
        require(mcq.id.isNotBlank()) { "MCQ ID must not be blank for update." }
        require(mcq.options.size == 4) { "Exactly 4 MCQ options are required." }
        require(mcq.correctIndex in 0L..3L) { "correctIndex must be in 0..3." }
        require(mcq.status != "published" || mcq.ocrReviewed) {
            "OCR/unreviewed MCQs cannot be published before agent review."
        }
        val docRef = db.collection(COLLECTION_MCQS).document(mcq.id)
        val updates = mapOf(
            "subjectId" to mcq.subjectId,
            "subjectName" to mcq.subjectName,
            "chapterNumber" to mcq.chapterNumber,
            "chapterTitle" to mcq.chapterTitle,
            "question" to mcq.question.trim(),
            "options" to mcq.options.map { it.trim() },
            "correctIndex" to mcq.correctIndex,
            "explanation" to mcq.explanation.trim(),
            "difficulty" to mcq.difficulty,
            "sourceType" to mcq.sourceType,
            "sourceFileUrl" to mcq.sourceFileUrl,
            "sourceStoragePath" to mcq.sourceStoragePath,
            "ocrReviewed" to mcq.ocrReviewed,
            "status" to mcq.status,
            "quizId" to mcq.quizId,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getMcqById(mcqId: String): Result<McqQuestionRecord?> {
        requireUserId()
        val docRef = db.collection(COLLECTION_MCQS).document(mcqId)
        return try {
            val snap = docRef.get().await()
            Result.success(
                if (snap.exists()) {
                    snap.toObject(McqQuestionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteMcq(mcqId: String): Result<Unit> {
        requireUserId()
        val docRef = db.collection(COLLECTION_MCQS).document(mcqId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- Quizzes ---

    fun observePublishedQuizzes(): Flow<List<QuizCollectionRecord>> {
        val query = db.collection(COLLECTION_QUIZZES)
            .whereEqualTo("status", "published")
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(QuizCollectionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_QUIZZES)
                }
                throw error
            }
    }

    fun observeAgentQuizzes(agentUid: String): Flow<List<QuizCollectionRecord>> {
        val query = db.collection(COLLECTION_QUIZZES)
            .whereEqualTo("createdBy", agentUid)
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(QuizCollectionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_QUIZZES)
                }
                throw error
            }
    }

    fun observeAllQuizzesAdmin(): Flow<List<QuizCollectionRecord>> {
        val colRef = db.collection(COLLECTION_QUIZZES)
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(QuizCollectionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, colRef.path)
                }
                throw error
            }
    }

    suspend fun getQuizById(quizId: String): Result<QuizCollectionRecord?> {
        requireUserId()
        val docRef = db.collection(COLLECTION_QUIZZES).document(quizId)
        return try {
            val snap = docRef.get().await()
            Result.success(
                if (snap.exists()) {
                    snap.toObject(QuizCollectionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun createQuiz(quiz: QuizCollectionRecord): Result<String> {
        val uid = requireUserId()
        require(quiz.mcqIds.isNotEmpty()) { "At least one MCQ must be added to a quiz." }
        val docRef = if (quiz.id.isNotBlank()) {
            db.collection(COLLECTION_QUIZZES).document(quiz.id)
        } else {
            db.collection(COLLECTION_QUIZZES).document()
        }
        val record = quiz.copy(
            id = "",
            title = quiz.title.trim(),
            description = quiz.description.trim(),
            questionCount = quiz.mcqIds.size.toLong(),
            createdBy = uid,
            createdAt = null,
            updatedAt = null
        )
        return try {
            docRef.set(record).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateQuiz(quiz: QuizCollectionRecord): Result<Unit> {
        requireUserId()
        require(quiz.id.isNotBlank()) { "Quiz ID must not be blank for update." }
        require(quiz.mcqIds.isNotEmpty()) { "At least one MCQ must remain in the quiz." }
        val docRef = db.collection(COLLECTION_QUIZZES).document(quiz.id)
        val updates = mapOf(
            "title" to quiz.title.trim(),
            "description" to quiz.description.trim(),
            "subjectId" to quiz.subjectId,
            "subjectName" to quiz.subjectName,
            "chapterNumber" to quiz.chapterNumber,
            "chapterTitle" to quiz.chapterTitle,
            "quizType" to quiz.quizType,
            "difficulty" to quiz.difficulty,
            "durationMinutes" to quiz.durationMinutes,
            "mcqIds" to quiz.mcqIds,
            "questionCount" to quiz.mcqIds.size.toLong(),
            "status" to quiz.status,
            "createdByName" to quiz.createdByName,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteQuiz(quizId: String): Result<Unit> {
        requireUserId()
        val docRef = db.collection(COLLECTION_QUIZZES).document(quizId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- Student Quiz Attempts & History ---

    fun observeMyAttempts(userId: String): Flow<List<QuizAttemptRecord>> {
        val query = db.collection(COLLECTION_ATTEMPTS)
            .whereEqualTo("userId", userId)
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(QuizAttemptRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser?.uid == userId) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_ATTEMPTS)
                }
                throw error
            }
    }

    suspend fun getAttemptById(attemptId: String): Result<QuizAttemptRecord?> {
        requireUserId()
        val docRef = db.collection(COLLECTION_ATTEMPTS).document(attemptId)
        return try {
            val snap = docRef.get().await()
            Result.success(
                if (snap.exists()) {
                    snap.toObject(QuizAttemptRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun submitQuizAttempt(attempt: QuizAttemptRecord): Result<String> {
        val uid = requireUserId()
        require(attempt.totalQuestions >= 1L) { "Quiz attempt must have at least 1 question." }
        val docRef = if (attempt.id.isNotBlank()) {
            db.collection(COLLECTION_ATTEMPTS).document(attempt.id)
        } else {
            db.collection(COLLECTION_ATTEMPTS).document()
        }
        val cleanAttempt = attempt.copy(
            id = "",
            userId = uid,
            createdAt = null
        )
        return try {
            docRef.set(cleanAttempt).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    // --- Uploaded Images & PDFs Metadata + Firebase Storage ---

    fun observeAgentUploads(agentUid: String): Flow<List<McqUploadRecord>> {
        val query = db.collection(COLLECTION_UPLOADS)
            .whereEqualTo("createdBy", agentUid)
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(McqUploadRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, COLLECTION_UPLOADS)
                }
                throw error
            }
    }

    fun observeAllUploadsAdmin(): Flow<List<McqUploadRecord>> {
        val colRef = db.collection(COLLECTION_UPLOADS)
        return colRef.snapshots()
            .map { snapshot ->
                snapshot.toObjects(McqUploadRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                if (Firebase.auth.currentUser != null) {
                    handleFirestoreError(error, OperationType.LIST, colRef.path)
                }
                throw error
            }
    }

    suspend fun createUploadRecord(upload: McqUploadRecord): Result<String> {
        val uid = requireUserId()
        val docRef = if (upload.id.isNotBlank()) {
            db.collection(COLLECTION_UPLOADS).document(upload.id)
        } else {
            db.collection(COLLECTION_UPLOADS).document()
        }
        val cleanUpload = upload.copy(
            id = "",
            createdBy = uid,
            createdAt = null,
            updatedAt = null
        )
        return try {
            docRef.set(cleanUpload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateUploadRecord(
        uploadId: String,
        reviewedCount: Long,
        ocrStatus: String,
        storagePath: String? = null,
        downloadUrl: String? = null,
        storageSynced: Boolean? = null
    ): Result<Unit> {
        requireUserId()
        val docRef = db.collection(COLLECTION_UPLOADS).document(uploadId)
        val updates = mutableMapOf<String, Any>(
            "reviewedCount" to reviewedCount,
            "ocrStatus" to ocrStatus,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (storagePath != null) updates["storagePath"] = storagePath
        if (downloadUrl != null) updates["downloadUrl"] = downloadUrl
        if (storageSynced != null) updates["storageSynced"] = storageSynced

        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun uploadMediaBytesToStorage(
        fileName: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<Pair<String, String>> {
        val uid = requireUserId()
        val firebaseStorage = storage ?: return Result.failure(
            IllegalStateException("Firebase Storage SDK অনুপস্থিত বা কনফিগার করা হয়নি।")
        )
        val sanitizedName = fileName.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        val storagePath = "mcq_uploads/$uid/${System.currentTimeMillis()}_$sanitizedName"
        return try {
            val ref = firebaseStorage.reference.child(storagePath)
            val metadata = storageMetadata {
                contentType = mimeType
            }
            withTimeout(15_000L) {
                ref.putBytes(bytes, metadata).await()
                val downloadUrl: Uri = ref.downloadUrl.await()
                storagePath to downloadUrl.toString()
            }.let { Result.success(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Storage upload failed for $storagePath: ${e.message}")
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_AGENTS = "agents"
        const val COLLECTION_MCQS = "mcqs"
        const val COLLECTION_QUIZZES = "quizzes"
        const val COLLECTION_ATTEMPTS = "quiz_attempts"
        const val COLLECTION_UPLOADS = "mcq_uploads"

        private fun defaultStorageOrNull(): FirebaseStorage? = try {
            Firebase.storage
        } catch (_: Exception) {
            null
        }
    }
}
