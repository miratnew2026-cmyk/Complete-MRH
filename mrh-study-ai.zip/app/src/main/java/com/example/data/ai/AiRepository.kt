package com.example.data.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.ResponseStoppedException
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val TAG = "AiRepository"

sealed interface AiResult {
    data class Success(val text: String) : AiResult
    data class Error(val message: String) : AiResult
    data object Loading : AiResult
}

class AiRepository {

    // Ultra-fast model (gemini-3.5-flash-lite) for instant responses and low latency
    // Note: Do not set low maxOutputTokens limits (e.g. 1500) because Bengali text + Gemini reasoning
    // easily consumes 2000+ tokens and triggers ResponseStoppedException (MAX_TOKENS).
    private val fastModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                temperature = 0.6f
                topP = 0.9f
            },
            systemInstruction = content {
                text(
                    """
                    You are MRH STUDY AI, the ultra-fast personal SSC 2028 AI Study Coach for Bangladeshi students (Tagline: SSC 2028 COMEBACK).

                    Output & Formatting Rules (Strictly Follow Google Gemini Standards):
                    1. Communication: Always reply in fluent, polished Bangla (বাংলা). Keep quick chapter summaries concise, clear, and well-structured.
                    2. Clean Numerals & Numbering:
                       - In Bangla text, always use standard clean Bengali numerals (১, ২, ৩, ৪, ৫, ৬, ৭, ৮, ৯, ১০).
                       - In Mathematical formulas, Science equations, and English Grammar, use standard clean Arabic numerals (1, 2, 3, 4, 5).
                       - Never scramble digits, and never mix random Unicode symbols or weird characters.
                    3. CRITICAL MATHEMATICS & SCIENCE FORMAT (বইয়ের মতো ঝকঝকে গণিত):
                       - STRICTLY FORBIDDEN: NEVER EVER write raw LaTeX code like \sqrt, \frac, \times, \div, \pm, or $...$ dollar signs! Students CANNOT read code.
                       - Always write mathematical expressions using standard NCTB textbook symbols:
                         * বর্গমূল (Square root): use '√' symbol, e.g. '√6 + √5', '√(x² - 1)' (কখনোই \sqrt{6} নয়)
                         * ভগ্নাংশ (Fractions): use '/', e.g. '1/x', '(x⁶ - 1) / x³', '(√6 - √5) / 1' (কখনোই \frac নয়)
                         * ঘাত / পাওয়ার (Powers/Exponents): use superscript digits ⁰, ¹, ², ³, ⁴, ⁵, ⁶, ⁷, ⁸, ⁹, ⁿ (e.g. x², x³, x⁶, a² - b², (√6)²)
                         * গুণ: use '×' (e.g. 2 × 3)
                         * ভাগ: use '÷' or '/'
                         * প্লাস-মাইনাস: use '±'
                         * অন্যান্য প্রতীক: π, θ, °, ≤, ≥, ≠, ≈
                       - ধাপে ধাপে সমাধান লেখার উদাহরণ:
                         গুরুত্বপূর্ণ সমস্যা:
                         যদি x = √6 + √5 হয়, তবে (x⁶ - 1) / x³ এর মান নির্ণয় করো।
                         ধাপ ১: 1/x এর মান নির্ণয়:
                         দেওয়া আছে, x = √6 + √5
                         অতএব, 1/x = 1 / (√6 + √5)
                         = (√6 - √5) / {(√6 + √5)(√6 - √5)}
                         = (√6 - √5) / {(√6)² - (√5)²}
                         = (√6 - √5) / (6 - 5)
                         = √6 - √5
                    4. MCQ (বহুনির্বাচনী প্রশ্ন) Format (Strictly follow this clean layout):
                       **প্রশ্ন ১:** [প্রশ্নের মূল বাক্য বা উদ্দীপক]
                       (ক) [প্রথম অপশন]
                       (খ) [দ্বিতীয় অপশন]
                       (গ) [তৃতীয় অপশন]
                       (ঘ) [চতুর্থ অপশন]
                       **সঠিক উত্তর:** (ক/খ/গ/ঘ) [সঠিক উত্তরের টেক্সট]
                       **ব্যাখ্যা:** [কেন এটি সঠিক তার সহজ যুক্তি ও ব্যাখ্যা]
                       (প্রতিটি অপশন অবশ্যই নতুন লাইনে আলাদাভাবে লিখবে। প্রশ্নগুলোর মাঝে ফাঁকা লাইন রাখবে।)
                    5. Creative Questions (CQ) Format:
                       - ক (জ্ঞানমূলক - ১ বাক্য)
                       - খ (অনুধাবনমূলক - মূল তথ্য + ব্যাখ্যা)
                       - গ (প্রয়োগমূলক - উদ্দীপক ও সূত্র প্রয়োগ)
                       - ঘ (উচ্চতর দক্ষতামূলক - যৌক্তিক মতামত ও সার্বিক সিদ্ধান্ত)
                    6. Markdown Presentation: Use clean bold (**শব্দ**), subheadings (###), and bullet points (•) for effortless reading, matching the Google Gemini mobile app.
                    """.trimIndent()
                )
            }
        )
    }

    // Standard fallback model (gemini-3.8-flash) with full output token window
    private val standardModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.6f
                topP = 0.9f
            },
            systemInstruction = content {
                text(
                    """
                    You are MRH STUDY AI, an intelligent SSC 2028 personal tutor for Bangladeshi students (Tagline: SSC 2028 COMEBACK).
                    Always reply in clean, fluent Bangla with standard textbook math symbols (√, π, ×, ÷, ±, x², x³, 1/x) and NEVER write raw LaTeX (\sqrt, \frac, $...$). Always format MCQs cleanly with (ক), (খ), (গ), (ঘ). Keep explanations well-organized and easy to read on mobile.
                    """.trimIndent()
                )
            }
        )
    }

    /**
     * Builds a strictly valid Gemini conversation history:
     * - Filters out error messages and blank lines.
     * - Filters out the current prompt if already present.
     * - Guarantees the history starts with a "user" turn (Gemini API requirement).
     * - Strictly alternates roles: user -> model -> user -> model.
     * - Guarantees the history ends with a "model" turn so the next sendMessageStream(prompt) is a valid "user" turn.
     * - Takes at most the last 6 turns (3 dialog pairs) to minimize token latency and maximize generation speed.
     */
    fun buildValidChatHistory(
        rawHistory: List<Pair<String, String>>,
        currentPrompt: String
    ): List<Content> {
        val cleanList = mutableListOf<Pair<String, String>>()

        for ((role, text) in rawHistory) {
            val trimmed = text.trim()
            if (trimmed.isBlank()) continue
            // Skip system/error messages
            if (trimmed.startsWith("দুঃখিত") || trimmed.startsWith("ত্রুটি:")) continue
            // Skip the current prompt if it was already recorded
            if (role == "user" && trimmed == currentPrompt.trim()) continue

            val normalizedRole = if (role == "user") "user" else "model"

            if (cleanList.isEmpty()) {
                // First turn MUST be "user"
                if (normalizedRole == "user") {
                    cleanList.add(normalizedRole to trimmed)
                }
            } else {
                val lastRole = cleanList.last().first
                if (normalizedRole != lastRole) {
                    cleanList.add(normalizedRole to trimmed)
                } else {
                    // Replace with the newer turn of the same role
                    cleanList[cleanList.size - 1] = normalizedRole to trimmed
                }
            }
        }

        // History before sending a new prompt must end with "model"
        while (cleanList.isNotEmpty() && cleanList.last().first == "user") {
            cleanList.removeAt(cleanList.size - 1)
        }

        // Keep last 6 turns for ultra-fast TTFT
        return cleanList.takeLast(6).map { (role, message) ->
            content(role) {
                text(message)
            }
        }
    }

    /**
     * Safely extracts any generated text carried inside a ResponseStoppedException.
     */
    internal fun extractPartialText(exception: ResponseStoppedException): String? {
        return try {
            exception.response.text?.trim()?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Streams response chunks for real-time instant typing feedback.
     * Has auto-fallback to standard generation and safe ResponseStoppedException recovery.
     */
    fun streamChatResponse(prompt: String, conversationHistory: List<Pair<String, String>>): Flow<String> = flow {
        val validHistory = buildValidChatHistory(conversationHistory, prompt)
        var streamedAny = false

        try {
            // Attempt 1: Ultra-fast streaming with gemini-3.5-flash-lite
            val chatSession = fastModel.startChat(validHistory)
            withTimeout(60_000L) {
                chatSession.sendMessageStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        streamedAny = true
                        emit(chunkText)
                    }
                }
            }
        } catch (e: ResponseStoppedException) {
            val recovered = extractPartialText(e)
            if (streamedAny) {
                Log.w(TAG, "Stream stopped after partial output (${e.message}); preserving streamed chunks.")
            } else if (!recovered.isNullOrBlank()) {
                Log.w(TAG, "Recovered text from ResponseStoppedException during stream.")
                emit(recovered)
            } else {
                // Attempt 2: Fallback to standardModel if nothing was emitted yet
                emitStandardFallback(prompt, e)
            }
        } catch (e: Exception) {
            if (e is CancellationException && e !is TimeoutCancellationException) {
                throw e
            }
            Log.w(TAG, "Fast streaming attempt encountered issue (streamedAny=$streamedAny): ${e.message}")

            if (!streamedAny) {
                emitStandardFallback(prompt, e)
            } else {
                Log.d(TAG, "Stream completed with partial output before interruption.")
            }
        }
    }

    private suspend fun kotlinx.coroutines.flow.FlowCollector<String>.emitStandardFallback(
        prompt: String,
        originalError: Exception
    ) {
        try {
            withTimeout(60_000L) {
                val fallbackResponse = standardModel.generateContent(
                    content {
                        text("শিক্ষার্থীর প্রশ্ন: $prompt\n\nঅনুগ্রহ করে SSC 2028 সিলেবাস অনুযায়ী সহজ, সাবলীল বাংলায় দ্রুত ও নির্ভুল উত্তর দাও:")
                    }
                )
                val output = fallbackResponse.text.orEmpty()
                if (output.isNotBlank()) {
                    emit(output)
                } else {
                    throw originalError
                }
            }
        } catch (fallbackStop: ResponseStoppedException) {
            val recovered = extractPartialText(fallbackStop)
            if (!recovered.isNullOrBlank()) {
                emit(recovered)
            } else {
                Log.e(TAG, "Fallback stopped with empty text", fallbackStop)
                throw fallbackStop
            }
        } catch (fallbackError: Exception) {
            if (fallbackError is CancellationException && fallbackError !is TimeoutCancellationException) {
                throw fallbackError
            }
            Log.e(TAG, "Both AI generation attempts failed", fallbackError)
            throw fallbackError
        }
    }

    /**
     * Unary response for quick explanations (with 60s timeout, full output limit,
     * ResponseStoppedException partial-text recovery, and automatic standardModel fallback).
     */
    suspend fun getQuickExplanation(prompt: String): AiResult {
        try {
            val response: GenerateContentResponse = withTimeout(60_000L) {
                fastModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                return AiResult.Success(text)
            }
        } catch (e: ResponseStoppedException) {
            val partial = extractPartialText(e)
            if (!partial.isNullOrBlank()) {
                Log.w(TAG, "Quick explanation stopped cleanly with generated text: ${e.message}")
                return AiResult.Success(partial)
            }
            Log.w(TAG, "Fast quick explanation stopped without text (${e.message}); trying standardModel fallback.")
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Quick explanation fastModel timed out", e)
            return AiResult.Error("অনুরোধের সময়সীমা শেষ হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Fast quick explanation failed (${e.message}); trying standardModel fallback.")
        }

        // Fallback attempt with standardModel (gemini-3.8-flash)
        return try {
            val fallbackResponse: GenerateContentResponse = withTimeout(60_000L) {
                standardModel.generateContent(prompt)
            }
            val text = fallbackResponse.text?.trim()
            if (!text.isNullOrBlank()) {
                AiResult.Success(text)
            } else {
                AiResult.Error("MRH AI-এর পক্ষ থেকে খালি উত্তর এসেছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।")
            }
        } catch (e: ResponseStoppedException) {
            val partial = extractPartialText(e)
            if (!partial.isNullOrBlank()) {
                Log.w(TAG, "Fallback quick explanation stopped cleanly with generated text.")
                AiResult.Success(partial)
            } else {
                Log.e(TAG, "AI Generation error", e)
                AiResult.Error("উত্তরটি অনেক দীর্ঘ হওয়ায় সম্পন্ন করা যায়নি। দয়া করে আরও নির্দিষ্ট প্রশ্ন করুন।")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Request timed out", e)
            AiResult.Error("অনুরোধের সময়সীমা শেষ হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI Generation error", e)
            AiResult.Error(e.localizedMessage ?: "AI সংযোগে সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।")
        }
    }
}
