/**
 * Deployment-time script to register or promote an Agent role record in Firestore
 * without hardcoding any credentials inside the Android APK.
 *
 * Usage (with GOOGLE_APPLICATION_CREDENTIALS or Firebase Admin credentials):
 *   INITIAL_AGENT_UID="<firebase-auth-uid>" \
 *   INITIAL_AGENT_USERNAME="Mr1122" \
 *   INITIAL_AGENT_EMAIL="agent@example.com" \
 *   INITIAL_AGENT_DISPLAY_NAME="MRH Primary Agent" \
 *   node scripts/seed_initial_agent.mjs
 */

const { initializeApp, applicationDefault } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || "gen-lang-client-0209337239";
const DATABASE_ID =
  process.env.FIRESTORE_DATABASE_ID ||
  "ai-studio-android-mrhstudy-149b0cb0-d20f-448d-a8e5-fc151c3ee643";

async function main() {
  const uid = (process.env.INITIAL_AGENT_UID || "").trim();
  const username = (process.env.INITIAL_AGENT_USERNAME || "").trim();
  const email = (process.env.INITIAL_AGENT_EMAIL || "").trim();
  const displayName = (process.env.INITIAL_AGENT_DISPLAY_NAME || "Authorized Agent").trim();

  if (!uid || !username || !email) {
    console.error(
      "Missing required environment variables: INITIAL_AGENT_UID, INITIAL_AGENT_USERNAME, INITIAL_AGENT_EMAIL"
    );
    process.exit(1);
  }

  const app = initializeApp({
    credential: applicationDefault(),
    projectId: PROJECT_ID,
  });

  const db = getFirestore(app, DATABASE_ID);
  const docRef = db.collection("agents").doc(uid);
  const existing = await docRef.get();

  if (existing.exists) {
    await docRef.update({
      username,
      displayName,
      email,
      role: "agent",
      active: true,
      assignedBy: uid,
      updatedAt: FieldValue.serverTimestamp(),
    });
    console.log(`Updated existing agent role for UID=${uid} (${username}).`);
  } else {
    await docRef.set({
      uid,
      username,
      displayName,
      email,
      role: "agent",
      active: true,
      assignedBy: uid,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    console.log(`Seeded new agent role for UID=${uid} (${username}).`);
  }
}

main().catch((err) => {
  console.error("Failed to seed initial agent:", err);
  process.exit(1);
});
