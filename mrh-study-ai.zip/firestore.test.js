const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const nowTs = () => new Date(Date.now() - 2000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-mrhstudy-149b0cb0-d20f-448d-a8e5-fc151c3ee643";

const BOOTSTRAP_UID = "admin_mirat_uid";
const BOOTSTRAP_TOKEN = {
  email: "miratnew2026@gmail.com",
  email_verified: true,
};
const AGENT_2_UID = "agent_mr1122_uid";
const STUDENT_ALICE_UID = "student_alice_123";
const STUDENT_BOB_UID = "student_bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validMcqPayload(createdBy, overrides = {}) {
  return {
    subjectId: "general_math",
    subjectName: "সাধারণ গণিত",
    chapterNumber: 1,
    chapterTitle: "বাস্তব সংখ্যা",
    question: "নিচের কোনটি অমূলদ সংখ্যা?",
    options: ["√4", "√9", "√8", "0.5"],
    correctIndex: 2,
    explanation: "√8 = 2√2 একটি অমূলদ সংখ্যা।",
    difficulty: "medium",
    sourceType: "ocr_image",
    sourceFileUrl: "",
    sourceStoragePath: "mcq_uploads/admin/page1.png",
    ocrReviewed: false,
    status: "pending_review",
    quizId: "",
    createdBy,
    createdAt: nowTs(),
    updatedAt: nowTs(),
    ...overrides,
  };
}

function validQuizPayload(createdBy, overrides = {}) {
  return {
    title: "সাধারণ গণিত অধ্যায় ১ কুইজ",
    description: "এসএসসি ২০২৮ প্রস্তুতি কুইজ",
    subjectId: "general_math",
    subjectName: "সাধারণ গণিত",
    chapterNumber: 1,
    chapterTitle: "বাস্তব সংখ্যা",
    quizType: "chapter",
    difficulty: "medium",
    durationMinutes: 15,
    mcqIds: ["mcq_1"],
    questionCount: 1,
    status: "published",
    createdBy,
    createdByName: "Mr1122",
    createdAt: nowTs(),
    updatedAt: nowTs(),
    ...overrides,
  };
}

function validAttemptPayload(userId, overrides = {}) {
  return {
    userId,
    quizId: "quiz_1",
    quizTitle: "বাস্তব সংখ্যা টেস্ট",
    quizType: "chapter",
    subjectId: "general_math",
    subjectName: "সাধারণ গণিত",
    chapterTitle: "বাস্তব সংখ্যা",
    score: 8,
    totalQuestions: 10,
    accuracyPercent: 80.0,
    timeTakenSeconds: 240,
    examMode: false,
    answers: [
      {
        mcqId: "mcq_1",
        question: "√2 কোন ধরনের সংখ্যা?",
        selectedIndex: 1,
        correctIndex: 1,
        isCorrect: true,
      },
    ],
    createdAt: nowTs(),
    ...overrides,
  };
}

function validUploadPayload(createdBy, overrides = {}) {
  return {
    createdBy,
    fileName: "math_board_2025.pdf",
    fileType: "pdf",
    storagePath: `mcq_uploads/${createdBy}/math_board_2025.pdf`,
    downloadUrl: "",
    subjectId: "general_math",
    subjectName: "সাধারণ গণিত",
    chapterNumber: 3,
    chapterTitle: "বীজগাণিতিক রাশি",
    extractedCount: 5,
    reviewedCount: 0,
    ocrStatus: "pending_review",
    storageSynced: false,
    createdAt: nowTs(),
    updatedAt: nowTs(),
    ...overrides,
  };
}

function validAgentDoc(uid, assignedBy, overrides = {}) {
  return {
    uid,
    username: "Mr1122",
    displayName: "Agent Mr1122",
    email: "agent@example.com",
    role: "agent",
    active: true,
    assignedBy,
    createdAt: nowTs(),
    updatedAt: nowTs(),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function dbFor(uid, tokenOptions = undefined) {
  if (!uid) {
    return testEnv.unauthenticatedContext().firestore();
  }
  return testEnv.authenticatedContext(uid, tokenOptions).firestore();
}

// --- 1. UNAUTHENTICATED DENIALS ---

test("Unauthenticated user: cannot read or list any collection", async () => {
  const unauthDb = dbFor(null);
  await assertFails(unauthDb.collection("agents").doc(BOOTSTRAP_UID).get());
  await assertFails(unauthDb.collection("mcqs").where("status", "==", "published").get());
  await assertFails(unauthDb.collection("quizzes").where("status", "==", "published").get());
  await assertFails(unauthDb.collection("quiz_attempts").where("userId", "==", STUDENT_ALICE_UID).get());
  await assertFails(unauthDb.collection("mcq_uploads").where("createdBy", "==", BOOTSTRAP_UID).get());
});

test("Unauthenticated user: cannot write any collection", async () => {
  const unauthDb = dbFor(null);
  await assertFails(unauthDb.collection("mcqs").doc("mcq_unauth").set(validMcqPayload("anon")));
  await assertFails(unauthDb.collection("quiz_attempts").doc("att_unauth").set(validAttemptPayload("anon")));
});

// --- 2. BOOTSTRAPPED AGENT & REGISTERED AGENT RBAC ---

test("Bootstrapped agent: can create and update registered agent role without hardcoding credentials in APK", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("agents").doc(AGENT_2_UID).set(
      validAgentDoc(AGENT_2_UID, BOOTSTRAP_UID, { username: "Mr1122" })
    )
  );
  // Registered agent can read their own agent doc
  const agentDb = dbFor(AGENT_2_UID, { email: "agent@example.com", email_verified: true });
  await assertSucceeds(agentDb.collection("agents").doc(AGENT_2_UID).get());
  await assertSucceeds(agentDb.collection("agents").where("uid", "==", AGENT_2_UID).get());
});

test("Student: cannot create/promote themselves or others to agent role", async () => {
  const aliceDb = dbFor(STUDENT_ALICE_UID, { email: "alice@example.com", email_verified: true });
  await assertFails(
    aliceDb.collection("agents").doc(STUDENT_ALICE_UID).set(
      validAgentDoc(STUDENT_ALICE_UID, STUDENT_ALICE_UID)
    )
  );
  // Unverified mirat email also fails bootstrapped check
  const fakeAdminDb = dbFor("fake_uid", {
    email: "miratnew2026@gmail.com",
    email_verified: false,
  });
  await assertFails(
    fakeAdminDb.collection("agents").doc("fake_uid").set(
      validAgentDoc("fake_uid", "fake_uid")
    )
  );
});

// --- 3. OCR REVIEW GATE & MCQ LIFECYCLE ---

test("OCR Gate: cannot publish MCQ when ocrReviewed is false (must be reviewed first)", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertFails(
    adminDb.collection("mcqs").doc("mcq_unreviewed_publish").set(
      validMcqPayload(BOOTSTRAP_UID, {
        sourceType: "ocr_pdf",
        ocrReviewed: false,
        status: "published",
      })
    )
  );
});

test("Agent MCQ workflow: save unreviewed OCR draft -> review -> publish -> update -> delete", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("agents").doc(AGENT_2_UID).set(
      validAgentDoc(AGENT_2_UID, BOOTSTRAP_UID)
    )
  );

  const agentDb = dbFor(AGENT_2_UID, { email: "agent@example.com", email_verified: true });
  // Step 1: Save OCR extracted question to pending_review queue
  await assertSucceeds(
    agentDb.collection("mcqs").doc("mcq_ocr_1").set(
      validMcqPayload(AGENT_2_UID, {
        sourceType: "ocr_pdf",
        ocrReviewed: false,
        status: "pending_review",
      })
    )
  );

  // Step 2: Review & publish
  await assertSucceeds(
    agentDb.collection("mcqs").doc("mcq_ocr_1").update({
      question: "সংশোধিত প্রশ্ন: x² - 5x + 6 = 0 এর মূলদ্বয় কত?",
      ocrReviewed: true,
      status: "published",
      updatedAt: nowTs(),
    })
  );

  // Step 3: Registered agent queries own MCQs
  await assertSucceeds(
    agentDb.collection("mcqs").where("createdBy", "==", AGENT_2_UID).get()
  );
});

test("Student: cannot create, update, or delete MCQs or Quizzes", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("mcqs").doc("mcq_pub_1").set(
      validMcqPayload(BOOTSTRAP_UID, { ocrReviewed: true, status: "published" })
    )
  );

  const aliceDb = dbFor(STUDENT_ALICE_UID);
  await assertFails(
    aliceDb.collection("mcqs").doc("mcq_student_hack").set(
      validMcqPayload(STUDENT_ALICE_UID, { ocrReviewed: true, status: "published" })
    )
  );
  await assertFails(
    aliceDb.collection("mcqs").doc("mcq_pub_1").update({
      question: "Hacked?",
      updatedAt: nowTs(),
    })
  );
  await assertFails(aliceDb.collection("mcqs").doc("mcq_pub_1").delete());

  await assertFails(
    aliceDb.collection("quizzes").doc("quiz_student_hack").set(
      validQuizPayload(STUDENT_ALICE_UID)
    )
  );
});

test("Student query alignment: can read published MCQs & Quizzes, but CANNOT read draft/pending_review or unfiltered list (rules are not filters)", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("mcqs").doc("mcq_pub").set(
      validMcqPayload(BOOTSTRAP_UID, { ocrReviewed: true, status: "published" })
    )
  );
  await assertSucceeds(
    adminDb.collection("mcqs").doc("mcq_pending").set(
      validMcqPayload(BOOTSTRAP_UID, { ocrReviewed: false, status: "pending_review" })
    )
  );
  await assertSucceeds(
    adminDb.collection("quizzes").doc("quiz_pub").set(
      validQuizPayload(BOOTSTRAP_UID, { status: "published" })
    )
  );
  await assertSucceeds(
    adminDb.collection("quizzes").doc("quiz_draft").set(
      validQuizPayload(BOOTSTRAP_UID, { status: "draft" })
    )
  );

  const aliceDb = dbFor(STUDENT_ALICE_UID);
  // Published queries pass
  await assertSucceeds(aliceDb.collection("mcqs").where("status", "==", "published").get());
  await assertSucceeds(aliceDb.collection("quizzes").where("status", "==", "published").get());
  await assertSucceeds(aliceDb.collection("quizzes").doc("quiz_pub").get());

  // Unfiltered list fails because draft docs exist / rules are not filters
  await assertFails(aliceDb.collection("mcqs").get());
  await assertFails(aliceDb.collection("quizzes").get());

  // Direct get of draft/pending docs fails
  await assertFails(aliceDb.collection("mcqs").doc("mcq_pending").get());
  await assertFails(aliceDb.collection("quizzes").doc("quiz_draft").get());
});

// --- 4. QUIZ CREATION, IMMUTABLE FIELDS & SHADOW REJECTIONS ---

test("Agent quiz creation & update preserves createdBy/createdAt immutability and rejects shadow keys", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("quizzes").doc("quiz_1").set(
      validQuizPayload(BOOTSTRAP_UID, { status: "draft" })
    )
  );

  // Reject changing createdBy on update
  await assertFails(
    adminDb.collection("quizzes").doc("quiz_1").update({
      createdBy: STUDENT_ALICE_UID,
      updatedAt: nowTs(),
    })
  );

  // Reject shadow field injection
  await assertFails(
    adminDb.collection("quizzes").doc("quiz_shadow").set(
      validQuizPayload(BOOTSTRAP_UID, { isVerifiedSuperAdmin: true })
    )
  );

  // Valid publish & delete
  await assertSucceeds(
    adminDb.collection("quizzes").doc("quiz_1").update({
      status: "published",
      updatedAt: nowTs(),
    })
  );
  await assertSucceeds(adminDb.collection("quizzes").doc("quiz_1").delete());
});

// --- 5. STUDENT QUIZ ATTEMPTS ISOLATION & IMMUTABILITY ---

test("Quiz attempts: student can create and query own attempts, cannot spoof userId, cannot read Bob's, cannot tamper after submit", async () => {
  const aliceDb = dbFor(STUDENT_ALICE_UID);
  const bobDb = dbFor(STUDENT_BOB_UID);

  // Alice submits own attempt
  await assertSucceeds(
    aliceDb.collection("quiz_attempts").doc("att_alice_1").set(
      validAttemptPayload(STUDENT_ALICE_UID)
    )
  );

  // Alice queries own attempts (matching client query)
  await assertSucceeds(
    aliceDb.collection("quiz_attempts").where("userId", "==", STUDENT_ALICE_UID).get()
  );

  // Alice cannot spoof score > totalQuestions
  await assertFails(
    aliceDb.collection("quiz_attempts").doc("att_alice_bad").set(
      validAttemptPayload(STUDENT_ALICE_UID, { score: 15, totalQuestions: 10 })
    )
  );

  // Alice cannot spoof Bob's userId
  await assertFails(
    aliceDb.collection("quiz_attempts").doc("att_spoof").set(
      validAttemptPayload(STUDENT_BOB_UID)
    )
  );

  // Bob cannot read or list Alice's attempt
  await assertFails(bobDb.collection("quiz_attempts").doc("att_alice_1").get());
  await assertFails(bobDb.collection("quiz_attempts").get());

  // Neither student can update or delete an attempt
  await assertFails(
    aliceDb.collection("quiz_attempts").doc("att_alice_1").update({ score: 10 })
  );
  await assertFails(aliceDb.collection("quiz_attempts").doc("att_alice_1").delete());
});

// --- 6. MCQ UPLOADS RECORD ACCESS ---

test("MCQ uploads: authorized agent can track uploads; students denied", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("mcq_uploads").doc("up_1").set(
      validUploadPayload(BOOTSTRAP_UID)
    )
  );
  await assertSucceeds(
    adminDb.collection("mcq_uploads").doc("up_1").update({
      reviewedCount: 5,
      ocrStatus: "reviewed",
      updatedAt: nowTs(),
    })
  );

  const aliceDb = dbFor(STUDENT_ALICE_UID);
  await assertFails(
    aliceDb.collection("mcq_uploads").doc("up_alice").set(
      validUploadPayload(STUDENT_ALICE_UID)
    )
  );
  await assertFails(aliceDb.collection("mcq_uploads").doc("up_1").get());
});

test("Registered agent without email_verified claim in token still passes isAgent() RBAC", async () => {
  const adminDb = dbFor(BOOTSTRAP_UID, BOOTSTRAP_TOKEN);
  await assertSucceeds(
    adminDb.collection("agents").doc(AGENT_2_UID).set(
      validAgentDoc(AGENT_2_UID, BOOTSTRAP_UID)
    )
  );

  // Authenticated context without email/email_verified claims (e.g. emulator test user)
  const agentMinimalDb = dbFor(AGENT_2_UID);
  await assertSucceeds(
    agentMinimalDb.collection("mcqs").doc("mcq_by_agent2").set(
      validMcqPayload(AGENT_2_UID, { ocrReviewed: true, status: "published" })
    )
  );
});
